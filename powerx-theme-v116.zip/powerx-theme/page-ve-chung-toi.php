<?php if (!defined('ABSPATH')) exit; get_header();
$v = function($k){ return function_exists('powerx_ab_def') ? px_opt($k, powerx_ab_def($k)) : px_opt($k,''); };
?>

<!-- 1. HERO BANNER -->
<section class="px-ab-hero">
  <div class="px-wrap px-ab-hero-grid">
    <div class="px-ab-hero-text">
      <span class="px-eyebrow"><?php echo esc_html($v('powerx_ab_hero_eyebrow')); ?></span>
      <h1><?php echo esc_html($v('powerx_ab_hero_title')); ?></h1>
      <p><?php echo esc_html($v('powerx_ab_hero_lead')); ?></p>
      <div class="px-ab-hero-stats">
        <div><b>2011</b><small>Khởi nguồn DPD FOAM</small></div>
        <div><b>3 châu lục</b><small>Bắc Mỹ · Âu · Á</small></div>
        <div><b>2025</b><small>Độc quyền tại Việt Nam</small></div>
      </div>
    </div>
    <div class="px-ab-hero-media"><img src="<?php echo esc_url($v('powerx_ab_hero_img')); ?>" alt="Power X" loading="lazy"></div>
  </div>
</section>

<!-- 2. THƯƠNG HIỆU & CÂU CHUYỆN -->
<section class="px-section"><div class="px-wrap">
  <div class="px-ab-zig">
    <div class="px-ab-zig-media"><img src="<?php echo esc_url($v('powerx_ab_story_img')); ?>" alt="" loading="lazy"></div>
    <div class="px-ab-zig-text">
      <span class="px-eyebrow"><?php echo esc_html($v('powerx_ab_story_eyebrow')); ?></span>
      <h2><?php echo esc_html($v('powerx_ab_story_h')); ?></h2>
      <?php foreach(preg_split('/\n\s*\n/', (string)$v('powerx_ab_story_body')) as $para){ $para=trim($para); if($para!=='') echo '<p>'.nl2br(esc_html($para)).'</p>'; } ?>
    </div>
  </div>
</div></section>

<!-- 3. GIẢI THƯỞNG -->
<section class="px-section px-products-band"><div class="px-wrap">
  <div class="px-sec-head" style="text-align:center">
    <span class="px-eyebrow" style="color:var(--red)"><?php echo esc_html($v('powerx_ab_aw_eyebrow')); ?></span>
    <h2><?php echo esc_html($v('powerx_ab_aw_h')); ?></h2>
  </div>
  <ul class="px-ab-aw-chips">
    <?php foreach(preg_split('/\r?\n/', (string)$v('powerx_ab_aw_list')) as $ln){ $ln=trim($ln); if($ln==='') continue;
      if(mb_strpos($ln,'—')!==false){ $pp=array_map('trim',explode('—',$ln,2)); echo '<li><b>'.esc_html($pp[0]).'</b> — '.esc_html($pp[1]).'</li>'; }
      else echo '<li>'.esc_html($ln).'</li>';
    } ?>
  </ul>
  <?php $awfull=$v('powerx_ab_aw_fullimg'); if($awfull): ?>
    <div class="px-ab-aw-full"><img src="<?php echo esc_url($awfull); ?>" alt="Giải thưởng Power X" loading="lazy"></div>
  <?php endif; ?>
</div></section>

<!-- 4. CÔNG NGHỆ -->
<section class="px-section"><div class="px-wrap">
  <div class="px-sec-head" style="text-align:center"><span class="px-eyebrow">Công nghệ lõi</span><h2><?php echo esc_html($v('powerx_ab_tech_h')); ?></h2>
    <p style="max-width:620px;margin:8px auto 0;color:var(--muted)"><?php echo esc_html($v('powerx_ab_tech_lead')); ?></p></div>
  <div class="px-ab-tech">
    <?php for($i=1;$i<=3;$i++): ?>
    <article class="px-ab-tech-row<?php echo ($i%2===0)?' reverse':''; ?>">
      <div class="px-ab-tech-media"><img src="<?php echo esc_url($v("powerx_ab_t{$i}_img")); ?>" alt="" loading="lazy"></div>
      <div class="px-ab-tech-text">
        <h3><?php echo esc_html($v("powerx_ab_t{$i}_title")); ?></h3>
        <div class="px-ab-tech-sub"><?php echo esc_html($v("powerx_ab_t{$i}_sub")); ?></div>
        <p><?php echo esc_html($v("powerx_ab_t{$i}_text")); ?></p>
        <?php if($i===2): ?><div class="px-ab-stat"><b>8.2×</b><small>thoáng khí so với foam thường</small></div><?php endif; ?>
      </div>
    </article>
    <?php endfor; ?>
  </div>
</div></section>

<!-- 5. LỊCH SỬ HÌNH THÀNH -->
<section class="px-section px-products-band"><div class="px-wrap">
  <div class="px-sec-head" style="text-align:center"><span class="px-eyebrow">Hành trình</span><h2><?php echo esc_html($v('powerx_ab_hist_h')); ?></h2>
    <p class="px-htl-hint">← vuốt ngang để xem các mốc →</p></div>
  <ol class="px-ab-htimeline">
    <?php $idx=0; foreach(preg_split('/\r?\n/', (string)$v('powerx_ab_hist_lines')) as $ln){ $ln=trim($ln); if($ln==='') continue;
      $vn=false; if($ln[0]==='*'){ $vn=true; $ln=ltrim(substr($ln,1)); }
      $pp=array_map('trim',explode('|',$ln,2)); $year=$pp[0]; $txt=isset($pp[1])?$pp[1]:'';
      $cls=($idx%2===0?'up':'down').($vn?' is-vn':''); ?>
      <li class="<?php echo $cls; ?>"><div class="px-tl-card"><?php if($vn) echo '<span class="px-tl-flag">★ Cột mốc tại Việt Nam</span>'; ?><b class="px-tl-yr"><?php echo esc_html($year); ?></b><p><?php echo esc_html($txt); ?></p></div></li>
    <?php $idx++; } ?>
  </ol>
</div></section>

<!-- 6. BẢN ĐỒ THẾ GIỚI -->
<section class="px-section"><div class="px-wrap">
  <div class="px-sec-head" style="text-align:center"><span class="px-eyebrow">Dấu chân toàn cầu</span><h2><?php echo esc_html($v('powerx_ab_map_h')); ?></h2>
    <p style="max-width:620px;margin:8px auto 0;color:var(--muted)"><?php echo esc_html($v('powerx_ab_map_lead')); ?></p></div>
  <div class="px-worldmap">
    <img src="<?php echo esc_url(get_template_directory_uri().'/assets/about/worldmap.png'); ?>" alt="Bản đồ Power X toàn cầu" loading="lazy">
    <svg class="px-wm-svg" viewBox="0 0 1000 386" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
      <path class="px-wm-line" d="M806 133 Q514 15 222 105"/>
      <path class="px-wm-line" d="M806 133 Q675 35 539 94"/>
      <path class="px-wm-line px-wm-line-vn" d="M806 133 Q868 150 794 189"/>
      <circle r="3.4" class="px-wm-travel"><animateMotion dur="2.6s" repeatCount="indefinite" path="M806 133 Q514 15 222 105"/></circle>
      <circle r="3.4" class="px-wm-travel"><animateMotion dur="2.1s" repeatCount="indefinite" path="M806 133 Q675 35 539 94"/></circle>
      <circle r="3.6" class="px-wm-travel px-wm-travel-vn"><animateMotion dur="1.5s" repeatCount="indefinite" path="M806 133 Q868 150 794 189"/></circle>
      <g class="px-wm-pin" transform="translate(222,105)"><circle class="px-wm-pulse" r="4"/><path class="px-wm-mark" d="M0 0 C -3.5 -7 -12 -11 -12 -20 A 12 12 0 1 1 12 -20 C 12 -11 3.5 -7 0 0 Z"/><circle cx="0" cy="-20" r="5" fill="#fff"/><text class="px-wm-lbl" x="0" y="-34" text-anchor="middle">Bắc Mỹ</text></g>
      <g class="px-wm-pin" transform="translate(539,94)"><circle class="px-wm-pulse" r="4"/><path class="px-wm-mark" d="M0 0 C -3.5 -7 -12 -11 -12 -20 A 12 12 0 1 1 12 -20 C 12 -11 3.5 -7 0 0 Z"/><circle cx="0" cy="-20" r="5" fill="#fff"/><text class="px-wm-lbl" x="0" y="-34" text-anchor="middle">Châu Âu</text></g>
      <g class="px-wm-pin" transform="translate(806,133)"><circle class="px-wm-pulse" r="4"/><path class="px-wm-mark" d="M0 0 C -3.5 -7 -12 -11 -12 -20 A 12 12 0 1 1 12 -20 C 12 -11 3.5 -7 0 0 Z"/><circle cx="0" cy="-20" r="5" fill="#fff"/><text class="px-wm-lbl" x="0" y="-34" text-anchor="middle">Châu Á</text></g>
      <g class="px-wm-pin px-wm-pin-vn" transform="translate(794,189)"><circle class="px-wm-pulse" r="4"/><path class="px-wm-mark" d="M0 0 C -3.5 -7 -12 -11 -12 -20 A 12 12 0 1 1 12 -20 C 12 -11 3.5 -7 0 0 Z"/><circle cx="0" cy="-20" r="5" fill="#111"/><text class="px-wm-lbl" x="16" y="6" text-anchor="start">★ Việt Nam</text></g>
    </svg>
  </div>
</div></section>

<!-- CTA -->
<section class="px-showroom-cta-band"><div class="px-wrap" style="text-align:center">
  <h2 style="font-family:var(--display);font-weight:900;text-transform:uppercase;font-size:clamp(24px,3vw,38px);margin:0 0 8px">FOR ME · NOT FOR YOU</h2>
  <p style="color:var(--muted);max-width:560px;margin:0 auto 20px">Tìm dòng nệm Power X phù hợp với chính bạn.</p>
  <button class="px-btn px-lead-open" data-interest="Trang Về chúng tôi">Nhận tư vấn miễn phí</button>
</div></section>

<?php get_footer(); ?>
