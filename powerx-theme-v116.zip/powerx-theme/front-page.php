<?php if (!defined('ABSPATH')) exit; get_header();
// Mỗi slot Hero: có thể là VIDEO (mp4/YouTube/Vimeo) hoặc ẢNH. Chỉ giữ slot có nội dung.
$hero_raw = array(
  array('img'=>px_opt('powerx_hero_image',''),   'video'=>px_opt('powerx_hero_video','')),
  array('img'=>px_opt('powerx_hero_image_2',''), 'video'=>px_opt('powerx_hero_video_2','')),
  array('img'=>px_opt('powerx_hero_image_3',''), 'video'=>px_opt('powerx_hero_video_3','')),
);
$hero_slots=array();
foreach($hero_raw as $s){ if(trim($s['img'])!=='' || trim($s['video'])!=='') $hero_slots[]=$s; }
$hero_interval  = max(2, intval(px_opt('powerx_hero_interval',5)));
$hero_video_secs= max(2, intval(px_opt('powerx_hero_video_secs',8)));
$show_img = px_opt('powerx_showroom_image','');
?>

<!-- HERO -->
<section class="px-hero-v3" data-hero-interval="<?php echo esc_attr($hero_interval); ?>" data-hero-video-secs="<?php echo esc_attr($hero_video_secs); ?>">
  <div class="px-hero-slider">
    <div class="px-hero-track">
      <?php if($hero_slots): foreach($hero_slots as $i=>$s):
            $media = function_exists('powerx_hero_media') ? powerx_hero_media($s['video'],$s['img']) : array('is_video'=>false,'html'=>'','img'=>$s['img']);
            $is_video = !empty($media['is_video']);
            $dur = $is_video ? $hero_video_secs : $hero_interval;
            $style = (!$is_video && trim($s['img'])!=='') ? ' style="background-image:url('.esc_url($s['img']).')"' : '';
      ?>
        <div class="px-hero-slide<?php echo $i===0?' is-active':''; echo $is_video?' px-hero-slide--video':''; ?>" data-duration="<?php echo esc_attr($dur*1000); ?>"<?php echo $style; ?>><?php echo $is_video ? $media['html'] : ''; ?></div>
      <?php endforeach; else: ?>
        <div class="px-hero-slide is-active px-hero-noimg" data-duration="<?php echo esc_attr($hero_interval*1000); ?>"></div>
      <?php endif; ?>
    </div>
  </div>
  <div class="px-hero-overlay"></div>
  <div class="px-wrap">
    <div class="px-hero-card">
      <span class="px-eyebrow"><?php echo esc_html(px_opt('powerx_hero_eyebrow','Nệm & gối hiệu năng cao')); ?></span>
      <h1><span class="hero-en"><?php echo esc_html(px_opt('powerx_hero_h1_a','FOR ME')); ?> · <em><?php echo esc_html(px_opt('powerx_hero_h1_em','NOT FOR YOU')); ?></em></span></h1>
      <div class="px-hero-tag"><?php echo esc_html(px_opt('powerx_hero_tag','POWER X — Sleep Performance')); ?></div>
      <p><?php echo esc_html(px_opt('powerx_hero_lead','Hybrid Graphene + lò xo túi phân vùng. Bốn dòng nệm cho bốn lifestyle.')); ?></p>
      <div class="px-hero-cta">
        <a class="px-btn px-btn-lime" href="#px-collection"><?php echo esc_html(px_opt('powerx_hero_btn1','Khám phá sản phẩm')); ?> →</a>
        <button class="px-btn px-btn-ghost px-lead-open" data-interest="Hero"><?php echo esc_html(px_opt('powerx_hero_btn2','Nhận tư vấn miễn phí')); ?></button>
      </div>
    </div>
  </div>
  <?php if(count($hero_slots)>1): ?>
  <div class="px-hero-dots" role="tablist" aria-label="Chuyển slide hero">
    <?php foreach($hero_slots as $i=>$s): ?>
      <button class="px-hero-dot<?php echo $i===0?' active':''; ?>" data-idx="<?php echo esc_attr($i); ?>" aria-label="<?php echo esc_attr('Slide '.($i+1)); ?>"></button>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>

<div class="px-trust"><div class="px-trust-track">
  <?php
  $px_certs = array('CertiPUR-US®','OEKO-TEX®','ISO 9001','RED DOT 2019','BẢO HÀNH 10 NĂM','GIAO LẮP 24H','100 ĐÊM DÙNG THỬ','TRẢ GÓP 0%');
  // 2 nhóm giống nhau để chạy vòng lặp liền mạch (-50%)
  for($g=0;$g<2;$g++){
    echo '<div class="px-trust-group" aria-hidden="'.($g?'true':'false').'">';
    for($k=0;$k<2;$k++){ foreach($px_certs as $c){ echo '<span class="px-cert">'.esc_html($c).'</span>'; } }
    echo '</div>';
  }
  ?>
</div></div>

<?php if (function_exists('powerx_promo_banner')) echo powerx_promo_banner(); ?>

<!-- TABS: Nệm / Gối / Tư vấn / Liên hệ -->
<section id="px-collection" class="px-section"><div class="px-wrap">
  <div class="px-sec-head" style="text-align:center">
    <span class="px-eyebrow">Bộ sưu tập</span>
    <h2>Chọn sản phẩm Power X</h2>
  </div>

  <div class="px-tabs" data-tabs>
    <div class="px-tab-bar" role="tablist">
      <button class="px-tab-btn active" data-tab="nem" role="tab">🛏 Nệm <span>4</span></button>
      <button class="px-tab-btn" data-tab="goi" role="tab">💤 Gối <span>2</span></button>
      <button class="px-tab-btn" data-tab="quiz" role="tab">⚡ Tư vấn nhanh</button>
      <button class="px-tab-btn" data-tab="contact" role="tab">📞 Liên hệ</button>
    </div>

    <div class="px-tab-panel active" data-panel="nem">
      <p class="px-tab-desc">Bốn dòng nệm cho bốn lifestyle — chọn theo nhu cầu sống của bạn.</p>
      <?php echo do_shortcode('[powerx_personas]'); ?>
    </div>

    <div class="px-tab-panel" data-panel="goi">
      <p class="px-tab-desc">Hai dòng gối CNC foam nhớ — định hình và cân bằng.</p>
      <div class="px-pillows">
        <a class="px-pillow" href="/product/power-x-ergo/">
          <?php if(function_exists('powerx_promo_badge_html')) echo powerx_promo_badge_html('px-sale-badge--pillow'); ?>
          <?php $img_ergo = px_opt('powerx_pillow_img_ergo',''); ?>
          <div class="px-pillow-media<?php echo $img_ergo?' has-img':''; ?>"><?php if($img_ergo): ?><img src="<?php echo esc_url($img_ergo); ?>" alt="Gối Power X Ergo" loading="lazy"><?php else: ?><svg width="180" height="120" viewBox="0 0 260 160"><ellipse cx="130" cy="146" rx="95" ry="11" fill="#000" opacity=".07"/><path d="M44 132 L44 104 Q60 96 78 100 Q96 104 108 90 Q120 80 140 86 Q165 96 196 92 Q214 90 216 108 L216 132 Q216 140 208 140 L52 140 Q44 140 44 132 Z" fill="#fff" stroke="#dcdcdc"/><path d="M44 124 L216 124 L216 132 Q216 140 208 140 L52 140 Q44 140 44 132 Z" fill="#bcd3e6"/></svg><?php endif; ?></div>
          <div class="px-pillow-body">
            <span class="px-pillow-code">ERGO</span>
            <h3>Power X Ergo</h3>
            <div class="px-pillow-tag">Ergo Support. Wake Up Sharp.</div>
            <p>Gối định hình CNC, foam nhớ 40D — ôm sát đường cong cổ gáy.</p>
            <ul class="px-pillow-feats">
              <li><b>40 × 60 × 10/12 cm</b> · Memory Foam 40D</li>
              <li>Vải PE làm mát · Khóa kéo tháo giặt</li>
              <li>Phù hợp: nghiêng/ngửa cố định, mỏi cổ gáy</li>
            </ul>
            <div class="px-pillow-foot"><span class="px-pillow-price">1.198.000 ₫</span><span class="px-pillow-cta">Khám phá →</span></div>
          </div>
        </a>
        <a class="px-pillow" href="/product/power-x-matrix/">
          <?php if(function_exists('powerx_promo_badge_html')) echo powerx_promo_badge_html('px-sale-badge--pillow'); ?>
          <?php $img_matrix = px_opt('powerx_pillow_img_matrix',''); ?>
          <div class="px-pillow-media<?php echo $img_matrix?' has-img':''; ?>"><?php if($img_matrix): ?><img src="<?php echo esc_url($img_matrix); ?>" alt="Gối Power X Matrix" loading="lazy"><?php else: ?><svg width="180" height="120" viewBox="0 0 260 160"><ellipse cx="130" cy="146" rx="95" ry="11" fill="#000" opacity=".07"/><path d="M44 132 L44 100 Q130 86 216 100 L216 132 Q216 140 208 140 L52 140 Q44 140 44 132 Z" fill="#fff" stroke="#dcdcdc"/><path d="M44 124 L216 124 L216 132 Q216 140 208 140 L52 140 Q44 140 44 132 Z" fill="#C3FF00"/></svg><?php endif; ?></div>
          <div class="px-pillow-body">
            <span class="px-pillow-code lime">MATRIX</span>
            <h3>Power X Matrix</h3>
            <div class="px-pillow-tag">Balance. Comfort. Recovery.</div>
            <p>Gối CNC kép Memory 40D + Baby Foam 25D — cân bằng nâng đỡ và êm thoáng.</p>
            <ul class="px-pillow-feats">
              <li><b>40 × 60 × 12 cm</b> · Memory 40D + Baby 25D</li>
              <li>Vải PE làm mát · Matrix Square Cut</li>
              <li>Phù hợp: hay đổi tư thế, dân văn phòng</li>
            </ul>
            <div class="px-pillow-foot"><span class="px-pillow-price">2.198.000 ₫</span><span class="px-pillow-cta">Khám phá →</span></div>
          </div>
        </a>
      </div>
    </div>

    <div class="px-tab-panel" data-panel="quiz">
      <p class="px-tab-desc">Trả lời 4 câu hỏi nhanh — Power X gợi ý đúng dòng nệm phù hợp.</p>
      <?php echo do_shortcode('[powerx_quiz type="mattress"]'); ?>
    </div>

    <!-- TAB LIÊN HỆ -->
    <div class="px-tab-panel" data-panel="contact">
      <p class="px-tab-desc">Để lại thông tin — Power X sẽ liên hệ tư vấn &amp; báo giá tốt nhất.</p>
      <div class="px-contact">
        <div class="px-contact-info">
          <h3>Kết nối với Power X</h3>
          <?php $ph=px_opt('powerx_phone','0335332028'); $msg=px_opt('powerx_messenger'); $em=px_opt('powerx_email'); $zl=px_opt('powerx_zalo'); $ad=px_opt('powerx_address','Số nhà E97, Đường D9, khu phố Vĩnh Thanh, Phường Trấn Biên, Thành Phố Đồng Nai'); ?>
          <ul>
            <?php if($ph): ?>
            <li><span class="px-c-icon px-c-phone"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.1-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.5 2.7.6a2 2 0 0 1 1.7 2z"/></svg></span>
              <div><small>Hotline</small><a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$ph)); ?>"><?php echo esc_html($ph); ?></a></div></li>
            <?php endif; ?>
            <?php if($msg): ?>
            <li><span class="px-c-icon px-c-fb"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.5 2 2 6.1 2 11.2c0 2.9 1.4 5.5 3.7 7.2v3.6l3.4-1.9c.9.2 1.9.4 2.9.4 5.5 0 10-4.1 10-9.2S17.5 2 12 2z"/></svg></span>
              <div><small>Facebook / Messenger</small><a href="<?php echo esc_url($msg); ?>" target="_blank" rel="noopener">Chat với Power X</a></div></li>
            <?php endif; ?>
            <?php if($zl): ?>
            <li><span class="px-c-icon px-c-zalo"><b>Z</b></span>
              <div><small>Zalo</small><a href="<?php echo esc_url($zl); ?>" target="_blank" rel="noopener">Liên hệ qua Zalo</a></div></li>
            <?php endif; ?>
            <?php if($em): ?>
            <li><span class="px-c-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M2 7l10 6 10-6"/></svg></span>
              <div><small>Email</small><a href="mailto:<?php echo esc_attr($em); ?>"><?php echo esc_html($em); ?></a></div></li>
            <?php endif; ?>
            <?php if($ad): ?>
            <li><span class="px-c-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 1 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></span>
              <div><small>Showroom</small><span><?php echo esc_html($ad); ?></span></div></li>
            <?php endif; ?>
          </ul>
        </div>
        <form class="px-contact-form px-lead-form" data-static-form>
          <h3>Để Power X gọi cho bạn</h3>
          <input name="name" placeholder="Họ và tên *" required>
          <input name="phone" placeholder="Số điện thoại *" required>
          <input name="email" placeholder="Email (tuỳ chọn)">
          <textarea name="note" placeholder="Bạn quan tâm sản phẩm nào? Ngân sách dự kiến?" rows="3"></textarea>
          <input type="hidden" name="interest" value="Tab Liên hệ">
          <button type="submit" class="px-btn px-btn-lime">Gửi thông tin →</button>
          <div class="px-lead-msg"></div>
          <p style="font-size:12px;color:var(--muted2);margin-top:8px">Thông tin của bạn sẽ chỉ được dùng cho mục đích tư vấn.</p>
        </form>
      </div>
    </div>

  </div>
</div></section>

<!-- CÔNG NGHỆ LÕI · HOT DELETE (theo Fable, nền trắng) -->
<?php if (function_exists('powerx_tech_section')) echo powerx_tech_section(); ?>

<!-- SO SÁNH CHI TIẾT (VS Analyzer theo Fable) -->
<?php if (function_exists('powerx_compare_v2')) echo powerx_compare_v2(); ?>

<!-- PHẢN HỒI KHÁCH HÀNG (kiểu Bedgear: carousel + khung sản phẩm trong từng thẻ) -->
<section class="px-section"><div class="px-wrap">
  <div class="px-sec-head" style="text-align:center"><span class="px-eyebrow">Phản hồi khách hàng</span></div>
  <div class="px-reviews-head">
    <h2 class="pxf-rev-title">HỌ ĐÃ ĐỔI NỆM.<br><em>VÀ ĐỔI CẢ BUỔI SÁNG.</em></h2>
    <div class="px-reviews-arrows">
      <button type="button" class="px-rev-arrow" data-dir="-1" aria-label="Trước"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M15 18l-6-6 6-6"/></svg></button>
      <button type="button" class="px-rev-arrow" data-dir="1" aria-label="Sau"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M9 6l6 6-6 6"/></svg></button>
    </div>
  </div>
  <div class="px-reviews" id="px-reviews-track">
    <?php $rev_d = function_exists('powerx_reviews_defaults') ? powerx_reviews_defaults() : array();
    for($ri=1;$ri<=4;$ri++):
      $dd = isset($rev_d[$ri]) ? $rev_d[$ri] : array('','','5','','','');
      $rn=px_opt("powerx_rev{$ri}_name",$dd[0]); $rt=px_opt("powerx_rev{$ri}_text",$dd[3]);
      if($rn==='' && $rt==='') continue;
      $rs=max(1,min(5,intval(px_opt("powerx_rev{$ri}_stars",$dd[2])))); $rsub=px_opt("powerx_rev{$ri}_sub",$dd[1]);
      $rtitle=px_opt("powerx_rev{$ri}_title", isset($dd[4])?$dd[4]:'');
      $rpslug=px_opt("powerx_rev{$ri}_product", isset($dd[5])?$dd[5]:'');
      $rprod = ($rpslug && function_exists('powerx_prod_by_slug')) ? powerx_prod_by_slug($rpslug) : null;
      $initial = function_exists('mb_substr') ? mb_strtoupper(mb_substr($rn,0,1)) : strtoupper(substr($rn,0,1)); ?>
      <div class="px-review">
        <div class="px-review-stars"><?php echo str_repeat('★',$rs).'<span class="px-review-stars-off">'.str_repeat('★',5-$rs).'</span>'; ?></div>
        <?php if($rtitle!==''): ?><div class="px-review-title"><?php echo esc_html($rtitle); ?></div><?php endif; ?>
        <p class="px-review-text">“<?php echo esc_html($rt); ?>”</p>
        <div class="px-review-by">
          <span class="px-review-ava"><?php echo esc_html($initial); ?></span>
          <span class="px-review-who"><b><?php echo esc_html($rn); ?></b>
            <span class="px-review-verified"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6"><path d="M20 6L9 17l-5-5"/></svg>Đã mua hàng · <?php echo esc_html($rsub); ?></span>
          </span>
        </div>
        <?php if($rprod):
          $pid=$rprod->get_id(); $purl=get_permalink($pid); ?>
        <div class="px-review-prod">
          <a class="px-review-prod-img" href="<?php echo esc_url($purl); ?>"><?php echo $rprod->get_image('woocommerce_gallery_thumbnail'); ?></a>
          <span class="px-review-prod-info">
            <b><?php echo esc_html($rprod->get_name()); ?></b>
            <span class="px-review-prod-price"><?php echo $rprod->get_price_html(); ?></span>
          </span>
          <a class="px-review-prod-btn" href="<?php echo esc_url($rprod->add_to_cart_url()); ?>" data-quantity="1" data-product_id="<?php echo esc_attr($pid); ?>" rel="nofollow"><?php echo esc_html($rprod->is_purchasable() && $rprod->is_in_stock() ? 'Mua ngay' : 'Xem'); ?></a>
        </div>
        <?php endif; ?>
      </div>
    <?php endfor; ?>
  </div>
</div></section>

<!-- SHOWROOM (theo Fable) — đặt trước Blog -->
<?php if (function_exists('powerx_showroom_v2')) echo powerx_showroom_v2(); ?>

<!-- BLOG -->
<section class="px-section"><div class="px-wrap">
  <div class="px-sec-head"><span class="px-eyebrow">Sống khỏe &amp; ngủ ngon</span><h2>Từ Power X</h2></div>
  <div class="px-blog-grid">
  <?php $q=new WP_Query(array('post_type'=>'post','posts_per_page'=>3,'ignore_sticky_posts'=>true));
  if($q->have_posts()): while($q->have_posts()): $q->the_post(); ?>
    <a class="px-blog-card" href="<?php the_permalink(); ?>">
      <div class="px-blog-thumb"><?php if(has_post_thumbnail()) the_post_thumbnail('medium_large'); else echo '<span>POWER X</span>'; ?></div>
      <div class="px-blog-body">
        <span class="px-blog-cat"><?php $c=get_the_category(); echo $c?esc_html($c[0]->name):'Blog'; ?></span>
        <h3><?php the_title(); ?></h3>
        <p><?php echo esc_html(wp_trim_words(get_the_excerpt(),22)); ?></p>
      </div>
    </a>
  <?php endwhile; wp_reset_postdata(); endif; ?>
  </div>
  <div style="text-align:center;margin-top:24px"><a class="px-btn px-btn-ghost" href="<?php echo esc_url(home_url('/blog/')); ?>">Xem tất cả bài viết →</a></div>
</div></section>

<script>
document.addEventListener('DOMContentLoaded',function(){
  document.querySelectorAll('.px-tabs').forEach(function(wrap){
    var btns = wrap.querySelectorAll('.px-tab-btn');
    var pans = wrap.querySelectorAll('.px-tab-panel');
    btns.forEach(function(b){ b.addEventListener('click',function(){
      btns.forEach(function(x){x.classList.remove('active');}); pans.forEach(function(p){p.classList.remove('active');});
      b.classList.add('active'); wrap.querySelector('[data-panel="'+b.getAttribute('data-tab')+'"]').classList.add('active');
    });});
  });
  // Form liên hệ tĩnh trên trang chủ (không phải popup) -> submit qua cùng AJAX
  document.querySelectorAll('[data-static-form]').forEach(function(f){
    f.addEventListener('submit',function(e){
      e.preventDefault();
      var msg=f.querySelector('.px-lead-msg'), btn=f.querySelector('button[type=submit]');
      var fd=new FormData(f); fd.append('action','powerx_lead'); fd.append('nonce',PowerX.nonce);
      btn.disabled=true; msg.textContent='Đang gửi...';
      fetch(PowerX.ajax,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(j){
        msg.style.color = j.success?'#2e7d00':'#A81E2E';
        msg.textContent = (j.data&&j.data.msg)||'Hoàn tất';
        if(j.success) f.reset(); btn.disabled=false;
      }).catch(function(){msg.style.color='#A81E2E'; msg.textContent='Lỗi kết nối'; btn.disabled=false;});
    });
  });

  // HERO SLIDER — trượt sang trái tự động, loop mượt (clone slide đầu)
  // Mỗi slide có thời lượng riêng: ẢNH dùng data-hero-interval, VIDEO dùng data-duration (giây hiển thị video).
  (function(){
    var hero = document.querySelector('.px-hero-v3'); if(!hero) return;
    var track = hero.querySelector('.px-hero-track');
    var slides = track ? Array.prototype.slice.call(track.children) : [];
    var dots = Array.prototype.slice.call(hero.querySelectorAll('.px-hero-dot'));
    var real = slides.length;
    var fallback = (parseInt(hero.getAttribute('data-hero-interval'),10)||5) * 1000;
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Thời lượng từng slide (ms) đọc từ data-duration
    var durations = slides.map(function(s){ return parseInt(s.getAttribute('data-duration'),10) || fallback; });

    // Cố gắng phát video MP4 của slide (autoplay có thể bị chặn → bấm tay vẫn play)
    function playVideoIn(slide){
      if(!slide) return; var v = slide.querySelector('video');
      if(v){ try{ v.currentTime = 0; var p = v.play(); if(p && p.catch) p.catch(function(){}); }catch(e){} }
    }
    // Phát video slide đầu ngay khi tải
    if(real>0) playVideoIn(slides[0]);

    if(real < 2){ return; } // 1 slide: đứng yên (video tự loop bằng thuộc tính HTML)

    // clone slide đầu để loop liền mạch
    var clone = slides[0].cloneNode(true); clone.classList.remove('is-active');
    track.appendChild(clone);

    var idx = 0, timer = null, animating = false;
    function go(i){
      animating = true;
      track.style.transition = 'transform .9s cubic-bezier(.65,0,.35,1)';
      track.style.transform = 'translateX(' + (-i*100) + '%)';
      var active = (i % real);
      dots.forEach(function(d,di){ d.classList.toggle('active', di===active); });
    }
    track.addEventListener('transitionend', function(){
      animating = false;
      if(idx >= real){ // vừa tới clone -> nhảy về 0 không transition
        idx = 0;
        track.style.transition = 'none';
        track.style.transform = 'translateX(0)';
      }
      playVideoIn(slides[idx % real]); // phát lại video của slide hiện tại
      schedule();
    });
    function next(){ if(animating) return; idx++; go(idx); }
    function schedule(){ if(reduce) return; stop(); var d = durations[idx % real] || fallback; timer = setTimeout(next, d); }
    function stop(){ if(timer){ clearTimeout(timer); timer = null; } }

    dots.forEach(function(d){
      d.addEventListener('click', function(){
        if(animating) return;
        idx = parseInt(d.getAttribute('data-idx'),10)||0; go(idx); playVideoIn(slides[idx % real]); schedule();
      });
    });
    hero.addEventListener('mouseenter', stop);
    hero.addEventListener('mouseleave', schedule);
    schedule();
  })();
});
</script>
<?php get_footer(); ?>
