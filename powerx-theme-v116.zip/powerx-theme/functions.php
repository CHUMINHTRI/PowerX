<?php
/** Power X theme functions (v2 — Casper layout + Quiz + Leads + Blog) */
if (!defined('ABSPATH')) exit;

define('POWERX_VER','7.37.1');

if (!function_exists('powerx_setup')):
function powerx_setup(){
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array('height'=>60,'width'=>200,'flex-height'=>true,'flex-width'=>true));
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    add_theme_support('automatic-feed-links');
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
    register_nav_menus(array('primary'=>'Menu chính'));
}
endif;
add_action('after_setup_theme','powerx_setup');

function powerx_asset_ver($rel){
    $path = get_template_directory().'/'.ltrim($rel,'/');
    return file_exists($path) ? filemtime($path) : POWERX_VER;
}
function powerx_assets(){
    wp_enqueue_style('powerx-fonts','https://fonts.googleapis.com/css2?family=Archivo:wght@700;800;900&display=swap', array(), null);
    wp_enqueue_style('powerx-style', get_stylesheet_uri(), array('powerx-fonts'), powerx_asset_ver('style.css'));
    wp_enqueue_script('powerx-quiz', get_template_directory_uri().'/js/quiz.js', array(), powerx_asset_ver('js/quiz.js'), true);
    wp_localize_script('powerx-quiz','PowerX', array(
        'ajax'  => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('powerx_lead'),
        'shop'  => function_exists('wc_get_page_id') ? get_permalink(wc_get_page_id('shop')) : home_url('/'),
    ));
}
add_action('wp_enqueue_scripts','powerx_assets');

require get_template_directory().'/inc/leads.php';
require get_template_directory().'/inc/quiz.php';
require get_template_directory().'/inc/shortcodes.php';
require get_template_directory().'/inc/products.php';
require get_template_directory().'/inc/customizer.php';
require get_template_directory().'/inc/price-display.php';
require get_template_directory().'/inc/wc-fix.php';
require get_template_directory().'/inc/discount-badge.php';
require get_template_directory().'/inc/pages.php';
require get_template_directory().'/inc/shop-archive.php';
require get_template_directory().'/inc/single-product.php';
require get_template_directory().'/inc/cart-drawer.php';
require get_template_directory().'/inc/checkout.php';
require get_template_directory().'/inc/training.php';
require get_template_directory().'/inc/lang.php';
require get_template_directory().'/inc/home-sections.php';

/* Vai trò mẫu + seeding (chạy 1 lần khi kích hoạt theme) */
function powerx_activate(){
    add_role('powerx_sales','Power X – Nhân viên bán hàng', array('read'=>true,'upload_files'=>true,'edit_products'=>true,'edit_published_products'=>true));
    if (get_option('powerx_seeded')!==POWERX_VER){
        require get_template_directory().'/inc/setup.php';
        powerx_seed_pages_categories();
        require get_template_directory().'/inc/blog-seed.php';
        powerx_seed_blog();
        update_option('powerx_seeded',POWERX_VER);
    }
}
add_action('after_switch_theme','powerx_activate');

function powerx_cart_count(){ return (function_exists('WC') && WC()->cart) ? WC()->cart->get_cart_contents_count() : 0; }

/* Logo mặc định Power X: ảnh PNG gốc của brand. $variant: 'dark' (header, nền sáng) | 'light' (footer, nền tối) */
function powerx_default_logo($variant='dark'){
    $file = ($variant==='light') ? 'logo-powerx-white.png' : 'logo-powerx.png';
    $path = get_template_directory().'/assets/'.$file;
    $ver  = file_exists($path) ? filemtime($path) : POWERX_VER;
    $src  = add_query_arg('v', $ver, get_template_directory_uri().'/assets/'.$file);
    $alt  = esc_attr(get_bloginfo('name').' — FOR ME · NOT FOR YOU');
    return '<img class="px-logo-img" src="'.esc_url($src).'" alt="'.$alt.'" width="246" height="50">';
}

/* URL chuyên mục sản phẩm: thử lần lượt nhiều slug, slug nào CÓ thì dùng; không có thì về Cửa hàng */
function powerx_cat_url($slugs){
    foreach((array)$slugs as $slug){
        $term = function_exists('get_term_by') ? get_term_by('slug',$slug,'product_cat') : false;
        if($term && !is_wp_error($term)){ $l=get_term_link($term); if(!is_wp_error($l)) return $l; }
    }
    if (function_exists('wc_get_page_id')){ $s=wc_get_page_id('shop'); if($s>0) return get_permalink($s); }
    return home_url('/');
}
/* Lấy product object từ slug */
function powerx_prod_by_slug($slug){
    $pobj = get_page_by_path($slug, OBJECT, 'product');
    if(!$pobj) return null;
    $prod = function_exists('wc_get_product') ? wc_get_product($pobj->ID) : null;
    return ($prod && $prod->get_status()==='publish') ? $prod : null;
}
/* Panel mega 2 cột kiểu Bedgear: TRÁI = thẻ ảnh dòng sản phẩm · PHẢI = bán chạy (ảnh + tên + giá) + nút xem tất cả */
function powerx_mega_panel($line_slugs, $cat_slugs, $title_left, $title_right, $quiz_url='', $quiz_text=''){
    if(!function_exists('wc_get_product')) return '';
    // TRÁI: thẻ ảnh dòng sản phẩm
    $tiles='';
    foreach($line_slugs as $slug){
        $prod = powerx_prod_by_slug($slug); if(!$prod) continue;
        $tiles .= '<a class="px-mega-card" href="'.esc_url(get_permalink($prod->get_id())).'"><span class="px-mega-img">'.$prod->get_image('woocommerce_thumbnail').'</span><span class="px-mega-name">'.esc_html($prod->get_name()).'</span></a>';
    }
    if($tiles==='') return '';
    // PHẢI: bán chạy theo chuyên mục (fallback = các dòng ở trên)
    $cat=''; foreach($cat_slugs as $cs){ $t=get_term_by('slug',$cs,'product_cat'); if($t && !is_wp_error($t)){ $cat=$cs; break; } }
    $prods=array();
    if($cat && function_exists('wc_get_products')){
        $prods = wc_get_products(array('status'=>'publish','limit'=>4,'orderby'=>'popularity','order'=>'DESC','category'=>array($cat)));
    }
    if(empty($prods)){ foreach($line_slugs as $slug){ $p=powerx_prod_by_slug($slug); if($p) $prods[]=$p; } }
    $rows='';
    foreach($prods as $tp){
        $rows .= '<a class="px-mega-prod" href="'.esc_url(get_permalink($tp->get_id())).'">'
               . '<span class="px-mega-prod-img">'.$tp->get_image('woocommerce_gallery_thumbnail').'</span>'
               . '<span class="px-mega-prod-info"><b>'.esc_html($tp->get_name()).'</b><span class="px-mega-prod-price">'.$tp->get_price_html().'</span></span></a>';
    }
    $shopall = powerx_cat_url($cat_slugs);
    $right = $rows!=='' ? '<div class="px-mega-h">'.esc_html($title_right).'</div><div class="px-mega-top-list">'.$rows.'</div><a class="px-mega-shopall" href="'.esc_url($shopall).'">Xem tất cả →</a>' : '';
    $cta = ($quiz_url && $quiz_text) ? '<a class="px-mega-quiz" href="'.esc_url($quiz_url).'"><span class="px-mega-quiz-ic">⚡</span><span class="px-mega-quiz-tx"><b>'.esc_html($quiz_text).'</b><small>Trả lời vài câu hỏi nhanh — Power X gợi ý sản phẩm phù hợp nhất với bạn →</small></span></a>' : '';
    return '<div class="px-mega"><div class="px-mega-inner">'
         . '<div class="px-mega-col px-mega-types"><div class="px-mega-h">'.esc_html($title_left).'</div><div class="px-mega-grid">'.$tiles.'</div></div>'
         . ($right ? '<div class="px-mega-col px-mega-top">'.$right.'</div>' : '')
         . '</div>'
         . $cta
         . '</div>';
}
/* Tạo HTML panel mega theo loại ('nem' | 'goi') — dùng chung cho fallback menu và walker menu tuỳ biến */
function powerx_mega_by_type($type){
    if($type==='nem'){
        $qn=get_page_by_path('quiz-nem'); $qn_url=$qn?get_permalink($qn):'';
        return powerx_mega_panel(array('power-x-prime','power-x-fusion','power-x-flow','power-x-core'), array('nem-hightech','nem','nem-hi-tech'), 'Các dòng nệm', 'Bán chạy nhất', $qn_url, 'Chưa biết chọn nệm nào? Làm quiz chọn nệm');
    }
    if($type==='goi'){
        $qg=get_page_by_path('quiz-goi'); $qg_url=$qg?get_permalink($qg):'';
        return powerx_mega_panel(array('power-x-ergo','power-x-matrix'), array('goi-hightech','goi','goi-hi-tech'), 'Các dòng gối', 'Bán chạy nhất', $qg_url, 'Chưa biết chọn gối nào? Làm quiz chọn gối');
    }
    return '';
}
/* Xác định mục menu nào cần gắn mega: theo chuyên mục sản phẩm (slug nem/goi) hoặc theo tiêu đề có "Hightech" + nệm/gối */
function powerx_mega_type_for_item($item){
    $obj = isset($item->object) ? $item->object : '';
    if($obj==='product_cat' && !empty($item->object_id)){
        $term = get_term((int)$item->object_id, 'product_cat');
        if($term && !is_wp_error($term)){
            if(in_array($term->slug, array('nem','nem-hightech','nem-hi-tech'), true)) return 'nem';
            if(in_array($term->slug, array('goi','goi-hightech','goi-hi-tech'), true)) return 'goi';
        }
    }
    $title = isset($item->title) ? $item->title : '';
    $t = function_exists('mb_strtolower') ? mb_strtolower($title) : strtolower($title);
    $high = (strpos($t,'hightech')!==false || strpos($t,'high-tech')!==false || strpos($t,'high tech')!==false);
    if($high){
        if(strpos($t,'nệm')!==false || strpos($t,'nem')!==false) return 'nem';
        if(strpos($t,'gối')!==false || strpos($t,'goi')!==false) return 'goi';
    }
    return '';
}
/* Walker menu tuỳ biến: giữ hiệu ứng mega kể cả khi người dùng tự tạo/sắp xếp menu trong Giao diện → Thiết lập Menu */
if(class_exists('Walker_Nav_Menu')):
class PowerX_Nav_Walker extends Walker_Nav_Menu {
    public function start_el(&$output, $item, $depth=0, $args=null, $id=0){
        $mega='';
        if((int)$depth===0){
            $type = powerx_mega_type_for_item($item);
            if($type){
                $mega = powerx_mega_by_type($type);
                if($mega){ if(!is_array($item->classes)) $item->classes=array(); $item->classes[]='px-has-mega'; }
            }
        }
        parent::start_el($output, $item, $depth, $args, $id);
        if($mega){
            $output .= '<button type="button" class="px-mega-toggle" aria-label="Mở danh mục">+</button>'.$mega;
        }
    }
}
endif;

function powerx_fallback_menu(){
    echo '<ul>';
    $qn=get_page_by_path('quiz-nem'); $qn_url = $qn?get_permalink($qn):'';
    $nem = powerx_mega_by_type('nem');
    echo '<li class="'.($nem?'px-has-mega':'').'"><a href="'.esc_url(powerx_cat_url(array('nem-hightech','nem','nem-hi-tech'))).'">Nệm Hightech</a>'.($nem?'<button type="button" class="px-mega-toggle" aria-label="Mở danh sách nệm">+</button>'.$nem:'').'</li>';
    $goi = powerx_mega_by_type('goi');
    echo '<li class="'.($goi?'px-has-mega':'').'"><a href="'.esc_url(powerx_cat_url(array('goi-hightech','goi','goi-hi-tech'))).'">Gối Hightech</a>'.($goi?'<button type="button" class="px-mega-toggle" aria-label="Mở danh sách gối">+</button>'.$goi:'').'</li>';
    if($qn) echo '<li><a href="'.esc_url($qn_url).'">Tư vấn chọn nệm</a></li>';
    $dt=get_page_by_path('doi-tac'); if($dt) echo '<li><a href="'.esc_url(get_permalink($dt)).'">Đối tác</a></li>';
    $vc=get_page_by_path('ve-chung-toi'); if($vc) echo '<li><a href="'.esc_url(get_permalink($vc)).'">Về chúng tôi</a></li>';
    echo '<li><a href="'.esc_url(home_url('/blog/')).'">Blog</a></li>';
    echo '</ul>';
}

add_action('wp_enqueue_scripts', function(){
    if (function_exists('is_product') && is_product()){
        wp_enqueue_script('powerx-size-picker', get_template_directory_uri().'/js/size-picker.js', array('jquery','wc-add-to-cart-variation'), powerx_asset_ver('js/size-picker.js'), true);
    }
});

/* Tự xoá cache khi bấm "Xuất bản" trong Customizer -> ảnh/nội dung mới hiện ngay (hỗ trợ các plugin cache phổ biến) */
add_action('customize_save_after', function(){
    if (function_exists('wp_cache_flush'))        wp_cache_flush();             // WordPress object cache
    if (function_exists('rocket_clean_domain'))   rocket_clean_domain();        // WP Rocket
    if (function_exists('w3tc_flush_all'))         w3tc_flush_all();             // W3 Total Cache
    if (function_exists('wp_cache_clear_cache'))   wp_cache_clear_cache();       // WP Super Cache
    if (function_exists('wpfc_clear_all_cache'))   wpfc_clear_all_cache(true);   // WP Fastest Cache
    if (function_exists('sg_cachepress_purge_cache')) sg_cachepress_purge_cache(); // SiteGround
    do_action('litespeed_purge_all');             // LiteSpeed Cache
    do_action('cache_enabler_clear_complete_cache'); // Cache Enabler
    do_action('autoptimize_action_cachepurged');  // Autoptimize
});
