<?php if (!defined('ABSPATH')) exit; get_header(); ?>
<article class="px-wrap px-article">
  <?php while(have_posts()): the_post(); ?>
    <div class="px-article-head">
      <span class="px-blog-cat"><?php $c=get_the_category(); echo $c?esc_html($c[0]->name):'Blog'; ?></span>
      <h1><?php the_title(); ?></h1>
      <div class="px-article-meta"><?php echo esc_html(get_the_date()); ?></div>
    </div>
    <?php if(has_post_thumbnail()): ?><div class="px-article-thumb"><?php the_post_thumbnail('large'); ?></div><?php endif; ?>
    <div class="px-article-body"><?php the_content(); ?></div>
  <?php endwhile; ?>
  <div class="px-article-cta">
    <button class="px-btn px-lead-open" data-interest="Từ bài blog">Nhận tư vấn chọn nệm</button>
  </div>
</article>
<?php get_footer(); ?>
