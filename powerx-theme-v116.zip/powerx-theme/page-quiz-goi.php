<?php if (!defined('ABSPATH')) exit; get_header(); ?>
<section class="px-section px-quizpage"><div class="px-wrap">
  <div class="px-quizpage-head">
    <span class="px-eyebrow"><?php echo esc_html(px_opt('powerx_quizgoi_eyebrow','Power X PillowID')); ?></span>
    <h1><?php echo esc_html(px_opt('powerx_quizgoi_h','Tìm chiếc gối hoàn hảo cho bạn')); ?></h1>
    <p><?php echo esc_html(px_opt('powerx_quizgoi_sub','Trả lời vài câu hỏi nhanh — Power X gợi ý dòng gối phù hợp nhất với tư thế ngủ của bạn.')); ?></p>
  </div>
  <div class="px-quizpage-quiz"><?php echo do_shortcode('[powerx_quiz type="pillow"]'); ?></div>
</div></section>
<?php get_footer(); ?>
