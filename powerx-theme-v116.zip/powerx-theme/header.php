<?php if (!defined('ABSPATH')) exit; ?>
<!DOCTYPE html><html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1.0"><?php wp_head(); ?></head>
<body <?php body_class(); ?>>
<?php if (function_exists('wp_body_open')) wp_body_open(); ?>

<div class="px-utility"><div class="px-wrap px-utility-in">
  <span>Tư vấn miễn phí · Bảo hành 10 năm · Giao lắp 24h</span>
  <a href="<?php echo esc_url(get_permalink(get_page_by_path('quiz-nem'))); ?>">★ Làm quiz chọn nệm trong 1 phút</a>
</div></div>

<div class="px-announce">Dùng thử <b>100 ĐÊM</b> · Đổi trả miễn phí — <b>FOR ME · NOT FOR YOU</b></div>

<header class="px-header">
  <div class="px-nav">
    <?php if (has_custom_logo()): ?>
      <div class="px-logo"><?php the_custom_logo(); /* tự kèm link về trang chủ — KHÔNG bọc trong <a> để tránh thẻ a lồng a */ ?></div>
    <?php else: ?>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="px-logo" aria-label="<?php echo esc_attr(get_bloginfo('name').' — Trang chủ'); ?>">
        <span class="px-logo-default"><?php echo powerx_default_logo('dark'); ?></span>
      </a>
    <?php endif; ?>
    <nav class="px-menu">
      <?php $px_menu_args=array('theme_location'=>'primary','container'=>false,'fallback_cb'=>'powerx_fallback_menu','depth'=>2);
      if(class_exists('PowerX_Nav_Walker')) $px_menu_args['walker']=new PowerX_Nav_Walker();
      wp_nav_menu($px_menu_args); ?>
    </nav>
    <div class="px-nav-left">
      <button class="px-burger" aria-label="Menu" onclick="document.querySelector('.px-menu').classList.toggle('open')"><span></span><span></span><span></span></button>
      <div class="px-search-wrap" data-open="false">
        <button type="button" class="px-search-btn" aria-label="Tìm kiếm" aria-expanded="false"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg></button>
        <form class="px-search" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
          <input type="search" name="s" placeholder="Tìm kiếm sản phẩm…" aria-label="Tìm kiếm">
          <input type="hidden" name="post_type" value="product">
          <button type="submit" aria-label="Tìm kiếm"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg></button>
        </form>
      </div>
      <?php if (function_exists('powerx_lang_switcher')) echo powerx_lang_switcher(); ?>
    </div>
    <div class="px-nav-right">
      <?php $px_acc = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : ''; if($px_acc): ?>
      <a class="px-acc" href="<?php echo esc_url($px_acc); ?>" title="Tài khoản" aria-label="Tài khoản">
        <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>
      </a>
      <?php endif; ?>
      <?php if (function_exists('wc_get_cart_url')): ?>
      <a class="px-cart" href="<?php echo esc_url(wc_get_cart_url()); ?>" title="Giỏ hàng" aria-label="Giỏ hàng">
        <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 4h2l2.4 12.4a1 1 0 0 0 1 .8h8.7a1 1 0 0 0 1-.8L21 7H6"/><circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/></svg>
        <span class="c"><?php echo esc_html(powerx_cart_count()); ?></span>
      </a>
      <?php endif; ?>
    </div>
  </div>
</header>
<main id="px-main">
