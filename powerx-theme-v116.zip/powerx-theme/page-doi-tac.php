<?php if (!defined('ABSPATH')) exit; get_header(); ?>
<section class="px-section"><div class="px-wrap">
  <div class="px-sec-head" style="text-align:center">
    <span class="px-eyebrow"><?php echo esc_html(px_opt('powerx_partners_eyebrow','HỆ THỐNG ĐẠI LÝ')); ?></span>
    <h2><?php echo esc_html(px_opt('powerx_partners_title','Đối tác & Đại lý Power X')); ?></h2>
    <p style="max-width:620px;margin:8px auto 0;color:var(--muted)"><?php echo esc_html(px_opt('powerx_partners_lead','Ghé các đại lý dưới đây để nằm thử trực tiếp sản phẩm Power X.')); ?></p>
  </div>

  <div class="px-partners-grid">
    <?php
    $any=false;
    for($i=1;$i<=6;$i++):
      $name = px_opt("powerx_partner{$i}_name",'');
      if(trim($name)==='') continue;
      $any=true;
      $addr = px_opt("powerx_partner{$i}_addr",'');
      $phone= px_opt("powerx_partner{$i}_phone",'');
      $pimg = px_opt("powerx_partner{$i}_img",'');
      $pmap = px_opt("powerx_partner{$i}_map",'');
      if(trim($pmap)==='' && trim($addr)!==''){
          $pmap = 'https://www.google.com/maps/search/?api=1&query='.rawurlencode($name.', '.trim(preg_replace('/\s+/',' ',$addr)));
      }
    ?>
      <div class="px-partner">
        <div class="px-partner-img<?php echo $pimg?'':' is-empty'; ?>">
          <?php if($pimg): ?><img src="<?php echo esc_url($pimg); ?>" alt="<?php echo esc_attr($name); ?>" loading="lazy"><?php else: ?><span>POWER<b>X</b></span><?php endif; ?>
        </div>
        <div class="px-partner-body">
          <h3><?php echo esc_html($name); ?></h3>
          <?php if($addr): ?>
          <p class="px-partner-addr">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 1 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            <span><?php echo nl2br(esc_html($addr)); ?></span>
          </p>
          <?php endif; ?>
          <?php if($phone): ?>
          <a class="px-partner-phone" href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$phone)); ?>">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.1-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.5 2.7.6a2 2 0 0 1 1.7 2z"/></svg>
            <?php echo esc_html($phone); ?>
          </a>
          <?php endif; ?>
          <?php if($pmap): ?>
          <a class="px-partner-map" href="<?php echo esc_url($pmap); ?>" target="_blank" rel="noopener noreferrer">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 1 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            Chỉ đường trên Google Maps
          </a>
          <?php endif; ?>
        </div>
      </div>
    <?php endfor; ?>
    <?php if(!$any): ?><p style="text-align:center;color:var(--muted)">Chưa có đại lý nào. Thêm trong Tùy biến → Power X — Giới thiệu & Đối tác.</p><?php endif; ?>
  </div>

  <div style="text-align:center;margin-top:36px">
    <p style="color:var(--muted);margin-bottom:14px">Bạn muốn trở thành đại lý Power X?</p>
    <button class="px-btn px-lead-open" data-interest="Đăng ký đại lý">Đăng ký hợp tác</button>
  </div>
</div></section>
<?php get_footer(); ?>
