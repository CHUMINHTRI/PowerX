/** Power X — Size picker v6: sync với select (ẩn) của WC. Đảm bảo Add to Cart hoạt động */
(function(){
  function init(form){
    if(!window.jQuery){ console.warn('PowerX size picker cần jQuery'); return; }
    var $form = jQuery(form);
    var raw = form.getAttribute('data-product_variations'); if(!raw) return;
    var data; try{ data = JSON.parse(raw); }catch(e){ return; }

    form.querySelectorAll('.px-size-grid').forEach(function(grid){
      var attrName = grid.getAttribute('data-attr');
      var $select = $form.find('select[name="'+attrName+'"]');
      if(!$select.length) return;

      // map value -> {pricetext, inStock}
      var info = {};
      data.forEach(function(v){
        if(v.attributes && v.attributes[attrName]!=null){
          var val = v.attributes[attrName] + '';
          // Lấy text gọn nhất từ price_html (đã được WC định dạng đúng)
          var tmp = document.createElement('div'); tmp.innerHTML = v.price_html || '';
          // chọn giá cuối (sale) nếu có <ins>
          var ins = tmp.querySelector('ins'); var priceText = ins ? ins.textContent.trim() : tmp.textContent.trim();
          info[val] = { price:parseFloat(v.display_price)||0, inStock:!!v.is_in_stock, text: priceText };
        }
      });

      // Gắn giá lên mỗi nút + đánh dấu hết hàng
      grid.querySelectorAll('.px-size-btn').forEach(function(btn){
        var val = btn.getAttribute('data-value');
        var meta = info[val]; if(!meta) return;
        btn.querySelector('.pr').textContent = meta.text;
        if(!meta.inStock){ btn.classList.add('oos'); btn.setAttribute('title','Tạm hết hàng'); }
      });

      // Mặc định: size thấp nhất CÒN HÀNG
      var pre = $select.val();
      if(!pre || !info[pre] || !info[pre].inStock){
        var lowest=null;
        Object.keys(info).forEach(function(k){
          if(!info[k].inStock) return;
          if(lowest===null || info[k].price < info[lowest].price) lowest=k;
        });
        if(lowest){ $select.val(lowest).trigger('change'); }
      }

      // Đánh dấu nút active theo giá trị hiện tại
      function syncActive(){
        var cur = $select.val()||'';
        grid.querySelectorAll('.px-size-btn').forEach(function(b){
          if(b.getAttribute('data-value')===cur) b.setAttribute('aria-pressed','true');
          else b.removeAttribute('aria-pressed');
        });
      }
      syncActive();
      $select.on('change', syncActive);

      // Click nút -> đổi select.val() và trigger change (WC sẽ tự cập nhật giá + nút Add to Cart)
      grid.addEventListener('click', function(e){
        var btn = e.target.closest('.px-size-btn'); if(!btn || btn.classList.contains('oos')) return;
        var v = btn.getAttribute('data-value');
        $select.val(v).trigger('change');
      });
    });

    // Trigger initial check
    setTimeout(function(){ $form.trigger('check_variations'); }, 60);
  }

  function ready(fn){ if(document.readyState!=='loading'){fn();} else{document.addEventListener('DOMContentLoaded',fn);} }
  ready(function(){ document.querySelectorAll('form.variations_form').forEach(init); });

  /* ===== Video sản phẩm trong gallery: bấm cover -> phát ===== */
  function pxPlayVideo(slide){
    if(!slide) return;
    var embed=slide.querySelector('.px-video-embed'), cover=slide.querySelector('.px-video-cover');
    if(!embed) return;
    var iframe=embed.querySelector('iframe[data-src]');
    if(iframe){ var s=iframe.getAttribute('data-src'); iframe.src=s+(s.indexOf('?')>-1?'&':'?')+'autoplay=1'; iframe.removeAttribute('data-src'); }
    var vid=embed.querySelector('video'); if(vid){ try{ vid.play(); }catch(e){} }
    slide.classList.add('px-video-playing');
    if(cover) cover.style.display='none';
  }
  document.addEventListener('click', function(e){
    var c=e.target.closest ? e.target.closest('.px-video-cover') : null;
    if(c){ e.preventDefault(); e.stopPropagation(); pxPlayVideo(c.closest('.px-product-video, .px-video-slide')); }
  });
})();
