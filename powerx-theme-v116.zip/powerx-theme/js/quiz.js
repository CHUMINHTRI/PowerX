(function(){
  // Quiz dữ liệu chuẩn theo tài liệu Power X mới
  var QUIZ = {
    mattress: {
      title:"Tư vấn chọn nệm Power X",
      questions:[
        {q:"Lifestyle nào mô tả bạn nhất?",a:[
          {t:"Doanh nhân / gia đình hiện đại — đầu tư nghiêm túc cho giấc ngủ",s:{PRM:3}},
          {t:"Vận động viên / năng động — cần phục hồi nhanh",s:{FUS:3}},
          {t:"Hay nóng lưng / cặp đôi — muốn ngủ mát êm",s:{FLW:3}},
          {t:"Người trẻ / lifestyle tối giản — giá hợp lý",s:{COR:3}} ]},
        {q:"Tư thế ngủ chính?",a:[
          {t:"Nằm nghiêng",s:{FLW:2,FUS:1,PRM:1}},
          {t:"Nằm ngửa",s:{PRM:2,FUS:1,COR:1}},
          {t:"Nằm sấp / nằm chắc",s:{COR:2}},
          {t:"Hay đổi tư thế",s:{FUS:2,PRM:1}} ]},
        {q:"Độ cứng bạn thích?",a:[
          {t:"Êm — ôm sát cơ thể",s:{FLW:2}},
          {t:"Medium — cân bằng",s:{FUS:2,PRM:2}},
          {t:"Medium-Firm — hơi chắc",s:{FLW:2,FUS:1}},
          {t:"Firm — chắc chắn",s:{COR:2,PRM:1}} ]},
        {q:"Điều bạn quan tâm nhất?",a:[
          {t:"Nâng đỡ chuẩn cột sống / phục hồi sâu",s:{PRM:2,FUS:1}},
          {t:"Mát lạnh, hết nóng lưng",s:{FLW:2,FUS:1}},
          {t:"Bạn cùng giường trở mình",s:{PRM:2,FUS:2}},
          {t:"Tối ưu chi phí, dễ vệ sinh",s:{COR:2}} ]}
      ],
      products:{
        PRM:{name:"Power X Prime",tagline:"Prime Level. Sleep Like a Pro.",desc:"Hybrid Graphene + lò xo kép — đẳng cấp, phục hồi sâu cho người thành đạt.",price:"từ 23.598.000₫"},
        FUS:{name:"Power X Fusion",tagline:"Recover Fast. Play Hard.",desc:"Hybrid + lò xo túi 11 vùng — cân bằng êm ái và đàn hồi, hồi phục cho người năng động.",price:"từ 16.198.000₫"},
        FLW:{name:"Power X Flow",tagline:"Flow Mode: Stay Cool, Stay Sharp.",desc:"Foam Graphene Memory + vỏ Tencel — mát lạnh, êm ái, lý tưởng cho cặp đôi.",price:"từ 9.398.000₫"},
        COR:{name:"Power X Core",tagline:"Cool Sleep. Core Power.",desc:"Foam Baby Air 2 mặt — tối giản, thoáng khí, lifestyle trẻ trung.",price:"từ 6.398.000₫"}
      }
    },
    pillow:{
      title:"Tư vấn chọn gối Power X",
      questions:[
        {q:"Bạn cần gì nhất từ gối?",a:[
          {t:"Định hình ôm cổ gáy chuẩn",s:{ERG:3}},
          {t:"Êm thoáng, đa tư thế",s:{MTX:3}} ]},
        {q:"Vấn đề bạn hay gặp?",a:[
          {t:"Mỏi cổ vai gáy",s:{ERG:2,MTX:2}},
          {t:"Nóng, bí khi ngủ",s:{MTX:2}} ]},
        {q:"Tư thế ngủ?",a:[
          {t:"Cố định nghiêng / ngửa",s:{ERG:2}},
          {t:"Hay xoay người",s:{MTX:2}} ]}
      ],
      products:{
        ERG:{name:"Power X Ergo",tagline:"Ergo Support. Wake Up Sharp.",desc:"Gối định hình CNC, foam nhớ 40D — ôm sát cổ gáy.",price:"1.198.000₫"},
        MTX:{name:"Power X Matrix",tagline:"Balance. Comfort. Recovery.",desc:"Gối CNC kép Memory 40D + Baby 25D — êm thoáng, đa tư thế.",price:"2.198.000₫"}
      }
    }
  };

  function el(h){var d=document.createElement('div');d.innerHTML=h.trim();return d.firstChild;}
  function shopSearch(n){return (PowerX.shop||'/')+'?s='+encodeURIComponent(n)+'&post_type=product';}

  function renderQuiz(mount){
    var type=mount.getAttribute('data-type')||'mattress', data=QUIZ[type]; if(!data) return;
    var step=0, scores={};
    function show(){
      mount.innerHTML='';
      if(step<data.questions.length){
        var Q=data.questions[step], prog=Math.round(step/data.questions.length*100);
        var box=el('<div class="px-quiz-card"></div>');
        box.appendChild(el('<div class="px-quiz-bar"><span style="width:'+prog+'%"></span></div>'));
        box.appendChild(el('<div class="px-quiz-step">Câu '+(step+1)+'/'+data.questions.length+'</div>'));
        box.appendChild(el('<h3 class="px-quiz-q">'+Q.q+'</h3>'));
        var opts=el('<div class="px-quiz-opts"></div>');
        Q.a.forEach(function(opt){
          var b=el('<button class="px-quiz-opt">'+opt.t+'</button>');
          b.onclick=function(){ for(var k in opt.s) scores[k]=(scores[k]||0)+opt.s[k]; step++; show(); };
          opts.appendChild(b);
        });
        box.appendChild(opts); mount.appendChild(box);
      } else {
        var best=null,bv=-1; for(var k in data.products){var v=scores[k]||0; if(v>bv){bv=v;best=k;}}
        var p=data.products[best];
        var box=el('<div class="px-quiz-card px-quiz-result"></div>');
        box.appendChild(el('<div class="px-quiz-step" style="color:var(--lime-deep)">Gợi ý cho bạn</div>'));
        box.appendChild(el('<h3 class="px-quiz-q">'+p.name+'</h3>'));
        box.appendChild(el('<div class="px-quiz-tagline">'+p.tagline+'</div>'));
        box.appendChild(el('<p class="px-quiz-desc">'+p.desc+'</p>'));
        box.appendChild(el('<div class="px-quiz-price">'+p.price+'</div>'));
        var row=el('<div class="px-quiz-cta"></div>');
        row.appendChild(el('<a class="px-btn" href="'+shopSearch(p.name)+'">Xem sản phẩm</a>'));
        row.appendChild(el('<button class="px-btn px-btn-ghost px-lead-open" data-interest="Quiz: '+p.name+'">Nhận tư vấn &amp; báo giá</button>'));
        box.appendChild(row);
        var again=el('<button class="px-quiz-again">Làm lại</button>'); again.onclick=function(){step=0;scores={};show();};
        box.appendChild(again);
        mount.appendChild(box); openPopup('Quiz: '+p.name);
      }
    }
    show();
  }

  // Popup
  var popup;
  function buildPopup(){
    popup=el('<div class="px-popup" role="dialog" aria-modal="true"><div class="px-popup-box">\
      <button class="px-popup-x" aria-label="Đóng">&times;</button>\
      <h3>Nhận tư vấn miễn phí từ Power X</h3>\
      <p>Để lại thông tin, đội ngũ Power X sẽ liên hệ tư vấn &amp; báo giá tốt nhất.</p>\
      <form class="px-lead-form">\
        <input name="name" placeholder="Họ và tên *" required>\
        <input name="phone" placeholder="Số điện thoại *" required>\
        <input name="email" placeholder="Email (tuỳ chọn)">\
        <textarea name="note" placeholder="Ghi chú (tuỳ chọn)"></textarea>\
        <input type="hidden" name="interest" value="">\
        <button type="submit" class="px-btn">Gửi thông tin</button>\
        <div class="px-lead-msg"></div></form></div></div>');
    document.body.appendChild(popup);
    popup.querySelector('.px-popup-x').onclick=closePopup;
    popup.addEventListener('click',function(e){if(e.target===popup)closePopup();});
    popup.querySelector('.px-lead-form').addEventListener('submit',submitLead);
  }
  function openPopup(interest){if(!popup)buildPopup(); popup.querySelector('[name=interest]').value=interest||'Tư vấn chung'; popup.classList.add('open');}
  function closePopup(){if(popup)popup.classList.remove('open');}
  function submitLead(e){
    e.preventDefault(); var f=e.target, msg=f.querySelector('.px-lead-msg'), btn=f.querySelector('button[type=submit]');
    var fd=new FormData(f); fd.append('action','powerx_lead'); fd.append('nonce',PowerX.nonce);
    btn.disabled=true; msg.textContent='Đang gửi...';
    fetch(PowerX.ajax,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(j){
      msg.style.color=j.success?'#2e7d00':'#A81E2E'; msg.textContent=(j.data&&j.data.msg)||'Hoàn tất';
      if(j.success){ f.reset(); setTimeout(closePopup,2200); } else { btn.disabled=false; }
    }).catch(function(){msg.style.color='#A81E2E'; msg.textContent='Lỗi kết nối, thử lại.'; btn.disabled=false;});
  }
  document.addEventListener('DOMContentLoaded',function(){
    document.querySelectorAll('.px-quiz').forEach(renderQuiz);
    document.addEventListener('click',function(e){var t=e.target.closest('.px-lead-open'); if(t){e.preventDefault(); openPopup(t.getAttribute('data-interest'));}});
    document.addEventListener('click',function(e){
      var mt=e.target.closest('.px-mega-toggle'); if(!mt) return;
      e.preventDefault();
      var li=mt.closest('.px-has-mega'); if(!li) return;
      var open=li.classList.toggle('is-open');
      mt.textContent = open ? '–' : '+';
    });
    // Desktop: hover-intent giữ panel mega mở khi rê chuột xuống panel
    document.querySelectorAll('.px-has-mega').forEach(function(li){
      var t;
      li.addEventListener('mouseenter',function(){ if(window.innerWidth>1240){ clearTimeout(t); li.classList.add('is-open'); } });
      li.addEventListener('mouseleave',function(){ if(window.innerWidth>1240){ t=setTimeout(function(){ li.classList.remove('is-open'); },140); } });
    });
    // Giỏ hàng trượt (drawer) kiểu Bedgear
    (function(){
      var dr=document.getElementById('px-cartdrawer'); if(!dr) return;
      var content=dr.querySelector('.px-cd-content');
      function setCounts(n){ document.querySelectorAll('.px-cart .c,.px-cd-count').forEach(function(e){ e.textContent=n; }); }
      function open(){ dr.classList.add('is-open'); document.body.classList.add('px-noscroll'); refresh(); }
      function close(){ dr.classList.remove('is-open'); document.body.classList.remove('px-noscroll'); }
      function req(params){
        var fd=new FormData(); fd.append('action','powerx_cart'); for(var k in params) fd.append(k,params[k]);
        dr.classList.add('is-loading');
        return fetch(PowerX.ajax,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
          dr.classList.remove('is-loading');
          if(j&&j.success){ content.innerHTML=j.data.html; setCounts(j.data.count); }
        }).catch(function(){ dr.classList.remove('is-loading'); });
      }
      function refresh(){ req({act:'get'}); }
      document.querySelectorAll('.px-cart').forEach(function(c){ c.addEventListener('click',function(e){ e.preventDefault(); open(); }); });
      dr.querySelector('.px-cartdrawer-overlay').addEventListener('click',close);
      dr.querySelector('.px-cartdrawer-x').addEventListener('click',close);
      document.addEventListener('keydown',function(e){ if(e.key==='Escape' && dr.classList.contains('is-open')) close(); });
      content.addEventListener('click',function(e){
        var plus=e.target.closest('.px-cd-plus'), minus=e.target.closest('.px-cd-minus'), rem=e.target.closest('.px-cd-remove');
        if(!plus && !minus && !rem) return;
        e.preventDefault();
        var item=e.target.closest('.px-cd-item'); if(!item) return;
        var key=item.getAttribute('data-key');
        var cur=parseInt((item.querySelector('.px-cd-num')||{}).textContent,10)||1;
        if(rem){ req({act:'remove',key:key}); }
        else { req({act:'set',key:key,qty:(plus?cur+1:cur-1)}); }
      });
    })();
    // Trang chi tiết SP: gallery tuỳ biến (ảnh + video) — bấm ô video là tự phát
    (function(){
      var gal=document.querySelector('.px-gallery'); if(!gal) return;
      var mains=gal.querySelectorAll('.px-gmain-item');
      var thumbs=gal.querySelectorAll('.px-gthumb');
      function play(v){
        if(!v) return;
        var box=v.querySelector('.px-gvideo-embed')||v;      // chỉ thao tác video THẬT trong khung phát, không phải video-bìa
        var f=box.querySelector('iframe'); var vid=box.querySelector('video');
        if(f && !f.src){ var s=f.getAttribute('data-src')||''; if(s) f.src = s + (s.indexOf('?')>-1?'&':'?') + 'autoplay=1'; }
        v.classList.add('is-playing');
        if(vid){ try{ vid.muted=false; vid.currentTime=0; var p=vid.play(); if(p&&p.catch) p.catch(function(){}); }catch(e){} }
      }
      function activate(idx,autoplay){
        mains.forEach(function(m){ m.classList.toggle('is-active', m.getAttribute('data-idx')==idx); });
        thumbs.forEach(function(t){ t.classList.toggle('is-active', t.getAttribute('data-idx')==idx); });
        var main=gal.querySelector('.px-gmain-item[data-idx="'+idx+'"]');
        if(autoplay && main){ play(main.querySelector('.px-gvideo')); }
      }
      thumbs.forEach(function(t){ t.addEventListener('click',function(){ activate(t.getAttribute('data-idx'), true); }); });
      // bấm trực tiếp vào khung video lớn cũng phát ngay
      gal.querySelectorAll('.px-gvideo .px-gvideo-cover').forEach(function(cover){
        cover.addEventListener('click',function(){ play(cover.closest('.px-gvideo')); });
      });
    })();
    // Trang chi tiết SP: accordion thông tin (chỉ mở 1 mục — mở cái này thì cái khác tự đóng)
    document.querySelectorAll('.px-pacc').forEach(function(acc){
      acc.querySelectorAll('.px-pacc-head').forEach(function(h){
        h.addEventListener('click',function(){
          var item=h.parentNode;
          var willOpen=!item.classList.contains('is-open');
          acc.querySelectorAll('.px-pacc-item').forEach(function(it){ it.classList.remove('is-open'); });
          if(willOpen) item.classList.add('is-open');
        });
      });
    });
    // Trang chi tiết SP: thanh CTA dính đáy
    (function(){
      var bar=document.getElementById('px-stickybar'); if(!bar) return;
      var form=document.querySelector('.px-single .summary form.cart, .px-single .summary .cart');
      var realBtn=document.querySelector('.px-single .summary .single_add_to_cart_button');
      function onScroll(){
        var show=false;
        if(form){ var r=form.getBoundingClientRect(); show = r.bottom < 80; }
        else { show = window.scrollY > 600; }
        bar.classList.toggle('is-on', show);
      }
      window.addEventListener('scroll',onScroll,{passive:true}); window.addEventListener('resize',onScroll); onScroll();
      var add=bar.querySelector('.px-stickybar-add');
      if(add) add.addEventListener('click',function(){
        var btn=document.querySelector('.px-single .summary .single_add_to_cart_button:not(.disabled)');
        if(btn){ btn.click(); }
        else if(form){ form.scrollIntoView({behavior:'smooth',block:'center'}); }
        else { window.scrollTo({top:0,behavior:'smooth'}); }
      });
    })();
    // Cửa hàng: mở/đóng panel lọc trên mobile + accordion từng nhóm
    (function(){
      var panel=document.getElementById('px-shop-filters');
      var toggle=document.querySelector('.px-filter-toggle');
      if(panel && toggle){
        var open=function(){ panel.classList.add('is-open'); document.body.classList.add('px-noscroll'); };
        var close=function(){ panel.classList.remove('is-open'); document.body.classList.remove('px-noscroll'); };
        toggle.addEventListener('click',open);
        var x=panel.querySelector('.px-filter-close'); if(x) x.addEventListener('click',close);
        panel.addEventListener('click',function(e){ if(e.target===panel) close(); });
      }
      document.querySelectorAll('.px-fgroup-head').forEach(function(h){
        h.addEventListener('click',function(){ h.parentNode.classList.toggle('is-open'); });
      });
    })();
    // Carousel phản hồi khách hàng (mũi tên trái/phải)
    (function(){
      var track=document.getElementById('px-reviews-track'); if(!track) return;
      var arrows=document.querySelectorAll('.px-rev-arrow');
      function step(){ var c=track.querySelector('.px-review'); return c?(c.getBoundingClientRect().width+22):360; }
      arrows.forEach(function(a){ a.addEventListener('click',function(){ track.scrollBy({left:step()*(parseInt(a.getAttribute('data-dir'),10)||1),behavior:'smooth'}); }); });
      function sync(){ var max=track.scrollWidth-track.clientWidth-2; var prev=document.querySelector('.px-rev-arrow[data-dir="-1"]'), next=document.querySelector('.px-rev-arrow[data-dir="1"]');
        if(prev) prev.disabled = track.scrollLeft<=2; if(next) next.disabled = track.scrollLeft>=max; }
      track.addEventListener('scroll',sync); window.addEventListener('resize',sync); sync();
    })();
    // Footer: đăng ký nhận tin -> lưu vào KH tiềm năng
    document.querySelectorAll('.px-news-form').forEach(function(f){
      f.addEventListener('submit',function(e){
        e.preventDefault();
        var inp=f.querySelector('input[type=email]'); var email=inp?inp.value.trim():'';
        var msg=f.querySelector('.px-news-msg'), btn=f.querySelector('button'); if(!email) return;
        var fd=new FormData(); fd.append('action','powerx_lead'); fd.append('nonce',PowerX.nonce);
        fd.append('name','Đăng ký nhận tin'); fd.append('phone',email); fd.append('email',email); fd.append('interest','Newsletter (footer)');
        if(btn) btn.disabled=true; if(msg){msg.style.color='#cfcfcf';msg.textContent='Đang gửi...';}
        fetch(PowerX.ajax,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(j){
          if(msg){ msg.style.color=j.success?'#C3FF00':'#ff8a8a'; msg.textContent=j.success?'Cảm ơn! Bạn đã đăng ký nhận tin.':((j.data&&j.data.msg)||'Có lỗi, thử lại.'); }
          if(j.success) f.reset(); if(btn) btn.disabled=false;
        }).catch(function(){ if(msg){msg.style.color='#ff8a8a';msg.textContent='Lỗi kết nối.';} if(btn) btn.disabled=false; });
      });
    });
  });

  /* Xem thêm đánh giá */
  document.addEventListener('click', function(e){
    var b = e.target.closest && e.target.closest('.px-rs-more');
    if(!b) return;
    var list = b.previousElementSibling;
    if(list && list.classList.contains('px-rs-list')){
      list.querySelectorAll('.px-rv--more').forEach(function(el){ el.hidden=false; });
    }
    b.remove();
  });
})();

/* ===== Ô tìm kiếm thu gọn thành icon, bấm để xổ ra ===== */
(function(){
  document.addEventListener('click', function(e){
    var btn = e.target.closest && e.target.closest('.px-search-btn');
    var openWrap = document.querySelector('.px-search-wrap[data-open="true"]');
    if(btn){
      var wrap = btn.closest('.px-search-wrap');
      var isOpen = wrap.getAttribute('data-open')==='true';
      wrap.setAttribute('data-open', isOpen?'false':'true');
      btn.setAttribute('aria-expanded', isOpen?'false':'true');
      if(!isOpen){ var inp = wrap.querySelector('input[type=search]'); if(inp) setTimeout(function(){inp.focus();},30); }
      e.preventDefault(); return;
    }
    if(openWrap && !e.target.closest('.px-search')){
      openWrap.setAttribute('data-open','false');
      var b=openWrap.querySelector('.px-search-btn'); if(b) b.setAttribute('aria-expanded','false');
    }
  });
  document.addEventListener('keydown', function(e){
    if(e.key==='Escape'){ var w=document.querySelector('.px-search-wrap[data-open="true"]'); if(w){ w.setAttribute('data-open','false'); var b=w.querySelector('.px-search-btn'); if(b) b.setAttribute('aria-expanded','false'); } }
  });
})();

/* ===== Dropdown chọn ngôn ngữ (cờ) ===== */
(function(){
  document.addEventListener('click', function(e){
    var cur = e.target.closest && e.target.closest('.px-lang-cur');
    var open = document.querySelector('.px-lang[data-open="true"]');
    if(cur){
      var wrap = cur.closest('.px-lang');
      var isOpen = wrap.getAttribute('data-open')==='true';
      if(open && open!==wrap){ open.setAttribute('data-open','false'); open.querySelector('.px-lang-cur').setAttribute('aria-expanded','false'); }
      wrap.setAttribute('data-open', isOpen?'false':'true');
      cur.setAttribute('aria-expanded', isOpen?'false':'true');
      e.preventDefault(); return;
    }
    if(open && !e.target.closest('.px-lang-menu')){
      open.setAttribute('data-open','false');
      open.querySelector('.px-lang-cur').setAttribute('aria-expanded','false');
    }
  });
})();

/* ===== Trang chi tiết: đưa giá biến thể (gốc + sau giảm) lên ô "từ ..." ===== */
(function(){
  if(!window.jQuery) return;
  jQuery(function($){
    var $form = $('.single-product form.variations_form');
    if(!$form.length) return;
    var $price = $('.single-product div.product .summary p.price').first();
    if(!$price.length) return;
    var orig = $price.html();
    $form.on('found_variation', function(e, v){
      if(v && v.price_html){ $price.html(v.price_html); }
      else if(v){
        var sale = parseFloat(v.display_price), reg = parseFloat(v.display_regular_price);
        $price.html(reg>sale ? '<del>'+fmt(reg)+'</del> <ins>'+fmt(sale)+'</ins>' : fmt(sale));
      }
    });
    $form.on('reset_data', function(){ $price.html(orig); });
    function fmt(n){
      if(isNaN(n)) return '';
      return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g,'.') + ' ₫';
    }
  });
})();
