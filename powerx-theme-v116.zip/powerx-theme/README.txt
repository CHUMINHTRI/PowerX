========================================
POWER X — WordPress/WooCommerce Theme v1.0
========================================

YÊU CẦU
- WordPress 6.0+ và PHP 7.4+
- Đã cài & kích hoạt plugin WooCommerce

----------------------------------------
1) CÀI ĐẶT THEME (chỉ 1 file, không cần theme cha)
----------------------------------------
1. Đăng nhập trang quản trị: tenmiencuaban/wp-admin
2. Vào: Giao diện (Appearance) -> Giao diện -> Thêm mới -> Tải giao diện lên
3. Chọn file: powerx-theme.zip -> Cài đặt ngay -> Kích hoạt
4. Trang chủ tự động dùng mẫu Power X (hero + sản phẩm + thương hiệu).

----------------------------------------
2) CÀI WOOCOMMERCE (nếu chưa có)
----------------------------------------
Plugin (Plugins) -> Cài mới -> tìm "WooCommerce" -> Cài đặt -> Kích hoạt
-> chạy trình hướng dẫn (tiền tệ VND, địa chỉ cửa hàng...).

----------------------------------------
3) LOGO & MENU
----------------------------------------
- Logo: Giao diện -> Tùy biến -> Nhận diện trang web -> Logo (nếu không đặt, theme dùng chữ "POWER X").
- Menu: Giao diện -> Menu -> tạo menu -> gán vị trí "Menu chính".

----------------------------------------
4) NHẬP SẢN PHẨM (Nệm, Gối)
----------------------------------------
Sản phẩm -> Tất cả sản phẩm -> Nhập (Import) -> chọn file CSV
(xuất từ sheet "3. Import sản phẩm" trong file Excel: PowerX_Web_Trien_khai.xlsx).

----------------------------------------
5) TẠO TÀI KHOẢN & PHÂN QUYỀN  (tính năng SẴN CÓ của WordPress)
----------------------------------------
Theme KHÔNG chứa admin panel riêng — WordPress đã có sẵn:
- Tạo tài khoản: Người dùng (Users) -> Thêm mới -> nhập thông tin -> chọn Vai trò -> Thêm người dùng.
- Các vai trò có sẵn:
    * Quản trị viên (Administrator) : toàn quyền.
    * Quản lý cửa hàng (Shop manager): WooCommerce tạo sẵn — quản lý sản phẩm/đơn hàng, KHÔNG sửa được hệ thống.
    * Biên tập (Editor) / Tác giả (Author): quản lý nội dung.
    * Khách hàng (Customer): tài khoản mua hàng.
    * "Power X – Nhân viên bán hàng": vai trò MẪU do theme tự tạo (thêm/sửa sản phẩm, tải ảnh).
- Đổi vai trò người dùng: Người dùng -> chọn người -> đổi "Vai trò" -> Cập nhật.

CHỈNH QUYỀN CHI TIẾT (bật/tắt từng quyền):
  Cài plugin miễn phí "Members" (Plugins -> Cài mới -> tìm "Members" của MemberPress)
  -> Members -> Roles: chỉnh từng quyền cho từng vai trò bằng giao diện tích chọn.

----------------------------------------
6) THANH TOÁN
----------------------------------------
- Trước khi bật MoMo/VNPay chạy thật: hoàn tất ĐĂNG KÝ BỘ CÔNG THƯƠNG.
- VNPay: đăng ký sandbox -> ký hợp đồng merchant -> cài plugin VNPay -> cấu hình.
- MoMo: đăng ký business.momo.vn (cần GPKD) -> cài plugin MoMo -> cấu hình.
- Chuyển khoản/QR: WooCommerce -> Cài đặt -> Thanh toán -> bật "Bank transfer (BACS)";
  thêm plugin VietQR nếu muốn tạo mã QR tự động theo đơn.

----------------------------------------
GỠ LỖI NHANH
----------------------------------------
- "Theme cha bị thiếu": KHÔNG xảy ra — đây là theme standalone.
- Sản phẩm không hiện ngoài trang chủ: kiểm tra WooCommerce đã kích hoạt và đã có sản phẩm.
- Trang chủ chưa đúng: Cài đặt -> Đọc -> để "Trang chủ hiển thị: Bài viết mới nhất"
  (theme tự nạp mẫu Power X qua front-page.php).

========================================
v2.0 — BỐ CỤC CASPER + QUIZ + POPUP + BLOG
========================================
Khi KÍCH HOẠT theme, hệ thống tự tạo 1 lần:
- Trang "Tư vấn chọn nệm" (/quiz-nem) và "Tư vấn chọn gối" (/quiz-goi) — chứa quiz tương tác.
- Trang "So sánh nệm" (/so-sanh-nem) — bảng so sánh 4 dòng.
- 4 chuyên mục blog: Sản phẩm · Câu chuyện giấc ngủ · Ngủ ngon · Power X.
- 5 bài blog mẫu (đã đăng).
- Đặt Trang chủ = mẫu Power X, tạo trang Blog (/blog).
*Nếu muốn chạy lại seeding: xóa tùy chọn 'powerx_seeded' trong DB rồi kích hoạt lại theme.

QUIZ
- Nhúng ở bất kỳ trang nào bằng shortcode: [powerx_quiz type="mattress"] hoặc [powerx_quiz type="pillow"].
- Kết thúc quiz sẽ TỰ bật popup lấy thông tin khách.

POPUP LẤY THÔNG TIN (LEAD)
- Mở popup từ bất kỳ nút nào có class "px-lead-open" (đã gắn sẵn ở hero, showroom, cuối bài blog).
- Chèn nút bằng shortcode: [powerx_lead_button text="Nhận tư vấn" interest="Trang X"].
- Lead được LƯU trong wp-admin -> mục "KH tiềm năng" VÀ gửi EMAIL về địa chỉ admin (Cài đặt -> Tổng quan -> Email quản trị).

MENU (khuyến nghị)
- Giao diện -> Menu: tạo menu với các mục: Nệm (kèm mục con Hybrid/Foam), Gối, So sánh nệm, Blog, Showroom -> gán vị trí "Menu chính".

========================================
v3.0 — HERO ẢNH NỀN KIỂU CASPER + TÙY BIẾN
========================================

CÁCH BẠN TỰ ĐỔI ẢNH/TEXT TRANG CHỦ (KHÔNG CẦN CODE):

1. Đăng nhập wp-admin -> Giao diện -> Tùy biến (Appearance -> Customize).
2. Mở mục "Power X — Trang chủ" (panel mới ở bên trái).
3. Có 4 nhóm cài đặt:
   - Hero (Đầu trang): tải ẢNH NỀN HERO + chỉnh các dòng chữ headline/lead/nút.
       * Khuyến nghị ảnh ≥ 2000×1200, có khoảng trống bên PHẢI để đặt hộp thoại trắng bên trái.
       * Ví dụ: ảnh phòng ngủ Power X chụp ngang, người mẫu ở giữa-phải, không gian rộng bên trái.
   - Khu Quiz: chỉnh tiêu đề + mô tả ngắn của khu tư vấn nhanh.
   - CTA Showroom: chỉnh tiêu đề/mô tả/ẢNH NỀN cho dải showroom.
   - Liên hệ (Footer): hotline, Zalo, địa chỉ, Facebook.
4. Bấm "Xuất bản" (Publish) ở góc trên trái -> đổi áp dụng ngay.

ẢNH SẢN PHẨM:
- Vào Sản phẩm -> chọn từng sản phẩm.
- Bên phải có 2 ô: "Ảnh sản phẩm" (ảnh đại diện) và "Thư viện sản phẩm" (các ảnh phụ).
- Kéo ảnh vào, bấm Cập nhật.

========================================
v4 — DỮ LIỆU MỚI (TÀI LIỆU POWER X CHÍNH CHỦ)
========================================
- HERO: dùng slogan "FOR ME · NOT FOR YOU" làm headline (thay vì câu chung chung).
- KHU 4 PERSONAS trên trang chủ:
    * Prime — Prime Level. Sleep Like a Pro. (doanh nhân, vận động viên chuyên nghiệp)
    * Fusion — Recover Fast. Play Hard. (người vận động, văn phòng)
    * Flow — Flow Mode: Stay Cool, Stay Sharp. (cặp đôi, người ngủ nóng)
    * Core — Cool Sleep. Core Power. (người trẻ, lifestyle tối giản)
- BẢO HÀNH: 10 NĂM (đã cập nhật mọi nơi).
- KÍCH THƯỚC: lớn nhất 220x200 (sửa từ 200x220).
- ĐỘ CỨNG: Prime Medium · Fusion Medium · Flow Medium-Firm · Core Firm.
- TRANG CHI TIẾT SẢN PHẨM (Casper-style): hiện tagline EN + phụ đề VI ngay dưới tên,
  khối 4 thông số (Cao/Loại/Độ cứng/Bảo hành), khu "Dành cho ai", khu "X-Features".
- Mục Sản phẩm trong wp-admin có thêm metabox "Power X – Nội dung Casper-style"
  để bạn nhập tagline/persona/X-Features dễ dàng.

CÁCH ĐIỀN NỘI DUNG MỘT SẢN PHẨM (ví dụ Power X Prime):
  1. Sản phẩm -> Power X Prime
  2. Metabox bên phải "Power X – Thông số thẻ": Nhãn=PRIME, Cao=30cm, Loại=Hybrid, Độ cứng=Medium
  3. Metabox bên dưới "Power X – Nội dung Casper-style":
     - Tagline EN: Prime Level. Sleep Like a Pro.
     - Phụ đề VI: Đẳng cấp giấc ngủ — tái tạo năng lượng cho người thành đạt.
     - Dành cho ai: (mỗi dòng 1 ý)
         Doanh nhân, vận động viên chuyên nghiệp
         Gia đình hiện đại
         Người tìm kiếm giấc ngủ đỉnh cao
     - X-Features: (Mã | Mô tả, mỗi dòng 1 cái)
         X-Touch | Lớp chần foam mát lạnh, sang trọng
         X-PrimeSpring | Hệ lò xo kép (micro coil + pocket coil)
         X-NeoFlex | Foam jelly đàn hồi, tản nhiệt tốt
         X-Regen | Thiết kế phục hồi sâu, tái tạo năng lượng
     - Bảo hành: 10 năm
  4. Cập nhật.

========================================
v5 — SIZE BUTTONS + TABS TRANG CHỦ + GIÁ THẤP NHẤT
========================================

TRANG CHỦ — TABS
- Bộ sưu tập có 3 tab: Nệm (4) · Gối (2) · Tư vấn nhanh (quiz).
- Mặc định mở tab Nệm. Quiz không còn chiếm cả section riêng — chỉ là 1 tab.

TRANG CHI TIẾT SẢN PHẨM — NÚT CHỌN SIZE
- Mỗi size là 1 NÚT TICK (không phải dropdown).
- Trên nút có sẵn: tên size + giá tương ứng.
- Click chọn 1 size -> giá lớn ở trên cập nhật theo size đó.
- Size hết hàng (out of stock) sẽ mờ và có nhãn "Hết hàng", không bấm được.
- Mặc định khi mở trang: tự chọn size THẤP NHẤT CÒN HÀNG.

TRANG CHỦ / SHOP — HIỂN THỊ GIÁ
- Trước đây: "23.598.000₫ – 37.598.000₫"  (range)
- Bây giờ:    "từ 23.598.000₫"           (giá thấp nhất CÒN TỒN KHO)
- Nếu size rẻ nhất hết hàng, hệ thống tự lấy size rẻ kế tiếp đang còn hàng.

========================================
v6 — SỬA LỖI ADD-TO-CART · GIÁ HIỂN THỊ · LOGO · CONTACT TAB · MOBILE
========================================

SAU KHI CÀI THEME v6:

1. LOGO
- Mặc định hiển thị logo SVG (zebra + POWER X chữ đen, X lime).
- Để upload logo CỦA HÃNG: vào Giao diện -> Tùy biến -> Nhận diện trang web -> Logo -> Chọn ảnh -> Xuất bản.
- Logo sẽ thay thế logo mặc định ngay lập tức.

2. CÀI ĐẶT VND (TỰ ĐỘNG)
- Khi kích hoạt theme, hệ thống TỰ đặt: Tiền tệ=VND, dấu ngàn=. , dấu thập phân=, , số chữ số thập phân=0.
- Nếu giá vẫn hiển thị sai sau khi cài lại theme: vào WooCommerce -> Cài đặt -> Chung -> kiểm tra 4 ô trên.
- Nếu giá trong database đã bị sai (vd 23598 thay vì 23598000), phải xóa sản phẩm cũ và IMPORT LẠI CSV.

3. ADD TO CART (đã sửa)
- v5 dùng <input hidden> nên WC không nhận variation. v6 dùng <select> ẩn + buttons -> WC nhận đúng.
- Nếu vẫn báo "không thể mua được": kiểm tra trong sản phẩm -> tab "Tồn kho" của từng variation phải bật "Còn hàng".

4. CART / CHECKOUT / TÀI KHOẢN
- v6 tự kích hoạt 4 trang WooCommerce: Giỏ hàng, Thanh toán, Tài khoản, Cửa hàng.
- Nếu giỏ hàng trắng trơn: vào WooCommerce -> Trạng thái -> Công cụ -> "Tạo lại trang mặc định" để chắc chắn.

5. TAB LIÊN HỆ
- Trang chủ giờ có 4 tab: Nệm / Gối / Tư vấn / Liên hệ.
- Số hotline + link Messenger + Zalo cập nhật trong Tùy biến -> Power X -> Liên hệ.
- Link Messenger mặc định đã đặt cho FB Page của bạn.
- Form liên hệ submit cùng hệ thống Lead -> wp-admin "KH tiềm năng" + email admin.

6. BLOG
- v6 KHÔNG tạo trùng bài blog nếu đã có (kiểm tra theo tiêu đề).
- Để thêm bài mới: Bài viết -> Thêm mới, chọn chuyên mục, đăng.
- Cần thêm hình minh họa: ô "Ảnh tiêu biểu" bên phải khi soạn bài.

7. MOBILE
- v6 đã được tối ưu: tabs cuộn ngang, personas + pillows xếp dọc, size buttons 2 cột, contact stack dọc.
- Test trên điện thoại sau khi cài.
