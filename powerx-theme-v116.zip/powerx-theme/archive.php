<?php if (!defined('ABSPATH')) exit; get_header(); ?>
<div class="px-wrap px-section">
  <div class="px-sec-head"><span class="px-eyebrow">Blog Power X</span>
    <h2><?php if(is_category()){single_cat_title();}elseif(is_home()){echo 'Tất cả bài viết';}else{the_archive_title();} ?></h2></div>
  <div class="px-blog-grid">
  <?php if(have_posts()): while(have_posts()): the_post(); ?>
    <a class="px-blog-card" href="<?php the_permalink(); ?>">
      <div class="px-blog-thumb"><?php if(has_post_thumbnail()) the_post_thumbnail('medium'); else echo '<span>POWER X</span>'; ?></div>
      <div class="px-blog-body">
        <span class="px-blog-cat"><?php $c=get_the_category(); echo $c?esc_html($c[0]->name):'Blog'; ?></span>
        <h3><?php the_title(); ?></h3>
        <p><?php echo esc_html(wp_trim_words(get_the_excerpt(),24)); ?></p>
      </div>
    </a>
  <?php endwhile; else: ?><p>Chưa có bài viết.</p><?php endif; ?>
  </div>
  <div class="px-pagination"><?php the_posts_pagination(array('mid_size'=>1)); ?></div>
</div>
<?php get_footer(); ?>
