<?php if (!defined('ABSPATH')) exit; get_header(); ?>
<div class="px-wrap px-section">
  <?php if (have_posts()): while (have_posts()): the_post(); ?>
    <article <?php post_class(); ?>>
      <h1 style="font-size:32px;margin-bottom:16px"><?php the_title(); ?></h1>
      <div><?php the_content(); ?></div>
    </article>
  <?php endwhile; else: ?>
    <p>Chưa có nội dung.</p>
  <?php endif; ?>
</div>
<?php get_footer(); ?>
