<?php
/**
 * Power X — Bố cục trang chi tiết sản phẩm (kiểu Bedgear).
 * 2 cột (gallery | tóm tắt) trong khung px-wrap, các khối còn lại full-width.
 */
defined('ABSPATH') || exit;
global $product;

if (post_password_required()) { echo get_the_password_form(); return; }
?>
<?php do_action('woocommerce_before_single_product'); ?>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class('px-single', $product); ?>>

  <div class="px-single-top"><div class="px-wrap px-single-grid">
    <div class="px-single-left">
      <?php do_action('woocommerce_before_single_product_summary'); ?>
    </div>
    <div class="summary entry-summary">
      <?php do_action('woocommerce_single_product_summary'); ?>
    </div>
  </div></div>

  <div class="px-single-after">
    <?php do_action('woocommerce_after_single_product_summary'); ?>
  </div>

</div>

<?php do_action('woocommerce_after_single_product'); ?>
