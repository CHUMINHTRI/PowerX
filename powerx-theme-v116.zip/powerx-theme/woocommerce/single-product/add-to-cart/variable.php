<?php
/** Power X — Variable form: hidden select + tick buttons. Đảm bảo WC variation matching hoạt động */
if (!defined('ABSPATH')) exit;
global $product;
$variations_json = wp_json_encode($available_variations);
$variations_attr = function_exists('wc_esc_json') ? wc_esc_json($variations_json) : _wp_specialchars($variations_json, ENT_QUOTES, 'UTF-8', true);
do_action('woocommerce_before_add_to_cart_form'); ?>
<form class="variations_form cart" action="<?php echo esc_url(apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink())); ?>" method="post" enctype='multipart/form-data' data-product_id="<?php echo absint($product->get_id()); ?>" data-product_variations="<?php echo $variations_attr; ?>">
<?php do_action('woocommerce_before_variations_form'); ?>

<?php if (empty($available_variations) && false !== $available_variations): ?>
  <p class="stock out-of-stock">Sản phẩm tạm hết hàng.</p>
<?php else: ?>
  <table class="variations" cellspacing="0" style="display:none">
    <tbody>
    <?php foreach ($attributes as $attribute_name => $options): ?>
      <tr>
        <th class="label"><label for="<?php echo esc_attr(sanitize_title($attribute_name)); ?>"><?php echo wc_attribute_label($attribute_name); ?></label></th>
        <td class="value">
          <?php
          wc_dropdown_variation_attribute_options(array(
            'options'   => $options,
            'attribute' => $attribute_name,
            'product'   => $product,
          ));
          ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <div class="px-variations">
    <?php foreach ($attributes as $attribute_name => $options): ?>
      <div class="px-attr">
        <label class="px-attr-label"><?php echo wc_attribute_label($attribute_name); ?></label>
        <div class="px-size-grid" data-attr="attribute_<?php echo esc_attr(sanitize_title($attribute_name)); ?>">
          <?php
          if (taxonomy_exists($attribute_name)) {
              foreach (wc_get_product_terms($product->get_id(), $attribute_name, array('fields'=>'all')) as $term){
                  if(in_array($term->slug, $options, true))
                      echo '<button type="button" class="px-size-btn" data-value="'.esc_attr($term->slug).'"><span class="sz">'.esc_html($term->name).'</span><span class="pr"></span></button>';
              }
          } else {
              foreach ($options as $option){
                  echo '<button type="button" class="px-size-btn" data-value="'.esc_attr($option).'"><span class="sz">'.esc_html($option).'</span><span class="pr"></span></button>';
              }
          }
          ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="single_variation_wrap">
    <?php do_action('woocommerce_before_single_variation'); ?>
    <?php do_action('woocommerce_single_variation'); ?>
    <?php do_action('woocommerce_after_single_variation'); ?>
  </div>
<?php endif; ?>

<?php do_action('woocommerce_after_variations_form'); ?>
</form>
<?php do_action('woocommerce_after_add_to_cart_form'); ?>
