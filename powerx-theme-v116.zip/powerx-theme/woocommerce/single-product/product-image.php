<?php
/**
 * Power X — Gallery sản phẩm.
 * Nếu sản phẩm có cấu hình "Gallery tuỳ biến (ảnh/video)" thì dùng gallery tuỳ biến
 * (ảnh lớn + lưới thumbnail, hỗ trợ video). Nếu không, dùng gallery mặc định WooCommerce.
 */
defined('ABSPATH') || exit;
global $product;

$px_items = function_exists('powerx_gallery_items') ? powerx_gallery_items($product) : array();

/* ---------- GALLERY TUỲ BIẾN (ảnh + video) ---------- */
if (!empty($px_items)) :
    $ph = wc_placeholder_img_src();
    ?>
    <div class="px-gallery">
        <div class="px-gallery-main">
            <?php if (function_exists('powerx_promo_badge_html')) echo powerx_promo_badge_html('px-sale-badge--single'); ?>
            <?php foreach ($px_items as $idx => $it):
                $img = $it['img'];
                $vid = $it['video'];
                $embed = ($vid !== '' && function_exists('powerx_video_embed_html')) ? powerx_video_embed_html($vid) : '';
                $active = $idx === 0 ? ' is-active' : '';
                ?>
                <div class="px-gmain-item<?php echo $active; ?>" data-idx="<?php echo (int)$idx; ?>">
                    <?php if ($embed): ?>
                        <div class="px-gvideo">
                            <div class="px-gvideo-cover" role="button" tabindex="0" aria-label="Phát video">
                                <?php echo powerx_gallery_cover_html($img, $vid, $product->get_name()); ?>
                                <span class="px-gvideo-play" aria-hidden="true"></span>
                            </div>
                            <div class="px-gvideo-embed"><?php echo $embed; ?></div>
                        </div>
                    <?php else: ?>
                        <img src="<?php echo esc_url($img !== '' ? $img : $ph); ?>" alt="<?php echo esc_attr($product->get_name()); ?>">
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php if (count($px_items) > 1): ?>
        <div class="px-gallery-thumbs">
            <?php foreach ($px_items as $idx => $it):
                $isvid = ($it['video'] !== '');
                ?>
                <button type="button" class="px-gthumb<?php echo $idx===0?' is-active':''; ?>" data-idx="<?php echo (int)$idx; ?>" aria-label="Ảnh <?php echo (int)$idx+1; ?>">
                    <?php echo powerx_gallery_cover_html($it['img'], $it['video'], ''); ?>
                    <?php if ($isvid): ?><span class="px-gthumb-play" aria-hidden="true"></span><?php endif; ?>
                </button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php
    return;
endif;

/* ---------- GALLERY MẶC ĐỊNH WOOCOMMERCE (fallback) ---------- */
$columns           = apply_filters('woocommerce_product_thumbnails_columns', 4);
$post_thumbnail_id = $product->get_image_id();
$wrapper_classes   = apply_filters('woocommerce_single_product_image_gallery_classes', array(
    'woocommerce-product-gallery',
    'woocommerce-product-gallery--' . ($post_thumbnail_id ? 'with-images' : 'without-images'),
    'woocommerce-product-gallery--columns-' . absint($columns),
    'images',
));

$px_video  = get_post_meta($product->get_id(), 'px_video', true);
$px_embed  = ($px_video && function_exists('powerx_video_embed_html')) ? powerx_video_embed_html($px_video) : '';
$px_poster = $post_thumbnail_id ? wp_get_attachment_image_url($post_thumbnail_id, 'woocommerce_single') : wc_placeholder_img_src();
?>
<div class="<?php echo esc_attr(implode(' ', array_map('sanitize_html_class', $wrapper_classes))); ?>" data-columns="<?php echo esc_attr($columns); ?>" style="opacity:0; transition:opacity .25s ease-in-out;">
    <?php if (function_exists('powerx_promo_badge_html')) echo powerx_promo_badge_html('px-sale-badge--single'); ?>
    <figure class="woocommerce-product-gallery__wrapper">
        <?php
        if ($post_thumbnail_id) {
            $html = wc_get_gallery_image_html($post_thumbnail_id, true);
        } else {
            $html  = '<div class="woocommerce-product-gallery__image--placeholder">';
            $html .= sprintf('<img src="%s" alt="%s" class="wp-post-image" />', esc_url(wc_placeholder_img_src()), esc_html__('Awaiting product image', 'woocommerce'));
            $html .= '</div>';
        }
        echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, $post_thumbnail_id);

        do_action('woocommerce_product_thumbnails');
        ?>
    </figure>

    <?php if ($px_embed): ?>
    <div class="px-product-video">
        <div class="px-video-cover" role="button" tabindex="0" aria-label="Phát video sản phẩm">
            <img src="<?php echo esc_url($px_poster); ?>" alt="Video sản phẩm" />
            <span class="px-video-play" aria-hidden="true"></span>
            <span class="px-video-tag">▶ Video sản phẩm</span>
        </div>
        <div class="px-video-embed"><?php echo $px_embed; ?></div>
    </div>
    <?php endif; ?>
</div>
