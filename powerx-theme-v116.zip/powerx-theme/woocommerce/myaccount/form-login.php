<?php
/**
 * Power X — Trang Tài khoản (Đăng nhập + Đăng ký) bố cục 2 cột.
 * Override của woocommerce/myaccount/form-login.php
 */
if ( ! defined( 'ABSPATH' ) ) exit;

do_action( 'woocommerce_before_customer_login_form' );

$can_register = 'yes' === get_option( 'woocommerce_enable_myaccount_registration' );
$gen_user     = 'yes' === get_option( 'woocommerce_registration_generate_username' );
$gen_pass     = 'yes' === get_option( 'woocommerce_registration_generate_password' );
?>

<div class="px-account">
  <div class="px-account-head">
    <span class="px-account-eyebrow">FOR ME · NOT FOR YOU</span>
    <h1 class="px-account-title">Tài khoản Power X</h1>
    <p class="px-account-sub">Đăng nhập để theo dõi đơn hàng, ưu đãi thành viên và lịch sử giấc ngủ của bạn.</p>
  </div>

  <div class="px-account-grid<?php echo $can_register ? '' : ' px-account-grid--solo'; ?>">

    <!-- ĐĂNG NHẬP -->
    <section class="px-acard px-acard-login">
      <div class="px-acard-h">
        <h2>Đăng nhập</h2>
        <p>Đã có tài khoản? Chào mừng bạn quay lại.</p>
      </div>

      <form class="woocommerce-form woocommerce-form-login login px-aform" method="post">
        <?php do_action( 'woocommerce_login_form_start' ); ?>

        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide px-arow">
          <label for="username"><?php esc_html_e( 'Tên tài khoản hoặc email', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
          <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" placeholder="email@cuaban.com" /><?php // phpcs:ignore ?>
        </p>

        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide px-arow">
          <label for="password"><?php esc_html_e( 'Mật khẩu', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
          <span class="password-input">
            <input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password" placeholder="••••••••" />
          </span>
        </p>

        <?php do_action( 'woocommerce_login_form' ); ?>

        <p class="form-row px-arow-actions">
          <?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
          <label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme px-aremember">
            <input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span><?php esc_html_e( 'Ghi nhớ đăng nhập', 'woocommerce' ); ?></span>
          </label>
          <button type="submit" class="woocommerce-button button woocommerce-form-login__submit px-btn px-btn-ink" name="login" value="<?php esc_attr_e( 'Đăng nhập', 'woocommerce' ); ?>"><?php esc_html_e( 'Đăng nhập', 'woocommerce' ); ?></button>
        </p>

        <p class="woocommerce-LostPassword lost_password px-alost">
          <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Quên mật khẩu?', 'woocommerce' ); ?></a>
        </p>

        <?php do_action( 'woocommerce_login_form_end' ); ?>
      </form>
    </section>

    <?php if ( $can_register ) : ?>
    <!-- ĐĂNG KÝ -->
    <section class="px-acard px-acard-register">
      <div class="px-acard-h">
        <h2>Đăng ký</h2>
        <p>Thành viên mới nhận ngay ưu đãi & quà chào mừng.</p>
      </div>

      <form method="post" class="woocommerce-form woocommerce-form-register register px-aform" <?php do_action( 'woocommerce_register_form_tag' ); ?>>
        <?php do_action( 'woocommerce_register_form_start' ); ?>

        <?php if ( ! $gen_user ) : ?>
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide px-arow">
          <label for="reg_username"><?php esc_html_e( 'Tên tài khoản', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
          <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" placeholder="tên hiển thị" /><?php // phpcs:ignore ?>
        </p>
        <?php endif; ?>

        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide px-arow">
          <label for="reg_email"><?php esc_html_e( 'Địa chỉ email', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
          <input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" placeholder="email@cuaban.com" /><?php // phpcs:ignore ?>
        </p>

        <?php if ( ! $gen_pass ) : ?>
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide px-arow">
          <label for="reg_password"><?php esc_html_e( 'Mật khẩu', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
          <span class="password-input">
            <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" placeholder="Tạo mật khẩu" />
          </span>
        </p>
        <?php else : ?>
        <p class="px-anote"><?php esc_html_e( 'Mật khẩu sẽ được gửi tới email của bạn.', 'woocommerce' ); ?></p>
        <?php endif; ?>

        <?php do_action( 'woocommerce_register_form' ); ?>

        <p class="woocommerce-form-row form-row px-arow-actions">
          <?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
          <button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit px-btn px-btn-lime" name="register" value="<?php esc_attr_e( 'Đăng ký', 'woocommerce' ); ?>"><?php esc_html_e( 'Đăng ký', 'woocommerce' ); ?></button>
        </p>

        <?php do_action( 'woocommerce_register_form_end' ); ?>
      </form>
    </section>
    <?php endif; ?>

  </div>

  <ul class="px-account-perks">
    <li><span>🌙</span> Dùng thử 100 đêm</li>
    <li><span>🛡️</span> Bảo hành 10 năm</li>
    <li><span>🚚</span> Giao lắp 24h</li>
    <li><span>↩️</span> Đổi trả miễn phí</li>
  </ul>
</div>

<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
