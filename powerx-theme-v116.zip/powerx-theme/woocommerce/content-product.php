<?php
/** Power X — thẻ sản phẩm trong vòng lặp (matching demo) */
if (!defined('ABSPATH')) exit;
global $product;
if (empty($product) || !$product->is_visible()) return;
$id=$product->get_id();
$pill=get_post_meta($id,'px_pill',true);
$h=get_post_meta($id,'px_height',true);$t=get_post_meta($id,'px_type',true);$hd=get_post_meta($id,'px_hardness',true);
?>
<li <?php wc_product_class('px-card', $product); ?>>
  <a href="<?php the_permalink(); ?>" class="px-card-media">
    <?php if($pill) echo '<span class="px-card-pill">'.esc_html($pill).'</span>'; ?>
    <?php if(function_exists('powerx_promo_badge_html')) echo powerx_promo_badge_html('px-sale-badge--card'); ?>
    <?php echo woocommerce_get_product_thumbnail(); ?>
  </a>
  <div class="px-card-body">
    <h3 class="px-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    <?php if(function_exists('powerx_trust_html')) echo powerx_trust_html($product,'px-card-trust'); ?>
    <?php if($h||$t||$hd): ?>
    <div class="px-card-specs">
      <?php if($h) echo '<div><b>'.esc_html($h).'</b><small>Cao</small></div>'; ?>
      <?php if($t) echo '<div><b>'.esc_html($t).'</b><small>Loại</small></div>'; ?>
      <?php if($hd)echo '<div><b>'.esc_html($hd).'</b><small>Độ cứng</small></div>'; ?>
    </div>
    <?php endif; ?>
    <span class="price"><?php echo $product->get_price_html(); ?></span>
    <?php woocommerce_template_loop_add_to_cart(); ?>
  </div>
</li>
