<?php
/** Power X — Trang "Về chúng tôi" + "Đối tác": tự tạo trang + chỉnh sửa qua Customizer */
if (!defined('ABSPATH')) exit;

/* Tự tạo 2 trang nếu chưa có (chạy khi vào admin) */
add_action('admin_init', function(){
    if (get_option('powerx_extra_pages') === '2') return;
    $mk = function($slug,$title){
        if (get_page_by_path($slug)) return;
        wp_insert_post(array('post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$title,'post_content'=>''));
    };
    $mk('ve-chung-toi','Về chúng tôi');
    $mk('doi-tac','Đối tác');
    update_option('powerx_extra_pages','2');
});

/* Ảnh mặc định (bundle trong theme) cho trang Về chúng tôi */
function powerx_ab_img($file){ return get_template_directory_uri().'/assets/about/'.$file; }

/* Nội dung mặc định trang Về chúng tôi — dùng chung cho Customizer & template */
function powerx_ab_def($key){
    $d = array(
      'powerx_ab_hero_eyebrow' => 'Về Power X',
      'powerx_ab_hero_title'   => 'Công nghệ giấc ngủ toàn cầu, nay đã đến Việt Nam',
      'powerx_ab_hero_lead'    => 'Power X là thương hiệu nệm hiệu năng cao của tập đoàn DPD FOAM — tiên phong về khoa học vật liệu giấc ngủ từ năm 2011, được tin dùng tại Bắc Mỹ, Châu Âu và Châu Á. Năm 2025, DPD FOAM ký kết phân phối độc quyền cùng Sleep Expert, đưa Power X đến với người Việt.',

      'powerx_ab_story_eyebrow'=> 'Our Story',
      'powerx_ab_story_h'      => 'Niềm tin toàn cầu, tinh hoa bản địa',
      'powerx_ab_story_body'   => "Kể từ năm 2011, DPD FOAM luôn tiên phong trong việc đổi mới giấc ngủ. Qua quá trình R&D không ngừng về khoa học vật liệu, chúng tôi chuyển hóa các loại mút tiên tiến thành những giải pháp chăm sóc sự thoải mái, nâng tầm giấc ngủ.\n\nChúng tôi tin rằng công nghệ giấc ngủ tiên tiến nhất nên được tiếp cận bởi tất cả mọi người — với chất lượng đạt giải thưởng và giá trị cạnh tranh thực sự.",

      'powerx_ab_aw_eyebrow'   => 'Tôn vinh sự xuất sắc',
      'powerx_ab_aw_h'         => 'Được công nhận toàn cầu',
      'powerx_ab_aw_list'      => "Red Dot Design Award — 2019\nGolden Dot Award — Trung Quốc\nDoanh nghiệp Công nghệ cao — Trung Quốc\nBằng sáng chế toàn cầu — vật liệu Smile Foam\nGiải Công trình xanh — ngành nội thất Trung Quốc\nĐạt chuẩn CertiPUR-US® & OEKO-TEX®",

      'powerx_ab_tech_h'       => 'Khoa học về sự thoải mái',
      'powerx_ab_tech_lead'    => 'Những vật liệu và cấu trúc độc quyền tạo nên khác biệt Power X.',
      'powerx_ab_t1_title'     => 'Lò Xo Sinh Học',
      'powerx_ab_t1_sub'       => 'Êm ái theo cách của riêng bạn',
      'powerx_ab_t1_text'      => 'Hệ thống lò xo bionic dạng mô-đun cho phép tinh chỉnh độ êm và khả năng nâng đỡ chưa từng có — tối ưu theo từng vùng cơ thể, bảo vệ cột sống toàn diện theo công thái học.',
      'powerx_ab_t2_title'     => 'Baby Foam Air®',
      'powerx_ab_t2_sub'       => 'Dòng foam thoáng khí hàng đầu thế giới',
      'powerx_ab_t2_text'      => 'Chỉ số 3.950 L/dm²·min — kỷ lục mới về độ thoáng khí, vượt tiêu chuẩn ngành tới 8.2 lần. Loại bỏ hoàn toàn cảm giác hầm bí, mang đến giấc ngủ khô thoáng trọn vẹn.',
      'powerx_ab_t3_title'     => '20D Memory Foam',
      'powerx_ab_t3_sub'       => 'Đột phá tỷ trọng siêu thấp đầu tiên thế giới',
      'powerx_ab_t3_text'      => 'Cột mốc toàn cầu đầu tiên đạt sản xuất hàng loạt Memory Foam 20D ổn định — mềm mại tuyệt đối, êm sát từng đường cong cơ thể với lượng vật liệu tối ưu: nhẹ hơn, bền hơn, hiệu quả hơn.',

      'powerx_ab_hist_h'       => 'Chặng đường 2011 — 2025',
      'powerx_ab_hist_lines'   => "2011 | Doriux được thành lập tại Phật Sơn, Trung Quốc.\n2012 | DPD FOAM lần đầu ra mắt tại triển lãm nội thất CIFF.\n2018 | Ra mắt thương hiệu riêng POWER X; phát triển dòng vật liệu độc quyền Baby Foam.\n2019 | Nhận giải Red Dot Design Award; lập nhà máy sản xuất chuyên dụng mới.\n2020 | Chứng nhận Doanh nghiệp Công nghệ cao Trung Quốc; giải Golden Dot Award.\n2021 | Giải Công nghệ mới Trung Quốc; chuẩn hóa năng lực công nghệ cao.\n2022 | Hệ thống kho tự động 3D quy mô lớn & dây chuyền cắt gọt hiện đại.\n2023 | Giải Đổi mới Nội thất Trung Quốc; Sản phẩm Đổi mới Sản xuất Vàng 2023.\n2024 | Ra mắt tại Las Vegas (Hoa Kỳ); bằng sáng chế toàn cầu vật liệu Smile Foam.\n*2025 | Nhà máy mới tự động hóa hơn 80.000 sản phẩm/tháng. Ký phân phối độc quyền với Công ty Sleep Expert — đưa Power X đến với người Việt.",

      'powerx_ab_map_h'        => 'Power X trên bản đồ thế giới',
      'powerx_ab_map_lead'     => 'Từ trung tâm sản xuất tại Châu Á đến Bắc Mỹ, Châu Âu — và nay là Việt Nam.',
    );
    if (isset($d[$key])) return $d[$key];
    $imgs = array(
      'powerx_ab_hero_img'=>'mattress.jpg','powerx_ab_story_img'=>'foam.jpg',
      'powerx_ab_aw_img'=>'sphere.jpg','powerx_ab_t1_img'=>'spring.jpg',
      'powerx_ab_t2_img'=>'air.jpg','powerx_ab_t3_img'=>'test.jpg',
    );
    if (isset($imgs[$key])) return powerx_ab_img($imgs[$key]);
    return '';
}

/* Cấu hình nội dung 2 trang trong Tùy biến */
add_action('customize_register', function($wp){
    $wp->add_panel('powerx_pages_panel', array('title'=>'Power X — Giới thiệu & Đối tác','priority'=>32));

    $T = function($key,$label,$section,$type='text') use($wp){
        $wp->add_setting($key, array('default'=>powerx_ab_def($key),'sanitize_callback'=> ($type==='textarea'?'sanitize_textarea_field':'sanitize_text_field')));
        $wp->add_control($key, array('label'=>$label,'section'=>$section,'type'=>$type));
    };
    $I = function($key,$label,$section) use($wp){
        $wp->add_setting($key, array('default'=>powerx_ab_def($key),'sanitize_callback'=>'esc_url_raw'));
        $wp->add_control(new WP_Customize_Image_Control($wp,$key,array('label'=>$label,'section'=>$section)));
    };

    /* ===== TRANG: VỀ CHÚNG TÔI ===== */
    $s='powerx_about_sec';
    $wp->add_section($s, array('title'=>'Trang: Về chúng tôi','panel'=>'powerx_pages_panel'));
    $T('powerx_ab_hero_eyebrow','HERO — Chữ nhỏ',$s); $T('powerx_ab_hero_title','HERO — Tiêu đề',$s); $T('powerx_ab_hero_lead','HERO — Mô tả',$s,'textarea'); $I('powerx_ab_hero_img','HERO — Ảnh',$s);
    $T('powerx_ab_story_eyebrow','Câu chuyện — Chữ nhỏ',$s); $T('powerx_ab_story_h','Câu chuyện — Tiêu đề',$s); $T('powerx_ab_story_body','Câu chuyện — Nội dung (đoạn cách 1 dòng trống)',$s,'textarea'); $I('powerx_ab_story_img','Câu chuyện — Ảnh (không chữ)',$s);
    $T('powerx_ab_aw_eyebrow','Giải thưởng — Chữ nhỏ',$s); $T('powerx_ab_aw_h','Giải thưởng — Tiêu đề',$s); $T('powerx_ab_aw_list','Giải thưởng — Danh sách (mỗi dòng 1 mục)',$s,'textarea'); $I('powerx_ab_aw_fullimg','Giải thưởng — Ảnh full-width (bạn upload)',$s);
    $T('powerx_ab_tech_h','Công nghệ — Tiêu đề',$s); $T('powerx_ab_tech_lead','Công nghệ — Mô tả',$s,'textarea');
    for($i=1;$i<=3;$i++){
        $T("powerx_ab_t{$i}_title","Công nghệ #{$i} — Tên",$s); $T("powerx_ab_t{$i}_sub","Công nghệ #{$i} — Phụ đề",$s); $T("powerx_ab_t{$i}_text","Công nghệ #{$i} — Mô tả",$s,'textarea'); $I("powerx_ab_t{$i}_img","Công nghệ #{$i} — Ảnh",$s);
    }
    $T('powerx_ab_hist_h','Lịch sử — Tiêu đề',$s);
    $T('powerx_ab_hist_lines','Lịch sử — Mốc (mỗi dòng: NĂM | nội dung; thêm * đầu dòng để tô đậm)',$s,'textarea');
    $T('powerx_ab_map_h','Bản đồ — Tiêu đề',$s); $T('powerx_ab_map_lead','Bản đồ — Mô tả',$s,'textarea');

    /* ===== TRANG: ĐỐI TÁC / ĐẠI LÝ ===== */
    $p='powerx_partners_sec';
    $Tp = function($key,$label,$default,$type='text') use($wp,$p){
        $wp->add_setting($key, array('default'=>$default,'sanitize_callback'=> ($type==='textarea'?'sanitize_textarea_field':'sanitize_text_field')));
        $wp->add_control($key, array('label'=>$label,'section'=>$p,'type'=>$type));
    };
    $wp->add_section($p, array('title'=>'Trang: Đối tác / Đại lý','panel'=>'powerx_pages_panel'));
    $Tp('powerx_partners_eyebrow','Chữ nhỏ trên tiêu đề','HỆ THỐNG ĐẠI LÝ');
    $Tp('powerx_partners_title','Tiêu đề lớn','Đối tác & Đại lý Power X');
    $Tp('powerx_partners_lead','Mô tả ngắn','Ghé các đại lý dưới đây để nằm thử trực tiếp sản phẩm Power X trước khi mua.','textarea');
    for($i=1;$i<=6;$i++){
        $Tp("powerx_partner{$i}_name","Đại lý #{$i} — Tên (để trống = ẩn)", ($i===1?'Power X Showroom Biên Hòa':''));
        $Tp("powerx_partner{$i}_addr","Đại lý #{$i} — Địa chỉ", ($i===1?'Số nhà E97, Đường D9, KP Vĩnh Thanh, P. Trấn Biên, TP. Đồng Nai':''),'textarea');
        $Tp("powerx_partner{$i}_phone","Đại lý #{$i} — Số điện thoại", ($i===1?'0335332028':''));
        $wp->add_setting("powerx_partner{$i}_map", array('default'=>'','sanitize_callback'=>'esc_url_raw'));
        $wp->add_control("powerx_partner{$i}_map", array('label'=>"Đại lý #{$i} — Link Google Maps (để trống sẽ tự tạo từ địa chỉ)",'section'=>$p,'type'=>'url'));
        $wp->add_setting("powerx_partner{$i}_img", array('sanitize_callback'=>'esc_url_raw'));
        $wp->add_control(new WP_Customize_Image_Control($wp,"powerx_partner{$i}_img",array('label'=>"Đại lý #{$i} — Hình ảnh",'section'=>$p)));
    }

    /* ===== TRANG QUIZ (Tư vấn chọn nệm / gối) ===== */
    $qz='powerx_quiz_sec';
    $Tq = function($key,$label,$default,$type='text') use($wp,$qz){
        $wp->add_setting($key,array('default'=>$default,'sanitize_callback'=> ($type==='textarea'?'sanitize_textarea_field':'sanitize_text_field')));
        $wp->add_control($key,array('label'=>$label,'section'=>$qz,'type'=>$type));
    };
    $wp->add_section($qz, array('title'=>'Trang Quiz (Tư vấn nệm/gối)','panel'=>'powerx_pages_panel'));
    $Tq('powerx_quiznem_eyebrow','Quiz Nệm — Chữ nhỏ','Power X MattressID');
    $Tq('powerx_quiznem_h','Quiz Nệm — Tiêu đề','Tìm dòng nệm hoàn hảo cho bạn');
    $Tq('powerx_quiznem_sub','Quiz Nệm — Mô tả','Trả lời 4 câu hỏi nhanh — Power X gợi ý đúng dòng nệm phù hợp với lifestyle và tư thế ngủ của bạn.','textarea');
    $Tq('powerx_quizgoi_eyebrow','Quiz Gối — Chữ nhỏ','Power X PillowID');
    $Tq('powerx_quizgoi_h','Quiz Gối — Tiêu đề','Tìm chiếc gối hoàn hảo cho bạn');
    $Tq('powerx_quizgoi_sub','Quiz Gối — Mô tả','Trả lời vài câu hỏi nhanh — Power X gợi ý dòng gối phù hợp nhất với tư thế ngủ của bạn.','textarea');
});
