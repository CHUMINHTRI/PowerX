<?php
/**
 * Power X — Khối trang chủ nâng cấp.
 *  1) Công nghệ lõi · HOT DELETE (thermal lab: 2 nệm cùng lúc + monitor + số động)
 *  2) Showroom trải nghiệm (text + ảnh/video nền chỉnh trong Customizer)
 */
if (!defined('ABSPATH')) exit;

/* ===== 1) CÔNG NGHỆ LÕI · HOT DELETE ===== */
function powerx_tech_section(){
    $quiz = get_page_by_path('quiz-nem'); $quiz_url = $quiz ? get_permalink($quiz) : '#px-collection';
    ob_start(); ?>
<section class="pxf-tech" id="congnghe"><div class="pxf-wrap pxf-tech-grid">
  <div class="pxf-tech-copy">
    <span class="pxf-eyebrow">Công nghệ lõi · Hot Balance Sleep System</span>
    <h2 class="pxf-h2"><span class="pxf-hotdelete">HOT DELETE<sup>®</sup></span><br><em>GRAPHENE-DRIVEN CLIMATE CONTROL</em></h2>
    <p class="pxf-lead">Nệm thường <b class="pxf-red">giữ nhiệt cơ thể lại</b> — bạn nóng dần và tỉnh giấc. HOT DELETE® làm ngược lại: thiết kế cắt CNC chính xác + Graphene dẫn nhiệt <b>xuyên qua nệm ra ngoài</b>, giữ bạn ở vùng ngủ sâu suốt đêm. Đã kiểm chứng trong phòng lab.</p>
    <ul class="pxf-feats">
      <li><span class="pxf-fic">G</span><span><b>Graphene Foam</b><p>Dẫn nhiệt gấp nhiều lần foam thường — lab test cho bề mặt mát hơn rõ rệt sau 6 giờ nằm.</p></span></li>
      <li><span class="pxf-fic">A</span><span><b>Baby Foam Air · Airflow</b><p>Độ thoáng khí 2215 L/dm²·phút — gấp ~4.5 lần foam thường (483 L/dm²·phút), khí nóng thoát liên tục.</p></span></li>
      <li><span class="pxf-fic">C</span><span><b>Rãnh CNC AirWave</b><p>Kênh dẫn khí cắt CNC chính xác — quản lý dòng nhiệt theo từng vùng cơ thể.</p></span></li>
    </ul>
    <a class="pxf-btn pxf-btn-red" href="<?php echo esc_url($quiz_url); ?>">Nhận tư vấn miễn phí <span>→</span></a>
  </div>

  <div class="pxf-lab" aria-label="Phòng lab nhiệt: nệm thường và Power X Hot Delete">
    <div class="pxf-lab-head"><span>HOT DELETE® · THERMAL LAB</span><span class="pxf-lab-live"><span class="pxf-dot"></span> LAB TEST</span></div>

    <!-- 2 nệm cùng một màn hình -->
    <div class="pxf-duo">
      <figure class="pxf-scene pxf-scene-hot">
        <figcaption><span>🔥 Nệm thường</span><b>34.6°C</b></figcaption>
        <svg viewBox="0 0 260 176" role="img" aria-label="Nệm thường giữ nhiệt">
          <defs><radialGradient id="pxfHotB" cx="42%" cy="45%" r="72%"><stop offset="0" stop-color="#FF1E00"/><stop offset=".38" stop-color="#FF6A00"/><stop offset=".7" stop-color="#FFC400"/><stop offset="1" stop-color="#8ec63f"/></radialGradient>
          <linearGradient id="pxfTrap2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="rgba(255,60,0,.5)"/><stop offset="1" stop-color="rgba(255,60,0,0)"/></linearGradient></defs>
          <rect x="26" y="118" width="208" height="34" fill="url(#pxfTrap2)" transform="translate(0,-22)"/>
          <g class="pxf-au-slow" stroke="#FF5330" stroke-width="3" fill="none" stroke-linecap="round">
            <path d="M92,66 v-18 m-5,6 l5,-6 l5,6"/><path d="M150,62 v-20 m-5,6 l5,-6 l5,6" style="animation-delay:.7s"/><path d="M204,66 v-18 m-5,6 l5,-6 l5,6" style="animation-delay:1.4s"/>
          </g>
          <ellipse cx="145" cy="94" rx="88" ry="15" fill="url(#pxfHotB)"/><circle cx="54" cy="94" r="13" fill="url(#pxfHotB)"/>
          <rect x="30" y="116" width="200" height="12" rx="4" fill="#E8E8EC"/><rect x="30" y="128" width="200" height="16" fill="#33231C"/><rect x="30" y="144" width="200" height="18" rx="4" fill="#3A3D45"/>
        </svg>
        <span class="pxf-scene-cap hot">Nhiệt kẹt lại trong nệm</span>
      </figure>

      <figure class="pxf-scene pxf-scene-cool">
        <figcaption><span>❄ Power X · Hot Delete</span><b class="cool">29.4°C</b></figcaption>
        <svg viewBox="0 0 260 176" role="img" aria-label="Power X thoát nhiệt">
          <defs><radialGradient id="pxfCoolB" cx="42%" cy="45%" r="72%"><stop offset="0" stop-color="#FFC400"/><stop offset=".5" stop-color="#9ACD32"/><stop offset="1" stop-color="#31A8D8"/></radialGradient>
          <linearGradient id="pxfFlow2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="rgba(80,180,255,.4)"/><stop offset="1" stop-color="rgba(80,180,255,0)"/></linearGradient></defs>
          <rect x="30" y="144" width="200" height="30" fill="url(#pxfFlow2)" opacity=".6"/>
          <g class="pxf-au-fast" stroke="#8ED0FF" stroke-width="2.6" fill="none" stroke-linecap="round">
            <path d="M108,66 v-16 m-5,5 l5,-5 l5,5"/><path d="M172,66 v-16 m-5,5 l5,-5 l5,5" style="animation-delay:.35s"/>
          </g>
          <ellipse cx="145" cy="94" rx="88" ry="15" fill="url(#pxfCoolB)"/><circle cx="54" cy="94" r="13" fill="url(#pxfCoolB)"/>
          <rect x="30" y="116" width="200" height="12" rx="4" fill="#E8E8EC"/><rect x="30" y="128" width="200" height="16" fill="#15304A"/><rect x="30" y="144" width="200" height="18" rx="4" fill="#3A3D45"/>
          <g class="pxf-ad-fast" stroke="#4FB4FF" stroke-width="3" fill="none" stroke-linecap="round">
            <path d="M84,150 v18 m-5,-6 l5,6 l5,-6"/><path d="M132,150 v18 m-5,-6 l5,6 l5,-6" style="animation-delay:.28s"/><path d="M180,150 v18 m-5,-6 l5,6 l5,-6" style="animation-delay:.56s"/>
          </g>
        </svg>
        <span class="pxf-scene-cap cool">Nhiệt thoát xuyên qua Graphene</span>
      </figure>
    </div>

    <!-- Thermal monitor bar -->
    <div class="pxf-monitor">
      <div class="pxf-mon-head"><span>THERMAL MONITOR · POWER X</span><span class="pxf-lab-live"><span class="pxf-dot"></span> LIVE</span></div>
      <p class="pxf-mon-lb">Nhiệt độ bề mặt nệm trong đêm</p>
      <div class="pxf-mon-bar"><span class="pxf-mon-knob"></span></div>
      <div class="pxf-mon-ends"><span>NÓNG BÍ · 34°C+</span><span>CÂN BẰNG · 28–30°C</span></div>
    </div>

    <!-- Số động -->
    <div class="pxf-lab-read pxf-lab-read3">
      <div><b class="pxf-num" data-to="-3.2" data-dec="1">0</b><i>°C</i><span>So với foam thường</span></div>
      <div><b class="pxf-num" data-to="11" data-dec="0">0</b><i>vùng</i><span>Nâng đỡ độc lập</span></div>
      <div><b class="pxf-num" data-to="0" data-dec="0">0</b><i>rung lan</i><span>Chuyển động cô lập</span></div>
    </div>
    <p class="pxf-lab-note">* Mô phỏng minh họa cơ chế tản nhiệt Hot Balance. Trải nghiệm thực tế tại showroom.</p>
  </div>
</div></section>
<?php return ob_get_clean();
}

/* ===== 2) SHOWROOM TRẢI NGHIỆM ===== */
function powerx_showroom_v2(){
    $phone   = function_exists('px_opt') ? px_opt('powerx_phone','0335332028') : '0335332028';
    $tel     = preg_replace('/\s+/','',$phone);
    $eyebrow = function_exists('px_opt') ? px_opt('powerx_showroom_eyebrow','Showroom trải nghiệm') : 'Showroom trải nghiệm';
    $t1      = function_exists('px_opt') ? px_opt('powerx_showroom_title1','NẰM THỬ 15 PHÚT.') : 'NẰM THỬ 15 PHÚT.';
    $t2      = function_exists('px_opt') ? px_opt('powerx_showroom_title2','QUYẾT ĐỊNH 10 NĂM.') : 'QUYẾT ĐỊNH 10 NĂM.';
    $desc    = function_exists('px_opt') ? px_opt('powerx_showroom_text','Prime, Fusion, Flow, Core — cả 4 dòng đặt cạnh nhau tại showroom Biên Hòa. Nằm thử trực tiếp, cảm nhận khác biệt trước khi quyết định.') : '';
    $btn     = function_exists('px_opt') ? px_opt('powerx_showroom_btn','Đặt lịch trải nghiệm') : 'Đặt lịch trải nghiệm';
    $img     = function_exists('px_opt') ? px_opt('powerx_showroom_image','') : '';
    $video   = function_exists('px_opt') ? px_opt('powerx_showroom_video','') : '';

    $media_html=''; $is_video=false;
    if(trim($video)!=='' && function_exists('powerx_hero_media')){
        $m = powerx_hero_media($video,$img);
        if(!empty($m['is_video'])){ $is_video=true; $media_html='<div class="pxf-show-bg">'.$m['html'].'</div>'; }
    }
    $has_bg = $is_video || trim($img)!=='';
    $cls    = 'pxf-show'.($has_bg?' pxf-show--bg':'');
    $style  = (!$is_video && trim($img)!=='') ? ' style="background-image:url('.esc_url($img).')"' : '';
    ob_start(); ?>
<section class="<?php echo $cls; ?>" id="showroom-v2"<?php echo $style; ?>>
  <?php echo $media_html; ?>
  <?php if($has_bg): ?><div class="pxf-show-overlay"></div><?php endif; ?>
  <div class="pxf-wrap pxf-show-grid">
    <div class="pxf-show-copy">
      <span class="pxf-eyebrow"><?php echo esc_html($eyebrow); ?></span>
      <h2 class="pxf-h2 pxf-show-h"><?php echo esc_html($t1); ?><br><em><?php echo esc_html($t2); ?></em></h2>
      <p class="pxf-lead"><?php echo esc_html($desc); ?></p>
      <div class="pxf-show-ctas">
        <button type="button" class="pxf-btn pxf-btn-red px-lead-open" data-interest="Showroom"><?php echo esc_html($btn); ?> <span>→</span></button>
        <a class="pxf-btn pxf-btn-ghost" href="tel:<?php echo esc_attr($tel); ?>">Gọi <?php echo esc_html($phone); ?></a>
      </div>
      <div class="pxf-count">
        <div><b data-count="100"><i>+</i></b><span>Đêm dùng thử</span></div>
        <div><b data-count="10"><i> năm</i></b><span>Bảo hành chính hãng</span></div>
        <div><b data-count="24"><i>h</i></b><span>Giao lắp tận nơi</span></div>
      </div>
    </div>
    <div class="pxf-zebra" aria-hidden="true">PWR<br>X</div>
  </div>
</section>
<?php return ob_get_clean();
}

/* ===== 3) SO SÁNH CHI TIẾT · VS ANALYZER ===== */
function powerx_compare_v2(){
    $chips = '';
    foreach(array('prime'=>'#E60012','fusion'=>'#7d9b00','flow'=>'#1E9BD7','core'=>'#C77D00') as $p=>$c){
        $chips .= '<button class="vchip" data-p="'.$p.'" style="--c:'.$c.'"><i></i>'.ucfirst($p).'</button>';
    }
    ob_start(); ?>
<section class="pxf-compare pxc" id="sosanh"><div class="pxf-wrap">
  <div class="pxf-compare-head">
    <span class="pxf-eyebrow">So sánh chi tiết</span>
    <h2 class="pxf-h2">ĐẶT 2 DÒNG NỆM<br><em>LÊN BÀN CÂN.</em></h2>
    <p class="pxf-lead pxf-center">Chọn 2 dòng bất kỳ — hệ thống chấm điểm 5 chỉ số và chỉ ra dòng phù hợp với bạn.</p>
  </div>

  <div class="vs hud" aria-label="Công cụ so sánh 2 dòng nệm Power X">
    <div class="vs-head"><span>POWER X · BẢNG SO SÁNH CHI TIẾT</span><span class="t-live"><span class="dot"></span> ANALYZING</span></div>
    <div class="vs-pickers">
      <div class="vs-side"><small>Bên A — Chọn dòng</small><div class="vs-chips" data-side="a"><?php echo $chips; ?></div></div>
      <div class="vs-badge">VS</div>
      <div class="vs-side right"><small>Bên B — Chọn dòng</small><div class="vs-chips" data-side="b"><?php echo $chips; ?></div></div>
    </div>
    <div class="vs-names">
      <span><span class="vs-tier" id="vsa-tier"></span><b id="vsa-name" style="display:block">POWER X PRIME</b></span>
      <span class="mid">HEAD-TO-HEAD</span>
      <span style="text-align:right"><span class="vs-tier" id="vsb-tier"></span><b id="vsb-name" style="display:block">POWER X FLOW</b></span>
    </div>
    <div id="vs-bars"></div>
    <div class="vs-specs" id="vs-specs"></div>
    <div class="vs-feats" id="vs-feats"></div>
    <div class="vs-verdict" id="vs-verdict"><span class="vic">⚡</span><span id="vs-verdict-text"></span><a class="pxc-cta px-lead-open" href="#px-collection" data-interest="So sánh" id="vs-buy">Chọn dòng này</a></div>
  </div>

  <div class="pxf-center"><button class="tbl-toggle" id="tbl-toggle">Xem bảng so sánh đầy đủ 4 dòng <span class="car">▾</span></button></div>
  <div class="compare collapsed" id="fulltable">
    <table>
      <thead><tr><th></th><th><i style="color:#E60012">●</i> PRIME</th><th><i style="color:#8FAE00">●</i> FUSION</th><th><i style="color:#1E9BD7">●</i> FLOW</th><th><i style="color:#DE9B00">●</i> CORE</th></tr></thead>
      <tbody>
        <tr><td>Phân khúc</td><td class="best">Flagship — cao cấp nhất</td><td>Performance</td><td>Advanced</td><td>Essential</td></tr>
        <tr><td>Giá từ</td><td>23.598.000₫</td><td>16.198.000₫</td><td>9.398.000₫</td><td class="best">6.398.000₫</td></tr>
        <tr><td>Độ cao</td><td class="best">30cm</td><td>27cm</td><td>22cm</td><td>15cm</td></tr>
        <tr><td>Độ cứng</td><td>Medium</td><td>Medium</td><td>Medium-Firm</td><td>Firm</td></tr>
        <tr><td>Công nghệ</td><td class="best">Lò xo kép + Cooling Gel + Aerospace Foam</td><td>Graphene + Lò xo 11 vùng + FlowEdge</td><td>Memory Foam Graphene + Tencel + AirWave</td><td>Foam 2 mặt + CNC AirWave + Dual Comfort</td></tr>
        <tr><td>Phù hợp nhất</td><td>Gia đình · người thành đạt</td><td>Người tập luyện · văn phòng</td><td>Cặp đôi · người ngủ nóng</td><td>Người trẻ · phòng cho thuê</td></tr>
      </tbody>
    </table>
  </div>
</div></section>
<?php return ob_get_clean();
}

/* JS: số nhảy liên tục (lab) + đếm 1 lần (showroom) */
add_action('wp_footer', function(){
    if (!(function_exists('is_front_page') && is_front_page())) return; ?>
<script>
(function(){
  var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function animate(el,to,dec,dur,cb){
    var t0=null;
    function step(ts){ if(!t0)t0=ts; var p=Math.min((ts-t0)/dur,1); var e=1-Math.pow(1-p,3); var v=to*e;
      el.textContent=(dec>0)?v.toFixed(dec):Math.round(v); if(p<1)requestAnimationFrame(step); else if(cb)cb(); }
    requestAnimationFrame(step);
  }
  /* LAB: chạy 0 -> số test, lặp liên tục */
  var nums=document.querySelectorAll('.pxf-num[data-to]');
  if(nums.length){
    var started=false;
    var io=new IntersectionObserver(function(es){es.forEach(function(e){
      if(!e.isIntersecting||started)return; started=true; io.disconnect();
      nums.forEach(function(el){
        var to=parseFloat(el.getAttribute('data-to'))||0, dec=parseInt(el.getAttribute('data-dec'),10)||0;
        if(reduce){ el.textContent=(dec>0)?to.toFixed(dec):to; return; }
        function loop(){ el.textContent=(dec>0)?(0).toFixed(dec):'0'; animate(el,to,dec,1300,function(){ setTimeout(loop,2200); }); }
        loop();
      });
    })},{threshold:.3});
    io.observe(nums[0].closest('.pxf-lab'));
  }
  /* SHOWROOM: đếm 1 lần */
  var counts=document.querySelectorAll('.pxf-count b[data-count]');
  if(counts.length){
    var seen=false;
    var io2=new IntersectionObserver(function(es){es.forEach(function(e){
      if(!e.isIntersecting||seen)return; seen=true; io2.disconnect();
      counts.forEach(function(el){
        var end=parseInt(el.getAttribute('data-count'),10)||0, suf=el.querySelector('i')?el.querySelector('i').outerHTML:'';
        if(reduce){ el.innerHTML=end+suf; return; }
        var t0=null;
        function step(ts){ if(!t0)t0=ts; var p=Math.min((ts-t0)/1100,1); var v=Math.round(end*(1-Math.pow(1-p,3))); el.innerHTML=v+suf; if(p<1)requestAnimationFrame(step); }
        requestAnimationFrame(step);
      });
    })},{threshold:.4});
    io2.observe(counts[0].closest('.pxf-count'));
  }
})();

/* SO SÁNH · VS ANALYZER */
(function(){
  var DATA={
    prime:{name:'POWER X PRIME',c:'#E60012',tier:'01 · FLAGSHIP',rank:1,price:23598000,priceTxt:'23.598.000₫',cao:'30cm',cung:'Medium',tech:'Lò xo kép + Cooling Gel + Aerospace Foam',fit:'Gia đình · người thành đạt',s:{'Mát lạnh':92,'Nâng đỡ':96,'Hồi phục cơ':95,'Êm ái':97,'Thoáng khí':92},f:[{ic:'🏆',t:'Đạt giải Red Dot 2019',d:'Thiết kế được công nhận toàn cầu'},{ic:'🧠',t:'Phục hồi sâu cơ thể',d:'Tái tạo năng lượng cho ngày làm việc cường độ cao'},{ic:'❄️',t:'Cooling Gel làm mát',d:'Không nóng lưng, ngủ sâu suốt đêm'},{ic:'⚙️',t:'Lò xo túi siêu nhỏ',d:'Nâng đỡ chính xác từng vùng cơ thể'}],tag:'flagship — đỉnh cao toàn diện của Power X'},
    fusion:{name:'POWER X FUSION',c:'#7d9b00',tier:'02 · PERFORMANCE',rank:2,price:16198000,priceTxt:'16.198.000₫',cao:'27cm',cung:'Medium',tech:'Graphene Foam + Lò xo túi 11 vùng + FlowEdge',fit:'Người tập luyện · văn phòng',s:{'Mát lạnh':84,'Nâng đỡ':92,'Hồi phục cơ':93,'Êm ái':88,'Thoáng khí':85},f:[{ic:'💪',t:'Phục hồi cơ bắp nhanh',d:'Hợp người hoạt động thể chất, máy móc cường độ cao'},{ic:'🦠',t:'Graphene kháng khuẩn',d:'Bề mặt sạch, mát, an toàn cho da'},{ic:'🛡️',t:'11 vùng nâng đỡ',d:'Cột sống thẳng tự nhiên, giảm đau lưng-vai'},{ic:'💑',t:'Không rung lan',d:'Bạn cùng giường trở mình không làm bạn thức'}],tag:'hồi phục cơ chuyên sâu cho người vận động'},
    flow:{name:'POWER X FLOW',c:'#1E9BD7',tier:'03 · ADVANCED',rank:3,price:9398000,priceTxt:'9.398.000₫',cao:'22cm',cung:'Medium-Firm',tech:'Memory Foam Graphene + Vỏ Tencel + AirWave',fit:'Cặp đôi · người ngủ nóng',s:{'Mát lạnh':90,'Nâng đỡ':78,'Hồi phục cơ':76,'Êm ái':80,'Thoáng khí':88},f:[{ic:'🌡️',t:'Mát lạnh cả đêm',d:'Vỏ Tencel + AirWave: hết nóng lưng, hết đổ mồ hôi'},{ic:'🤲',t:'Ôm sát cơ thể',d:'Giảm áp lực điểm tì đè ở vai và hông'},{ic:'🌿',t:'Vỏ Tencel mềm mịn',d:'Cảm giác dễ chịu ngay khi chạm vào'},{ic:'🔇',t:'Im lặng tuyệt đối',d:'Foam thuần — không tiếng kêu lò xo'}],tag:'tối ưu mát lạnh trong tầm giá'},
    core:{name:'POWER X CORE',c:'#C77D00',tier:'04 · ESSENTIAL',rank:4,price:6398000,priceTxt:'6.398.000₫',cao:'15cm',cung:'Firm',tech:'Foam 2 mặt + Rãnh CNC AirWave + Dual Comfort',fit:'Người trẻ · phòng cho thuê',s:{'Mát lạnh':72,'Nâng đỡ':70,'Hồi phục cơ':65,'Êm ái':68,'Thoáng khí':78},f:[{ic:'💰',t:'Giá hợp lý nhất',d:'Chất lượng Power X với mức đầu tư tối ưu'},{ic:'🔄',t:'Hai mặt linh hoạt',d:'Mặt thoáng & mặt phẳng cứng — đổi theo mùa'},{ic:'🖐️',t:'Rãnh CNC thông khí',d:'Massage nhẹ, lưu thông không khí suốt đêm'},{ic:'🏠',t:'Dễ vệ sinh',d:'Vỏ tháo giặt, lý tưởng phòng cho thuê'}],tag:'khởi đầu tối giản, dễ tiếp cận nhất'}
  };
  var state={a:'prime',b:'flow'};
  var bars=document.getElementById('vs-bars'), specs=document.getElementById('vs-specs'), feats=document.getElementById('vs-feats');
  if(!bars) return;
  function render(){
    var A=DATA[state.a], B=DATA[state.b];
    var an=document.getElementById('vsa-name'), bn=document.getElementById('vsb-name');
    an.textContent=A.name; an.style.color=A.c; bn.textContent=B.name; bn.style.color=B.c;
    var at=document.getElementById('vsa-tier'), bt=document.getElementById('vsb-tier');
    at.textContent=A.tier; at.style.setProperty('--tc',A.c); bt.textContent=B.tier; bt.style.setProperty('--tc',B.c);
    document.querySelectorAll('.vs-chips[data-side="a"] .vchip').forEach(function(ch){ch.classList.toggle('on',ch.dataset.p===state.a)});
    document.querySelectorAll('.vs-chips[data-side="b"] .vchip').forEach(function(ch){ch.classList.toggle('on',ch.dataset.p===state.b)});
    var h='';
    Object.keys(A.s).forEach(function(k){
      var av=A.s[k], bv=B.s[k];
      h+='<div class="vrow"><div class="vbar left'+(av>bv?' win':'')+'" style="--c:'+A.c+'"><i data-w="'+av+'"></i><span class="vnum">'+av+'</span></div><div class="vlab">'+k+'</div><div class="vbar right'+(bv>av?' win':'')+'" style="--c:'+B.c+'"><i data-w="'+bv+'"></i><span class="vnum">'+bv+'</span></div></div>';
    });
    bars.innerHTML=h;
    requestAnimationFrame(function(){requestAnimationFrame(function(){ bars.querySelectorAll('.vbar i').forEach(function(i){i.style.width=i.dataset.w+'%'}); });});
    function row(k,va,vb,ba,bb){ return '<div class="vspec"><span class="va'+(ba?' better':'')+'">'+va+'</span><span class="k">'+k+'</span><span class="vb'+(bb?' better':'')+'">'+vb+'</span></div>'; }
    specs.innerHTML=row('Phân khúc',A.tier.split('· ')[1],B.tier.split('· ')[1],A.rank<B.rank,B.rank<A.rank)+row('Giá từ',A.priceTxt,B.priceTxt,A.price<B.price,B.price<A.price)+row('Độ cao',A.cao,B.cao,false,false)+row('Độ cứng',A.cung,B.cung,false,false)+row('Công nghệ',A.tech,B.tech,false,false)+row('Phù hợp nhất',A.fit,B.fit,false,false);
    function ul(M,right){ var s='<ul'+(right?' class="right"':'')+'>'; M.f.forEach(function(x){ s+='<li><span class="fic">'+x.ic+'</span><span class="ft"><b>'+x.t+'</b><span>'+x.d+'</span></span></li>'; }); return s+'</ul>'; }
    feats.innerHTML=ul(A,false)+'<div class="fk">Tính năng<br>nổi bật</div>'+ul(B,true);
    var wa=0,wb=0; Object.keys(A.s).forEach(function(k){ if(A.s[k]>B.s[k])wa++; else if(B.s[k]>A.s[k])wb++; });
    var W=(A.rank<B.rank)?A:B, L=(W===A)?B:A, wins=(W===A)?wa:wb;
    document.getElementById('vs-verdict-text').innerHTML='<b style="color:'+W.c+'">'+W.name+'</b> đứng phân khúc cao hơn, thắng '+wins+'/5 chỉ số — '+W.tag+'. <b style="color:'+L.c+'">'+L.name.replace('POWER X ','')+'</b> là lựa chọn nếu bạn cần '+L.tag+'.';
  }
  document.querySelectorAll('.vs-chips .vchip').forEach(function(ch){
    ch.addEventListener('click',function(){ var side=ch.closest('.vs-chips').dataset.side, p=ch.dataset.p, other=side==='a'?'b':'a'; if(state[other]===p){state[other]=state[side];} state[side]=p; render(); });
  });
  var vsEl=document.querySelector('.vs');
  var io=new IntersectionObserver(function(es){es.forEach(function(e){ if(e.isIntersecting){render();io.unobserve(vsEl);} })},{threshold:.25});
  io.observe(vsEl); render();
  var tb=document.getElementById('tbl-toggle'), tbl=document.getElementById('fulltable');
  if(tb){ tb.addEventListener('click',function(){ var open=tbl.classList.toggle('collapsed'); tb.classList.toggle('open',!open); tb.firstChild.textContent=open?'Xem bảng so sánh đầy đủ 4 dòng ':'Ẩn bảng so sánh '; }); }
})();
</script>
<?php });
