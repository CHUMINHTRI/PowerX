<?php
/** Power X — hiển thị giá variable = giá thấp nhất CÒN TỒN KHO (thay vì range) */
if (!defined('ABSPATH')) exit;

function powerx_min_instock_price($product){
    if(!$product || !$product->is_type('variable')) return null;
    $min=null;
    foreach($product->get_available_variations() as $v){
        if(empty($v['is_in_stock'])) continue;
        $p = floatval($v['display_price']);
        if($p>0 && ($min===null || $p<$min)) $min=$p;
    }
    if($min===null){
        // fallback: nếu không có variation nào in_stock, lấy giá thấp nhất bất kỳ
        $prices=$product->get_variation_prices(true);
        if(!empty($prices['price'])) $min = floatval(min($prices['price']));
    }
    return $min;
}

add_filter('woocommerce_variable_sale_price_html','powerx_variable_price_html',10,2);
add_filter('woocommerce_variable_price_html','powerx_variable_price_html',10,2);
function powerx_variable_price_html($price_html,$product){
    $min = powerx_min_instock_price($product);
    if($min===null) return $price_html;
    return '<span class="px-price-from">từ </span>'.wc_price($min);
}
