<?php
/**
 * Power X — Đào tạo bán hàng (nội bộ)
 * - Tải file .html lên: (A) Bảng tin → Đào tạo bán hàng (đáng tin cậy nhất), HOẶC
 *   (B) Tùy biến → Liên hệ → ô "Đào tạo bán hàng — Tải file HTML".
 * - Nội dung lưu riêng tư trong DB, phục vụ qua URL có kiểm tra ĐĂNG NHẬP QUẢN TRỊ.
 * - Link hiển thị trong menu Tài khoản (mở ở tab mới).
 */
if (!defined('ABSPATH')) exit;

function powerx_training_url(){ return home_url('/?powerx_training=1'); }
function powerx_training_enabled(){ return get_theme_mod('powerx_training_enabled','1')==='1'; }
/* Ai được xem: tài khoản quản trị WordPress (administrator) */
function powerx_training_can_view(){ return is_user_logged_in() && current_user_can('manage_options'); }

/* File HTML mặc định nhúng sẵn trong theme (assets/training-app.html) */
function powerx_training_bundled_path(){ return get_template_directory().'/assets/training-app.html'; }

/* Lấy nội dung HTML: ưu tiên (1) file admin tải lên, (2) file chọn trong Customizer, (3) file nhúng sẵn */
function powerx_training_get_html(){
    $html = get_option('powerx_training_html','');
    if ($html !== '') return $html;
    $id = (int) get_theme_mod('powerx_training_attach', 0);
    if ($id > 0) {
        $path = get_attached_file($id);
        if ($path && file_exists($path)) { $c = file_get_contents($path); if ($c !== false && $c !== '') return $c; }
    }
    $bp = powerx_training_bundled_path();
    if (file_exists($bp)) { $c = file_get_contents($bp); if ($c !== false) return $c; }
    return '';
}
/* Kiểm tra nhanh có nội dung hay không (không đọc cả file) */
function powerx_training_has_file(){
    if (get_option('powerx_training_html','') !== '') return true;
    $id = (int) get_theme_mod('powerx_training_attach', 0);
    if ($id > 0 && get_attached_file($id)) return true;
    return file_exists(powerx_training_bundled_path());
}

/* Cho phép quản trị viên tải file .html / .htm lên Thư viện (mặc định WP chặn) */
add_filter('upload_mimes', function($mimes){
    if (current_user_can('manage_options')) { $mimes['html']='text/html'; $mimes['htm']='text/html'; }
    return $mimes;
});
add_filter('wp_check_filetype_and_ext', function($data,$file,$filename,$mimes){
    if (current_user_can('manage_options')) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (in_array($ext, array('html','htm'), true)) { $data['ext']='html'; $data['type']='text/html'; }
    }
    return $data;
}, 10, 4);

/* Customizer: sau khi Đăng, sao nội dung file đã chọn vào DB rồi xoá file công khai */
add_action('customize_save_after', function($manager){
    $id = (int) get_theme_mod('powerx_training_attach', 0);
    if ($id <= 0 && is_object($manager)) {
        $s = $manager->get_setting('powerx_training_attach');
        if ($s) { $pv = $s->post_value(); if ($pv) $id = (int) $pv; }
    }
    if ($id <= 0) return;
    $path = get_attached_file($id);
    if ($path && file_exists($path)) {
        $content = file_get_contents($path);
        if ($content !== false && $content !== '') {
            update_option('powerx_training_html', $content, false);
            update_option('powerx_training_name', basename($path));
            update_option('powerx_training_time', current_time('mysql'));
            wp_delete_attachment($id, true);
            set_theme_mod('powerx_training_attach', 0);
        }
    }
});

/* ===== (A) Trang Admin tải file lên — đáng tin cậy ===== */
add_action('admin_menu', function(){
    add_menu_page('Đào tạo bán hàng','Đào tạo bán hàng','manage_options','powerx-training','powerx_training_admin_page','dashicons-welcome-learn-more',58);
});
function powerx_training_admin_page(){
    if (!current_user_can('manage_options')) return;
    if (isset($_POST['powerx_training_nonce']) && wp_verify_nonce($_POST['powerx_training_nonce'],'powerx_training_save')) {
        update_theme_mod_safe();
        if (isset($_POST['powerx_training_delete'])) {
            delete_option('powerx_training_html'); delete_option('powerx_training_name'); delete_option('powerx_training_time');
            echo '<div class="notice notice-success is-dismissible"><p>Đã xoá nội dung đào tạo.</p></div>';
        } elseif (!empty($_FILES['powerx_training_file']['tmp_name']) && is_uploaded_file($_FILES['powerx_training_file']['tmp_name'])) {
            $f=$_FILES['powerx_training_file']; $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
            if (!in_array($ext,array('html','htm'),true)) {
                echo '<div class="notice notice-error"><p>Chỉ chấp nhận file .html hoặc .htm.</p></div>';
            } elseif ($f['size'] > 12*1024*1024) {
                echo '<div class="notice notice-error"><p>File quá lớn (tối đa 12MB).</p></div>';
            } else {
                $content=file_get_contents($f['tmp_name']);
                if ($content===false || $content==='') { echo '<div class="notice notice-error"><p>Không đọc được nội dung file.</p></div>'; }
                else {
                    update_option('powerx_training_html',$content,false);
                    update_option('powerx_training_name',sanitize_file_name($f['name']));
                    update_option('powerx_training_time',current_time('mysql'));
                    echo '<div class="notice notice-success is-dismissible"><p>✅ Đã tải lên: <b>'.esc_html($f['name']).'</b></p></div>';
                }
            }
        } else {
            echo '<div class="notice notice-success is-dismissible"><p>Đã lưu cài đặt.</p></div>';
        }
    }
    $name=get_option('powerx_training_name',''); $time=get_option('powerx_training_time','');
    $size=strlen(get_option('powerx_training_html','')); $url=powerx_training_url();
    $enabled=powerx_training_enabled();
    ?>
    <div class="wrap">
        <h1>Đào tạo bán hàng (nội bộ)</h1>
        <p>Tải lên 1 file <b>.html</b> (app đào tạo khép kín). Chỉ <b>tài khoản quản trị</b> đã đăng nhập mới xem được. Link sẽ hiện trong menu <b>Tài khoản</b> và mở ở tab mới.</p>
        <?php if ($name && $size>0): ?>
        <div class="card" style="max-width:680px;padding:12px 18px;margin:14px 0">
            <p style="margin:.3em 0"><b>File hiện tại:</b> <?php echo esc_html($name); ?> (<?php echo esc_html(size_format($size)); ?>)</p>
            <?php if ($time): ?><p style="margin:.3em 0"><b>Cập nhật:</b> <?php echo esc_html($time); ?></p><?php endif; ?>
            <p style="margin:.3em 0"><b>Xem thử:</b> <a href="<?php echo esc_url($url); ?>" target="_blank"><?php echo esc_html($url); ?></a></p>
        </div>
        <?php else: ?><p><em>Chưa có file nào được lưu.</em></p><?php endif; ?>
        <form method="post" enctype="multipart/form-data" style="max-width:680px">
            <?php wp_nonce_field('powerx_training_save','powerx_training_nonce'); ?>
            <table class="form-table" role="presentation">
                <tr><th scope="row"><label for="ptf">Chọn file .html</label></th>
                    <td><input type="file" name="powerx_training_file" id="ptf" accept=".html,.htm">
                        <p class="description">Nên là HTML khép kín (CSS/JS/ảnh nhúng sẵn).</p></td></tr>
                <tr><th scope="row">Hiển thị</th>
                    <td><label><input type="checkbox" name="powerx_training_enabled" value="1" <?php checked($enabled); ?>> Bật mục Đào tạo bán hàng</label></td></tr>
            </table>
            <p class="submit">
                <button type="submit" class="button button-primary">Lưu &amp; Tải lên</button>
                <?php if ($name): ?><button type="submit" name="powerx_training_delete" value="1" class="button" style="margin-left:8px;color:#b32d2e" onclick="return confirm('Xoá nội dung hiện tại?');">Xoá nội dung</button><?php endif; ?>
            </p>
        </form>
    </div>
    <?php
}
/* Lưu trạng thái bật/tắt (theme_mod) từ trang admin */
function update_theme_mod_safe(){
    set_theme_mod('powerx_training_enabled', isset($_POST['powerx_training_enabled']) ? '1' : '0');
}

/* ===== Phục vụ app — chỉ tài khoản quản trị đã đăng nhập ===== */
add_action('template_redirect', function(){
    if (!isset($_GET['powerx_training'])) return;
    if (!powerx_training_enabled()) { status_header(404); wp_die('Mục đào tạo hiện đang tắt.'); }
    if (!is_user_logged_in()) { wp_safe_redirect( wp_login_url( powerx_training_url() ) ); exit; }
    if (!current_user_can('manage_options')) { wp_die('Trang đào tạo chỉ dành cho tài khoản quản trị Power X.'); }
    $html = powerx_training_get_html();
    if ($html === '') { wp_die('Chưa có nội dung đào tạo. Vào Bảng tin → Đào tạo bán hàng để tải file HTML lên.'); }
    nocache_headers(); status_header(200);
    header('Content-Type: text/html; charset=utf-8');
    header('X-Robots-Tag: noindex, nofollow', true);
    echo $html; exit;
});

/* Mở link đào tạo ở tab mới */
add_action('wp_footer', function(){
    if (!function_exists('is_account_page') || !is_account_page()) return;
    ?><script>document.querySelectorAll('.woocommerce-MyAccount-navigation a[href*="powerx_training=1"]').forEach(function(a){a.target="_blank";a.rel="noopener";});</script><?php
});
