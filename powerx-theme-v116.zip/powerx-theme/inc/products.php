<?php
/** Power X — thông số thẻ + nội dung tagline/persona/features cho trang chi tiết */
if (!defined('ABSPATH')) exit;

/* ===== Chỉ số tạo niềm tin: đã bán + đánh giá (ổn định theo sản phẩm) ===== */
function powerx_compact_num($n){
    $n=(int)$n;
    if($n>=1000){ $v=$n/1000; $s=rtrim(rtrim(number_format($v,1,',',''),'0'),','); return $s.'k'; }
    return number_format($n,0,',','.');
}
function powerx_trust_sold($product){
    if(!$product) return 0; $id=$product->get_id();
    // Số đã bán cố định theo từng sản phẩm (tổng 1000)
    $map = array(
        'power-x-prime'  => 64,
        'power-x-fusion' => 81,
        'power-x-flow'   => 182,
        'power-x-core'   => 261,
        'power-x-ergo'   => 491,
        'power-x-matrix' => 223,
    );
    $slug = $product->get_slug();
    if(isset($map[$slug])) return $map[$slug];
    $real=(int)get_post_meta($id,'total_sales',true);
    if($real>80) return $real;
    return 480 + ($id*37 % 2200); // dự phòng cho sản phẩm khác
}
function powerx_trust_reviews($product){
    if(!$product) return array('count'=>0,'avg'=>0);
    $id=$product->get_id(); $cnt=(int)$product->get_review_count(); $avg=(float)$product->get_average_rating();
    if($cnt>=3) return array('count'=>$cnt,'avg'=>($avg>0?$avg:4.8));
    return array('count'=>32 + ($id*13 % 260), 'avg'=>round(4.6 + (($id*7)%4)/10, 1));
}
function powerx_trust_html($product,$class=''){
    if(!$product || !function_exists('wc_get_rating_html')) return '';
    $r=powerx_trust_reviews($product); $sold=powerx_trust_sold($product);
    return '<div class="px-trust-stats '.esc_attr($class).'">'
         . '<span class="px-ts-stars">'.wc_get_rating_html($r['avg']).'</span>'
         . '<span class="px-ts-rev">'.powerx_compact_num($r['count']).' đánh giá</span>'
         . '<span class="px-ts-dot">·</span>'
         . '<span class="px-ts-sold">Đã bán '.powerx_compact_num($sold).'</span>'
         . '</div>';
}
/* Phân bố sao ảo (ổn định theo sản phẩm) — đa số 5 sao, ít 4, rất ít 3 */
function powerx_trust_dist($product){
    $r=powerx_trust_reviews($product); $c=(int)$r['count']; if($c<1) $c=1;
    $five = (int)round($c*0.82);
    $four = (int)round($c*0.14);
    $three= max(0, $c-$five-$four);
    return array(5=>$five,4=>$four,3=>$three,2=>0,1=>0);
}
/* Bộ đánh giá ảo (nội dung gốc, ổn định theo ID) — dùng khi sản phẩm chưa có đánh giá thật */
function powerx_fake_reviews($product, $limit=20){
    if(!$product) return array();
    $id=$product->get_id();
    $names=array('Nguyễn Minh Khôi','Trần Thị Hương','Lê Hoàng Nam','Phạm Thu Trang','Vũ Đức Anh','Đặng Khánh Linh','Bùi Quốc Bảo','Hồ Ngọc Mai','Dương Thành Đạt','Phan Thị Yến','Ngô Gia Huy','Lý Phương Thảo','Đỗ Văn Tú','Cao Thị Hà','Trịnh Minh Quân','Hà Thuỳ Dung','Võ Tấn Phát','Mai Kim Chi','Đinh Hữu Lộc','Tô Bích Ngọc','Nguyễn Hải Đăng','Trương Mỹ Linh','Phùng Anh Tuấn','Lương Thị Thuỷ','Châu Gia Hân','Tạ Quang Vinh','Nguyễn Thị Lan','Hoàng Văn Sơn','Đoàn Thanh Tâm','Kiều Thị Nhung','Lâm Chí Cường','Bùi Thị Diễm','Phạm Hồng Phúc','Vương Tuấn Kiệt','Trần Bảo Châu','Lê Thị Kim Oanh');
    $titles=array('Ngủ ngon hẳn sau 1 tuần','Đáng đồng tiền','Chất lượng vượt mong đợi','Giao nhanh, đóng gói kỹ','Êm và thoáng','Hết đau lưng buổi sáng','Cả nhà đều thích','Sẽ mua thêm cái nữa','Form chắc, nằm rất đã','Trải nghiệm như khách sạn 5 sao','Quá hài lòng','Nằm là nghiện','Mua không hối hận','Đúng như mô tả','Ưng từ cái nhìn đầu tiên','Ngủ sâu hơn rõ rệt','Mát lưng, không bí','Bố mẹ mình rất thích','Xứng đáng 5 sao','Nâng đỡ cột sống tốt','Tốt hơn nệm cũ nhiều','Đáng tiền hơn hàng ngoại','Sản phẩm chất lượng','Đẹp và bền');
    $bodies=array(
        'Mình bị đau lưng kinh niên, nằm được hơn tuần thì sáng dậy nhẹ người hẳn. Nệm nâng đỡ tốt, không bị lún sâu.',
        'Bề mặt thoáng mát, nằm điều hoà hay không cũng không bị bí. Ban đêm trở mình không thấy ồn. Rất hài lòng.',
        'Đặt online hơi lo nhưng nhận hàng thấy đóng gói chắc chắn, giao đúng hẹn. Nằm thử là ưng liền.',
        'Hai vợ chồng nằm thoải mái, một người trở mình người kia không bị rung. Độ cứng vừa phải, đỡ lưng.',
        'Giá tốt hơn mấy hãng ngoại mà chất lượng không thua. Bảo hành dài nên yên tâm. Recommend cho mọi người.',
        'Con mình ngủ sâu hơn hẳn từ khi đổi nệm này. Chất liệu không mùi, an tâm cho cả nhà.',
        'Nằm chắc lưng, không bị nóng lưng như nệm cũ. Sau 1 tháng vẫn giữ form rất tốt, không xẹp.',
        'Tư vấn nhiệt tình, chọn đúng độ cứng mình cần. Sản phẩm xịn, đáng tiền, sẽ ủng hộ tiếp.',
        'Mê nhất là độ thoáng khí, mùa nóng nằm vẫn mát. Đường may đẹp, vỏ tháo giặt tiện.',
        'Trước hay lăn lộn khó ngủ, giờ đặt lưng xuống là vào giấc nhanh. Quá ổn trong tầm giá.',
        'Sản phẩm đúng như hình, chất lượng thật sự tốt. Nhân viên giao hàng còn hỗ trợ kê lên giường giúp.',
        'Nằm gần 2 tháng rồi, vẫn êm và giữ phom nguyên vẹn. Không hề bị xẹp lún ở giữa như mình lo ban đầu.',
        'Mình ngủ hay bị nóng, nệm này thoáng khí thật, lưng khô ráo cả đêm. Rất đáng tiền.',
        'Lần đầu mua nệm online mà ưng quá. Đóng gói cẩn thận, bung ra là nằm được luôn, không mùi khó chịu.',
        'Mẹ mình lớn tuổi hay đau hông, đổi sang nệm này ngủ ngon hẳn, sáng dậy đỡ ê ẩm hơn nhiều.',
        'Độ cứng vừa người, nâng đỡ cột sống rõ ràng. Mình tập gym hay mỏi lưng, giờ phục hồi nhanh hơn.',
        'Giao hàng nhanh ngoài mong đợi, đặt hôm trước hôm sau có. Chất lượng tương xứng với giá tiền.',
        'Phòng có máy lạnh nằm cực thích, bề mặt mềm vừa phải mà vẫn chắc. Gia đình ai cũng khen.',
        'So với nệm lò xo cũ thì một trời một vực. Êm mà không bị ọp ẹp, trở mình không phát ra tiếng.',
        'Mua cho phòng khách sạn mini của mình, khách phản hồi ngủ rất ngon. Sẽ đặt thêm vài cái nữa.',
        'Chất liệu cao cấp, sờ vào là biết hàng tốt. Bảo hành dài hạn nên rất yên tâm khi xuống tiền.',
        'Bé nhà mình hết lăn xuống đất ban đêm vì nệm rộng rãi và êm. Cả nhà ngủ ngon từ ngày đổi nệm.',
        'Mình kén nệm lắm mà cái này hợp gu thật. Không quá mềm không quá cứng, nằm phát là buồn ngủ.',
        'Đáng từng đồng. Sau thời gian dùng thử mình tự tin giới thiệu cho bạn bè và người thân.',
    );
    $r=powerx_trust_reviews($product); $avg=(float)$r['avg'];
    $n=min($limit, max(8, (int)floor($r['count']/12)+8)); // ~8..20 bài
    $out=array(); $now=time();
    for($i=0;$i<$n;$i++){
        $ni=($id*7+$i*3) % count($names);
        $ti=($id*5+$i*2) % count($titles);
        $bi=($id*11+$i) % count($bodies);
        $star = ($i%6===5) ? 4 : 5; // đa số 5 sao, thỉnh thoảng 4
        $days = 4 + (($id*13+$i*17) % 220); // 4..223 ngày trước
        $out[]=array(
            'name'=>$names[$ni],
            'title'=>$titles[$ti],
            'body'=>$bodies[$bi],
            'stars'=>$star,
            'date'=>date_i18n('d/m/Y', $now - $days*86400),
            'verified'=>true,
        );
    }
    return $out;
}
function powerx_fake_reviews_html($product, $show=6){
    $list=powerx_fake_reviews($product); if(empty($list)) return '';
    $total=count($list); $i=0;
    $h='<div class="px-rs-list">';
    foreach($list as $rv){
        $hidden = ($i>=$show) ? ' px-rv--more" hidden="hidden' : '';
        $h.='<article class="px-rv'.$hidden.'">'
          . '<div class="px-rv-head">'
          . '<span class="px-rv-avatar">'.esc_html(mb_substr($rv['name'],0,1)).'</span>'
          . '<div class="px-rv-id"><b class="px-rv-name">'.esc_html($rv['name']).'</b>'
          . ($rv['verified']?'<span class="px-rv-verified">✓ Đã mua hàng</span>':'').'</div>'
          . '<span class="px-rv-date">'.esc_html($rv['date']).'</span>'
          . '</div>'
          . wc_get_rating_html($rv['stars'])
          . '<h4 class="px-rv-title">'.esc_html($rv['title']).'</h4>'
          . '<p class="px-rv-body">'.esc_html($rv['body']).'</p>'
          . '</article>';
        $i++;
    }
    $h.='</div>';
    if($total>$show){
        $rest=$total-$show;
        $h.='<button type="button" class="px-rs-more" data-rest="'.$rest.'">Xem thêm '.$rest.' đánh giá ▾</button>';
    }
    return $h;
}

add_action('add_meta_boxes', function(){
    add_meta_box('powerx_specs','Power X – Thông số thẻ','powerx_specs_box','product','side','default');
    add_meta_box('powerx_content','Power X – Nội dung Casper-style','powerx_content_box','product','normal','high');
});
function powerx_specs_box($post){
    wp_nonce_field('powerx_specs','powerx_specs_nonce');
    $f=array('px_pill'=>'Nhãn (pill), vd: PRIME','px_height'=>'Chiều cao, vd: 30cm','px_type'=>'Loại, vd: Hybrid','px_hardness'=>'Độ cứng, vd: Medium');
    foreach($f as $k=>$lbl){ $v=esc_attr(get_post_meta($post->ID,$k,true));
        echo '<p><label style="display:block;font-weight:600;margin-bottom:3px">'.esc_html($lbl).'</label>';
        echo '<input type="text" name="'.$k.'" value="'.$v.'" style="width:100%"></p>';
    }
}
function powerx_content_box($post){
    wp_nonce_field('powerx_content','powerx_content_nonce');
    $f=array(
        'px_tagline_en'=>array('Tagline tiếng Anh','VD: Prime Level. Sleep Like a Pro.','text'),
        'px_tagline_vi'=>array('Phụ đề tiếng Việt','VD: Đẳng cấp giấc ngủ — tái tạo năng lượng.','text'),
        'px_persona'=>array('Sản phẩm này dành cho ai (mỗi dòng 1 ý)','VD:\nDoanh nhân, vận động viên chuyên nghiệp\nGia đình hiện đại','textarea'),
        'px_xfeatures'=>array('X-Features (mỗi dòng: Mã | Mô tả)','VD:\nX-Touch | Lớp chần foam mát lạnh\nX-PrimeSpring | Hệ lò xo kép','textarea'),
        'px_warranty'=>array('Bảo hành','VD: 10 năm','text'),
        'px_video'=>array('Video sản phẩm (link YouTube/Vimeo hoặc URL .mp4)','VD: https://youtu.be/xxxx  hoặc  https://.../video.mp4 — hiện trong khung ảnh sản phẩm','text'),
    );
    foreach($f as $k=>$row){ $v=esc_attr(get_post_meta($post->ID,$k,true));
        echo '<p><label style="display:block;font-weight:600;margin-bottom:3px">'.esc_html($row[0]).'</label>';
        if($row[2]==='textarea') echo '<textarea name="'.$k.'" rows="4" style="width:100%">'.esc_textarea(get_post_meta($post->ID,$k,true)).'</textarea>';
        else echo '<input type="text" name="'.$k.'" value="'.$v.'" style="width:100%">';
        echo '<small style="color:#888">'.esc_html($row[1]).'</small></p>';
    }
}
add_action('save_post_product', function($id){
    if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE) return;
    if(isset($_POST['powerx_specs_nonce'])&&wp_verify_nonce($_POST['powerx_specs_nonce'],'powerx_specs')){
        foreach(array('px_pill','px_height','px_type','px_hardness') as $k){
            if(isset($_POST[$k])) update_post_meta($id,$k,sanitize_text_field($_POST[$k]));
        }
    }
    if(isset($_POST['powerx_content_nonce'])&&wp_verify_nonce($_POST['powerx_content_nonce'],'powerx_content')){
        foreach(array('px_tagline_en','px_tagline_vi','px_warranty') as $k){
            if(isset($_POST[$k])) update_post_meta($id,$k,sanitize_text_field($_POST[$k]));
        }
        foreach(array('px_persona','px_xfeatures') as $k){
            if(isset($_POST[$k])) update_post_meta($id,$k,sanitize_textarea_field($_POST[$k]));
        }
        if(isset($_POST['px_video'])) update_post_meta($id,'px_video',esc_url_raw(trim($_POST['px_video'])));
    }
});

/* Tạo mã nhúng video từ link YouTube/Vimeo hoặc file MP4 */
function powerx_video_embed_html($url){
    $url=trim((string)$url); if($url==='') return '';
    if(preg_match('~(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/|youtube\.com/shorts/)([\w-]{11})~',$url,$m)){
        return '<div class="px-video-frame"><iframe data-src="https://www.youtube.com/embed/'.$m[1].'?rel=0&playsinline=1" title="Video sản phẩm" frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></div>';
    }
    if(preg_match('~vimeo\.com/(?:video/)?(\d+)~',$url,$m)){
        return '<div class="px-video-frame"><iframe data-src="https://player.vimeo.com/video/'.$m[1].'" title="Video sản phẩm" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe></div>';
    }
    if(preg_match('~\.(mp4|webm|ogg)(\?.*)?$~i',$url)){
        return '<div class="px-video-frame"><video controls playsinline preload="metadata" src="'.esc_url($url).'"></video></div>';
    }
    $oe = wp_oembed_get($url);
    return $oe ? '<div class="px-video-frame">'.$oe.'</div>' : '';
}

/* Ảnh bìa (poster) tự suy ra từ link video — YouTube có ảnh sẵn; MP4/Vimeo trả rỗng (xử lý bằng frame đầu) */
function powerx_video_poster($url){
    $url=trim((string)$url); if($url==='') return '';
    if(preg_match('~(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/|youtube\.com/shorts/)([\w-]{11})~',$url,$m)){
        return 'https://img.youtube.com/vi/'.$m[1].'/hqdefault.jpg';
    }
    return '';
}
function powerx_is_mp4($url){ return (bool)preg_match('~\.(mp4|webm|ogg)(\?.*)?$~i', trim((string)$url)); }

/* Media nền cho 1 slide Hero. Trả về array('html'=>..., 'is_video'=>bool).
   - Nếu có $video: MP4 -> <video autoplay muted loop>; YouTube/Vimeo -> iframe nền phủ kín.
   - Nếu không: dùng ảnh nền $img. */
function powerx_hero_media($video,$img){
    $video=trim((string)$video); $img=trim((string)$img);
    if($video!==''){
        if(powerx_is_mp4($video)){
            $poster = $img!=='' ? ' poster="'.esc_url($img).'"' : '';
            return array('is_video'=>true,'html'=>
                '<video class="px-hero-video" autoplay muted loop playsinline preload="auto"'.$poster.'>'
                .'<source src="'.esc_url($video).'" type="video/mp4"></video>');
        }
        if(preg_match('~(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/|youtube\.com/shorts/)([\w-]{11})~',$video,$m)){
            $id=$m[1];
            $src='https://www.youtube.com/embed/'.$id.'?autoplay=1&mute=1&controls=0&loop=1&playlist='.$id.'&playsinline=1&rel=0&showinfo=0&modestbranding=1&iv_load_policy=3';
            return array('is_video'=>true,'html'=>'<div class="px-hero-yt"><iframe src="'.esc_url($src).'" title="Hero video" frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></div>');
        }
        if(preg_match('~vimeo\.com/(?:video/)?(\d+)~',$video,$m)){
            $src='https://player.vimeo.com/video/'.$m[1].'?autoplay=1&muted=1&loop=1&background=1';
            return array('is_video'=>true,'html'=>'<div class="px-hero-yt"><iframe src="'.esc_url($src).'" title="Hero video" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe></div>');
        }
    }
    return array('is_video'=>false,'html'=>'', 'img'=>$img);
}
/* HTML ảnh bìa cho ô gallery: ưu tiên ảnh đã chọn → poster YouTube → frame đầu của MP4 → placeholder */
function powerx_gallery_cover_html($img,$vid,$alt){
    $img=trim((string)$img); $vid=trim((string)$vid);
    if($img!=='') return '<img src="'.esc_url($img).'" alt="'.esc_attr($alt).'">';
    $poster = powerx_video_poster($vid);
    if($poster!=='') return '<img src="'.esc_url($poster).'" alt="'.esc_attr($alt).'">';
    if(powerx_is_mp4($vid)) return '<video src="'.esc_url($vid).'#t=4" muted playsinline preload="metadata"></video>';
    return '<img src="'.esc_url(wc_placeholder_img_src()).'" alt="'.esc_attr($alt).'">';
}

/* Tagline tiếng Anh + phụ đề tiếng Việt NGAY DƯỚI TIÊU ĐỀ trang chi tiết */
add_action('woocommerce_single_product_summary','powerx_single_tagline',6);
function powerx_single_tagline(){
    global $product; $id=$product->get_id();
    $en=get_post_meta($id,'px_tagline_en',true); $vi=get_post_meta($id,'px_tagline_vi',true);
    if(!$en&&!$vi) return;
    echo '<div class="px-single-tagline">';
    if($en) echo '<div class="px-tag-en">'.esc_html($en).'</div>';
    if($vi) echo '<div class="px-tag-vi">'.esc_html($vi).'</div>';
    echo '</div>';
}

/* Khối thông số (Cao/Loại/Độ cứng) */
add_action('woocommerce_single_product_summary','powerx_single_specs',25);
function powerx_single_specs(){
    global $product; $id=$product->get_id();
    $h=get_post_meta($id,'px_height',true);$t=get_post_meta($id,'px_type',true);$hd=get_post_meta($id,'px_hardness',true);$w=get_post_meta($id,'px_warranty',true);
    if(trim((string)$w)!=='' && mb_strtolower(trim($w))==='trọn đời') $w='10 năm';
    if(!$h&&!$t&&!$hd&&!$w) return;
    echo '<div class="px-card-specs px-single-specs">';
    if($h) echo '<div><b>'.esc_html($h).'</b><small>Cao</small></div>';
    if($t) echo '<div><b>'.esc_html($t).'</b><small>Loại</small></div>';
    if($hd)echo '<div><b>'.esc_html($hd).'</b><small>Độ cứng</small></div>';
    if($w) echo '<div><b>'.esc_html($w).'</b><small>Bảo hành</small></div>';
    echo '</div>';
}

/* Sau phần short description: persona "Dành cho ai" + X-Features */
add_action('woocommerce_single_product_summary','powerx_single_persona_xfeat',45);
function powerx_single_persona_xfeat(){
    global $product; $id=$product->get_id();
    $persona=get_post_meta($id,'px_persona',true); $xf=get_post_meta($id,'px_xfeatures',true);
    if($persona){
        echo '<div class="px-block"><h4>👤 Dành cho ai</h4><ul>';
        foreach(preg_split('/\r?\n/',$persona) as $line){ $line=trim($line); if($line!=='') echo '<li>'.esc_html($line).'</li>'; }
        echo '</ul></div>';
    }
    if($xf){
        echo '<div class="px-block"><h4>⭐ X-Features</h4><dl class="px-xfeat">';
        foreach(preg_split('/\r?\n/',$xf) as $line){
            $parts=array_map('trim',explode('|',$line,2));
            if(count($parts)===2 && $parts[0]!==''){
                echo '<dt>'.esc_html($parts[0]).'</dt><dd>'.esc_html($parts[1]).'</dd>';
            }
        }
        echo '</dl></div>';
    }
}
