<?php
/** Power X — Trang chi tiết sản phẩm bố cục kiểu Bedgear (giữ nguyên text & màu hiện có).
 *  Gồm: 2 cột (gallery | tóm tắt) · hàng icon tính năng · cam kết · accordion ·
 *  khối "Cấu tạo bên trong" · các khối tính năng zigzag · Review Snapshot · thanh CTA dính đáy. */
if (!defined('ABSPATH')) exit;

/* ============================================================
   META BOX: Khối hình ảnh Bedgear (exploded + 4 khối tính năng)
   ============================================================ */
add_action('add_meta_boxes', function(){
    add_meta_box('powerx_blocks','Power X – Khối hình ảnh (Bedgear style)','powerx_blocks_box','product','normal','default');
});
function powerx_blocks_img_field($post_id,$id,$label){
    $val = get_post_meta($post_id,$id,true);
    echo '<div class="px-imgfield" style="margin:6px 0 14px">';
    echo '<label style="display:block;font-weight:600;margin-bottom:4px">'.esc_html($label).'</label>';
    echo '<input type="hidden" class="px-img-input" name="'.esc_attr($id).'" value="'.esc_attr($val).'">';
    echo '<div class="px-img-prev" style="margin-bottom:6px">'.($val?'<img src="'.esc_url($val).'" style="max-width:160px;height:auto;border:1px solid #ddd;border-radius:4px">':'').'</div>';
    echo '<button type="button" class="button px-img-pick">Chọn ảnh</button> <button type="button" class="button px-img-clear">Xoá ảnh</button></div>';
}
function powerx_blocks_box($post){
    wp_nonce_field('powerx_blocks','powerx_blocks_nonce');
    echo '<p style="color:#666">Các khối dưới đây hiển thị ở trang chi tiết sản phẩm. Khối nào để trống sẽ tự ẩn.</p>';
    echo '<h4 style="margin:14px 0 6px">“Cấu tạo bên trong” (ảnh bổ lớp)</h4>';
    $h=esc_attr(get_post_meta($post->ID,'px_inside_h',true));
    echo '<p><label style="font-weight:600">Tiêu đề khối</label><br><input type="text" name="px_inside_h" value="'.$h.'" placeholder="Cấu tạo bên trong" style="width:100%"></p>';
    powerx_blocks_img_field($post->ID,'px_inside_img','Ảnh bổ dọc các lớp (exploded view)');
    echo '<hr style="margin:16px 0"><h4 style="margin:0 0 8px">Khối tính năng (ảnh + chữ, tối đa 5)</h4>';
    for($i=1;$i<=5;$i++){
        echo '<div style="border:1px solid #e2e2e2;padding:12px;margin-bottom:12px;border-radius:6px;background:#fafafa"><b>Khối #'.$i.'</b>';
        $e=esc_attr(get_post_meta($post->ID,"px_feat{$i}_eyebrow",true));
        $t=esc_attr(get_post_meta($post->ID,"px_feat{$i}_title",true));
        $x=get_post_meta($post->ID,"px_feat{$i}_text",true);
        echo '<p><input type="text" name="px_feat'.$i.'_eyebrow" value="'.$e.'" placeholder="Chữ nhỏ (eyebrow), vd: GIỮ MÁT SUỐT ĐÊM" style="width:100%"></p>';
        echo '<p><input type="text" name="px_feat'.$i.'_title" value="'.$t.'" placeholder="Tiêu đề" style="width:100%"></p>';
        echo '<p><textarea name="px_feat'.$i.'_text" rows="2" placeholder="Mô tả ngắn" style="width:100%">'.esc_textarea($x).'</textarea></p>';
        powerx_blocks_img_field($post->ID,"px_feat{$i}_img","Ảnh khối #$i");
        echo '</div>';
    }
}
add_action('save_post_product', function($id){
    if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if(!isset($_POST['powerx_blocks_nonce']) || !wp_verify_nonce($_POST['powerx_blocks_nonce'],'powerx_blocks')) return;
    $txt = array('px_inside_h');
    for($i=1;$i<=5;$i++){ $txt[]="px_feat{$i}_eyebrow"; $txt[]="px_feat{$i}_title"; }
    foreach($txt as $k){ if(isset($_POST[$k])) update_post_meta($id,$k,sanitize_text_field($_POST[$k])); }
    for($i=1;$i<=5;$i++){ $k="px_feat{$i}_text"; if(isset($_POST[$k])) update_post_meta($id,$k,sanitize_textarea_field($_POST[$k])); }
    $imgs = array('px_inside_img'); for($i=1;$i<=5;$i++) $imgs[]="px_feat{$i}_img";
    foreach($imgs as $k){ if(isset($_POST[$k])) update_post_meta($id,$k,esc_url_raw(trim($_POST[$k]))); }
});
add_action('admin_enqueue_scripts', function(){
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if(!$screen || $screen->post_type!=='product') return;
    wp_enqueue_media();
    $js = "jQuery(function($){".
      "$(document).on('click','.px-img-pick',function(e){e.preventDefault();var w=$(this).closest('.px-imgfield');var f=wp.media({title:'Chọn ảnh',button:{text:'Dùng ảnh này'},multiple:false,library:{type:'image'}});f.on('select',function(){var a=f.state().get('selection').first().toJSON();w.find('.px-img-input').val(a.url);w.find('.px-img-prev').html('<img src=\"'+a.url+'\" style=\"max-width:160px;height:auto;border:1px solid #ddd;border-radius:4px\">');});f.open();});".
      "$(document).on('click','.px-img-clear',function(e){e.preventDefault();var w=$(this).closest('.px-imgfield');w.find('.px-img-input').val('');w.find('.px-img-prev').empty();});".
      "$(document).on('click','.px-vid-pick',function(e){e.preventDefault();var w=$(this).closest('.px-vidfield');var f=wp.media({title:'Chọn video',button:{text:'Dùng video này'},multiple:false,library:{type:'video'}});f.on('select',function(){var a=f.state().get('selection').first().toJSON();w.find('.px-vid-input').val(a.url);});f.open();});".
      "$(document).on('click','.px-vid-clear',function(e){e.preventDefault();$(this).closest('.px-vidfield').find('.px-vid-input').val('');});".
    "});";
    wp_add_inline_script('jquery-core',$js);
});

/* ============================================================
   META BOX: Gallery sản phẩm tuỳ biến (ảnh HOẶC video) — thay Album mặc định
   ============================================================ */
add_action('add_meta_boxes', function(){
    add_meta_box('powerx_gallery','Power X – Gallery sản phẩm (ảnh / video)','powerx_gallery_box','product','normal','high');
});
function powerx_gallery_box($post){
    wp_nonce_field('powerx_gallery','powerx_gallery_nonce');
    echo '<p style="color:#666">Tải ảnh cho từng ô — hiển thị dưới ảnh chính dạng lưới (như Bedgear). Nếu nhập thêm <b>link video</b> (YouTube/Vimeo/MP4) thì ô đó là VIDEO (ảnh dùng làm hình đại diện, bấm để phát). Ô #1 là ảnh chính mặc định. Bỏ trống tất cả ⇒ dùng "Album hình ảnh sản phẩm" mặc định của WooCommerce.</p>';
    for($i=1;$i<=6;$i++){
        echo '<div style="border:1px solid #e2e2e2;padding:12px;margin-bottom:10px;border-radius:6px;background:#fafafa"><b>Ô #'.$i.($i===1?' (ảnh chính)':'').'</b>';
        powerx_blocks_img_field($post->ID,"px_gal{$i}_img",'Ảnh / hình đại diện');
        $v=esc_attr(get_post_meta($post->ID,"px_gal{$i}_video",true));
        echo '<div class="px-vidfield"><label style="display:block;font-weight:600;margin-bottom:4px">Video (tuỳ chọn)</label>';
        echo '<p style="margin:0 0 6px"><button type="button" class="button px-vid-pick">Chọn video từ thư viện</button> <button type="button" class="button px-vid-clear">Xoá video</button></p>';
        echo '<input type="text" class="px-vid-input" name="px_gal'.$i.'_video" value="'.$v.'" placeholder="…hoặc dán link YouTube / Vimeo / MP4" style="width:100%">';
        echo '</div>';
        echo '</div>';
    }
}
add_action('save_post_product', function($id){
    if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if(!isset($_POST['powerx_gallery_nonce']) || !wp_verify_nonce($_POST['powerx_gallery_nonce'],'powerx_gallery')) return;
    for($i=1;$i<=6;$i++){
        if(isset($_POST["px_gal{$i}_img"]))   update_post_meta($id,"px_gal{$i}_img",   esc_url_raw(trim($_POST["px_gal{$i}_img"])));
        if(isset($_POST["px_gal{$i}_video"])) update_post_meta($id,"px_gal{$i}_video", esc_url_raw(trim($_POST["px_gal{$i}_video"])));
    }
    // Nếu sản phẩm chưa có "Ảnh sản phẩm" mà ô #1 có ảnh -> tự đặt làm ảnh đại diện (để hiện đúng ở Cửa hàng, giỏ, mega...)
    if(!has_post_thumbnail($id)){
        $g1 = get_post_meta($id,'px_gal1_img',true);
        if($g1){ $aid = attachment_url_to_postid($g1); if($aid) set_post_thumbnail($id,$aid); }
    }
});
/* Lấy danh sách item gallery tuỳ biến (ảnh + video). Rỗng nếu chưa cấu hình. */
function powerx_gallery_items($product){
    if(!$product) return array();
    $id=$product->get_id(); $items=array();
    for($i=1;$i<=6;$i++){
        $img=get_post_meta($id,"px_gal{$i}_img",true);
        $vid=get_post_meta($id,"px_gal{$i}_video",true);
        if($img==='' && $vid==='') continue;
        $items[]=array('img'=>$img,'video'=>$vid);
    }
    return $items;
}

/* ============================================================
   CUSTOMIZER: Cam kết + nội dung accordion vận chuyển/bảo hành
   ============================================================ */
function powerx_single_badges_default(){ return array('Miễn phí giao lắp','Dùng thử 100 đêm','Bảo hành 10 năm','Trả góp 0%'); }
function powerx_single_ship_default(){ return "Miễn phí giao lắp tận nơi cho đơn từ 3 triệu. Dùng thử 100 đêm — đổi trả miễn phí nếu chưa hài lòng. Bảo hành chính hãng đến 10 năm."; }
add_action('customize_register', function($wp){
    $wp->add_section('powerx_single_sec', array('title'=>'WooCommerce — Trang chi tiết SP','priority'=>34));
    $T = function($k,$l,$d,$type='text') use($wp){
        $wp->add_setting($k, array('default'=>$d,'sanitize_callback'=>($type==='textarea'?'sanitize_textarea_field':'sanitize_text_field')));
        $wp->add_control($k, array('label'=>$l,'section'=>'powerx_single_sec','type'=>$type));
    };
    $bd = powerx_single_badges_default();
    for($i=1;$i<=4;$i++){ $T("powerx_pbadge{$i}","Cam kết #{$i}", $bd[$i-1]); }
    $T('powerx_acc_ship','Accordion “Vận chuyển, Bảo hành & Đổi trả”', powerx_single_ship_default(),'textarea');
});

/* ============================================================
   SẮP XẾP LẠI HOOK TRÊN TRANG CHI TIẾT
   ============================================================ */
add_action('wp', function(){
    if(!function_exists('is_product') || !is_product()) return;
    // Bỏ tabs mặc định (mô tả/đánh giá) — thay bằng accordion + review snapshot riêng
    remove_action('woocommerce_after_single_product_summary','woocommerce_output_product_data_tabs',10);
    // Đưa "Dành cho ai + X-Features" ra khỏi tóm tắt (đã gom vào accordion bên dưới)
    remove_action('woocommerce_single_product_summary','powerx_single_persona_xfeat',45);
    // Ẩn dòng "SKU / Danh mục" mặc định của WooCommerce
    remove_action('woocommerce_single_product_summary','woocommerce_template_single_meta',40);
    // Thay đánh giá mặc định bằng dòng "đánh giá + đã bán" (tạo niềm tin)
    remove_action('woocommerce_single_product_summary','woocommerce_template_single_rating',10);
    add_action('woocommerce_single_product_summary','powerx_single_trust_stats',8);
    // Bỏ nhãn sale mặc định của WooCommerce (bị văng ra ngoài ảnh) — đã có nhãn "Sale X%" trong ảnh
    remove_action('woocommerce_before_single_product_summary','woocommerce_show_product_sale_flash',10);
    // Tóm tắt (cột phải): cam kết + accordion 5 mục (KHÔNG còn hàng icon X-Features)
    add_action('woocommerce_single_product_summary','powerx_single_trust',34);
    add_action('woocommerce_single_product_summary','powerx_single_accordions',60);
    // Các khối full-width sau tóm tắt (ĐÃ BỎ khối "Thông tin sản phẩm")
    add_action('woocommerce_after_single_product_summary','powerx_single_inside',12);
    add_action('woocommerce_after_single_product_summary','powerx_single_zigzag',14);
    add_action('woocommerce_after_single_product_summary','powerx_single_reviews',16);
});

/* Dòng "đánh giá + đã bán" dưới tiêu đề (tạo niềm tin) */
function powerx_single_trust_stats(){
    global $product; if(!$product || !function_exists('powerx_trust_html')) return;
    echo powerx_trust_html($product,'px-ts-single');
}
/* Hàng icon tính năng (lấy mã X-Features hiện có) */
function powerx_single_feat_icons(){
    global $product; if(!$product) return;
    $xf = get_post_meta($product->get_id(),'px_xfeatures',true); if(!$xf) return;
    $codes=array();
    foreach(preg_split('/\r?\n/',$xf) as $l){ $p=array_map('trim',explode('|',$l,2)); if($p[0]!=='') $codes[]=$p[0]; if(count($codes)>=4) break; }
    if(!$codes) return;
    echo '<div class="px-feat-icons">';
    foreach($codes as $c){
        echo '<span class="px-feat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M20 6L9 17l-5-5"/></svg>'.esc_html($c).'</span>';
    }
    echo '</div>';
}
/* Hàng cam kết (4 badge) — kiểu Casper: icon trên, chữ dưới, căn giữa */
function powerx_single_trust(){
    $bd = powerx_single_badges_default();
    $ic = array(
        // giao lắp (xe tải)
        '<path d="M3 7h11v8H3z"/><path d="M14 10h4l3 3v2h-7z"/><circle cx="7" cy="17.5" r="1.7"/><circle cx="17.5" cy="17.5" r="1.7"/>',
        // dùng thử 100 đêm (trăng)
        '<path d="M21 12.8A8.5 8.5 0 1 1 11.2 3a6.6 6.6 0 0 0 9.8 9.8z"/>',
        // bảo hành (khiên tick)
        '<path d="M12 3l8 3v6c0 5-3.5 7.7-8 9-4.5-1.3-8-4-8-9V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
        // trả góp 0% (phần trăm)
        '<path d="M19 5L5 19"/><circle cx="7.5" cy="7.5" r="2.4"/><circle cx="16.5" cy="16.5" r="2.4"/>',
    );
    echo '<div class="px-ptrust-row">';
    for($i=1;$i<=4;$i++){
        $b = px_opt("powerx_pbadge{$i}", $bd[$i-1]); if($b==='') continue;
        $svg = isset($ic[$i-1]) ? $ic[$i-1] : '<path d="M20 6L9 17l-5-5"/>';
        echo '<span class="px-ptrust"><span class="px-ptrust-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'.$svg.'</svg></span><span class="px-ptrust-tx">'.esc_html($b).'</span></span>';
    }
    echo '</div>';
}
/* Trích 1 mục theo tiêu đề <h3>…</h3> trong nội dung Mô tả (Description) */
function powerx_extract_h3_section($html, $title){
    if($html==='') return '';
    if(preg_match('~<h[23][^>]*>\s*'.preg_quote($title,'~').'.*?</h[23]>(.*?)(?=<h[23]|$)~is', $html, $m)){
        return trim($m[1]);
    }
    return '';
}
/* Accordion 5 mục (cột phải, thu gọn): Công nghệ Power X · Thông số kỹ thuật · FAQ · Dành cho ai · Vận chuyển/Bảo hành */
function powerx_single_accordions(){
    global $product; if(!$product) return; $id=$product->get_id();
    $desc = $product->get_description();
    $items=array();

    // 1) Công nghệ Power X (từ X-Features)
    $xf = get_post_meta($id,'px_xfeatures',true);
    if($xf){
        $dl='<dl class="px-xfeat">';
        foreach(preg_split('/\r?\n/',$xf) as $line){ $parts=array_map('trim',explode('|',$line,2)); if(count($parts)===2 && $parts[0]!=='') $dl.='<dt>'.esc_html($parts[0]).'</dt><dd>'.esc_html($parts[1]).'</dd>'; }
        $dl.='</dl>';
        $items[]=array('Công nghệ Power X', $dl);
    }

    // 2) Thông số kỹ thuật (lấy từ Description; nếu không có thì dùng bảng thuộc tính WooCommerce)
    $tech = powerx_extract_h3_section($desc, 'Thông số kỹ thuật');
    if(trim($tech)===''){ ob_start(); wc_display_product_attributes($product); $tech=ob_get_clean(); }
    if(trim($tech)!=='') $items[]=array('Thông số kỹ thuật', $tech);

    // 3) Câu hỏi thường gặp (lấy từ Description) — tách mỗi Hỏi/Đáp xuống dòng riêng
    $faq = powerx_extract_h3_section($desc, 'Câu hỏi thường gặp');
    if(trim($faq)==='') $faq = powerx_extract_h3_section($desc, 'FAQ');
    if(trim($faq)!=='') $items[]=array('Câu hỏi thường gặp', powerx_format_faq($faq));

    // 4) Dành cho ai (từ px_persona)
    $persona = get_post_meta($id,'px_persona',true);
    if($persona){
        $ul='<ul class="px-acc-list">';
        foreach(preg_split('/\r?\n/',$persona) as $line){ $line=trim($line); if($line!=='') $ul.='<li>'.esc_html($line).'</li>'; }
        $ul.='</ul>';
        $items[]=array('Dành cho ai', $ul);
    }

    // 5) Vận chuyển, Bảo hành & Đổi trả
    $ship = px_opt('powerx_acc_ship', powerx_single_ship_default());
    $w = get_post_meta($id,'px_warranty',true);
    if(trim((string)$w)!=='' && mb_strtolower(trim($w))==='trọn đời') $w='10 năm';
    $body5 = wpautop(esc_html($ship));
    if($w) $body5 .= '<p><b>Bảo hành:</b> '.esc_html($w).'</p>';
    $items[]=array('Vận chuyển, Bảo hành & Đổi trả', $body5);

    if(empty($items)) return;
    echo '<div class="px-pacc">';
    foreach($items as $k=>$it){
        $open = ($k===0) ? ' is-open' : '';
        echo '<div class="px-pacc-item'.$open.'"><button type="button" class="px-pacc-head">'.esc_html($it[0]).'<span class="px-pacc-ic"></span></button><div class="px-pacc-body">'.$it[1].'</div></div>';
    }
    echo '</div>';
}

/* Định dạng FAQ: mỗi "Hỏi:" và "Đáp:" xuống dòng riêng, câu hỏi in đậm */
function powerx_format_faq($html){
    $text = trim(wp_strip_all_tags($html));
    if($text==='') return $html;
    // Chèn ngắt dòng trước mỗi mốc Hỏi/Đáp (hỗ trợ cả Q:/A:)
    $text = preg_replace('/\s*(Hỏi\s*:|Q\s*:)/u', "\n\n$1", $text);
    $text = preg_replace('/\s*(Đáp\s*:|A\s*:)/u', "\n$1", $text);
    $text = trim($text);
    $out='';
    foreach(preg_split('/\n+/u',$text) as $line){
        $line=trim($line); if($line==='') continue;
        if(preg_match('/^(Hỏi\s*:|Q\s*:)/u',$line))      $out.='<p class="px-faq-q"><b>'.esc_html($line).'</b></p>';
        elseif(preg_match('/^(Đáp\s*:|A\s*:)/u',$line))   $out.='<p class="px-faq-a">'.esc_html($line).'</p>';
        else $out.='<p>'.esc_html($line).'</p>';
    }
    return $out!=='' ? $out : $html;
}

/* "Thông tin sản phẩm" — khối full-width mở sẵn, không có dấu +/- (đưa xuống dưới cho cân đối) */
function powerx_single_info(){
    global $product; if(!$product) return; $id=$product->get_id();
    $body = apply_filters('the_content', $product->get_description());
    $persona = get_post_meta($id,'px_persona',true);
    $xf = get_post_meta($id,'px_xfeatures',true);
    if($persona){
        $body .= '<h3 class="px-pinfo-sub">Dành cho ai</h3><ul class="px-pinfo-list">';
        foreach(preg_split('/\r?\n/',$persona) as $line){ $line=trim($line); if($line!=='') $body.='<li>'.esc_html($line).'</li>'; }
        $body .= '</ul>';
    }
    if($xf){
        $body .= '<h3 class="px-pinfo-sub">X-Features</h3><dl class="px-xfeat">';
        foreach(preg_split('/\r?\n/',$xf) as $line){ $parts=array_map('trim',explode('|',$line,2)); if(count($parts)===2 && $parts[0]!=='') $body.='<dt>'.esc_html($parts[0]).'</dt><dd>'.esc_html($parts[1]).'</dd>'; }
        $body .= '</dl>';
    }
    if(trim($body)==='') return;
    echo '<section class="px-pinfo"><div class="px-wrap"><h2 class="px-pinfo-h">Thông tin sản phẩm</h2><div class="px-pinfo-body">'.$body.'</div></div></section>';
}

/* Khối "Cấu tạo bên trong" (exploded) */
function powerx_single_inside(){
    global $product; if(!$product) return; $id=$product->get_id();
    $img = get_post_meta($id,'px_inside_img',true); if(!$img) return;
    $h = get_post_meta($id,'px_inside_h',true); if($h==='') $h='Cấu tạo bên trong';
    echo '<section class="px-inside"><div class="px-wrap">';
    echo '<h2 class="px-inside-h">'.esc_html($h).'</h2>';
    echo '<div class="px-inside-img"><img src="'.esc_url($img).'" alt="'.esc_attr($h).'" loading="lazy">';
    // Hiệu ứng gió thổi từ tâm ra 4 phía (thoáng khí)
    echo '<div class="px-airflow" aria-hidden="true">';
    foreach(array('up','down','left','right') as $d){
        for($k=0;$k<3;$k++){ echo '<span class="px-air px-air-'.$d.' a'.$k.'"></span>'; }
    }
    echo '</div>';
    echo '</div>';
    echo '</div></section>';
}
/* Các khối tính năng zigzag (ảnh + chữ xen kẽ) */
function powerx_single_zigzag(){
    global $product; if(!$product) return; $id=$product->get_id();
    $rows='';
    for($i=1;$i<=5;$i++){
        $e=get_post_meta($id,"px_feat{$i}_eyebrow",true); $t=get_post_meta($id,"px_feat{$i}_title",true);
        $x=get_post_meta($id,"px_feat{$i}_text",true); $img=get_post_meta($id,"px_feat{$i}_img",true);
        if($t==='' && $x==='' && $img==='') continue;
        $alt = ($i%2===0) ? ' px-zz-alt' : '';
        $txt = '<div class="px-zz-text">'.($e?'<span class="px-zz-eyebrow">'.esc_html($e).'</span>':'').($t?'<h3>'.esc_html($t).'</h3>':'').($x?'<p>'.esc_html($x).'</p>':'').'</div>';
        $media = $img ? '<div class="px-zz-media"><img src="'.esc_url($img).'" alt="'.esc_attr($t).'" loading="lazy"></div>' : '<div class="px-zz-media px-zz-media-empty" aria-hidden="true"></div>';
        $rows .= '<div class="px-zz-row'.$alt.'">'.$media.$txt.'</div>';
    }
    if($rows==='') return;
    echo '<section class="px-zigzag"><div class="px-wrap">'.$rows.'</div></section>';
}
/* Review Snapshot (điểm + biểu đồ sao + danh sách & form đánh giá WooCommerce) */
function powerx_single_reviews(){
    global $product; if(!$product) return; $id=$product->get_id();

    $real_count = (int)$product->get_review_count();
    $use_fake = ($real_count < 3) && function_exists('powerx_trust_reviews');

    if($use_fake){
        $tr=powerx_trust_reviews($product);
        $avg=(float)$tr['avg']; $count=(int)$tr['count'];
        $dist=powerx_trust_dist($product);
    } else {
        $avg = (float)$product->get_average_rating();
        $count = $real_count;
        $dist = array(5=>0,4=>0,3=>0,2=>0,1=>0);
        $cs = get_comments(array('post_id'=>$id,'status'=>'approve','type'=>'review','count'=>false));
        foreach($cs as $c){ $r=(int)get_comment_meta($c->comment_ID,'rating',true); if($r>=1 && $r<=5) $dist[$r]++; }
    }
    $rec = $count>0 ? round((($dist[5]+$dist[4]) / $count) * 100) : 0;

    echo '<section class="px-reviewsnap"><div class="px-wrap">';
    echo '<h2 class="px-rs-h">Đánh giá sản phẩm</h2>';
    echo '<div class="px-rs-top">';
    echo '<div class="px-rs-score"><div class="px-rs-num">'.number_format($avg,1).'</div>'.wc_get_rating_html($avg).'<div class="px-rs-count">'.powerx_compact_num($count).' lượt đánh giá</div></div>';
    if($count>0){
        echo '<div class="px-rs-rec"><div class="px-rs-rec-num">'.$rec.'%</div><div class="px-rs-rec-lbl">khách hàng giới thiệu sản phẩm này</div></div>';
    }
    echo '<div class="px-rs-bars">';
    for($s=5;$s>=1;$s--){
        $n=$dist[$s]; $pct=$count>0?round($n/$count*100):0;
        echo '<div class="px-rs-bar"><span class="px-rs-bar-l">'.$s.' sao</span><span class="px-rs-bar-t"><span style="width:'.$pct.'%"></span></span><span class="px-rs-bar-n">'.powerx_compact_num($n).'</span></div>';
    }
    echo '</div>';
    echo '</div>'; // top

    echo '<div class="px-rs-body">';
    if($use_fake && function_exists('powerx_fake_reviews_html')){
        echo powerx_fake_reviews_html($product);
    }
    comments_template();
    echo '</div>';
    echo '</div></section>';
}

/* Thanh CTA dính đáy khi cuộn */
add_action('wp_footer', function(){
    if(!function_exists('is_product') || !is_product()) return;
    global $product; if(!$product) $product = wc_get_product(get_the_ID()); if(!$product) return;
    echo '<div class="px-stickybar" id="px-stickybar"><div class="px-wrap px-stickybar-in">';
    echo '<div class="px-stickybar-prod">'.$product->get_image('woocommerce_gallery_thumbnail').'<div class="px-stickybar-meta"><b>'.esc_html($product->get_name()).'</b><span class="px-stickybar-price">'.$product->get_price_html().'</span></div></div>';
    echo '<button type="button" class="px-btn px-btn-lime px-stickybar-add">Thêm vào giỏ</button>';
    echo '</div></div>';
});
