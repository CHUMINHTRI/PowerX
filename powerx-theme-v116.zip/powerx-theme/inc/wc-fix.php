<?php
/** Power X — tự động đặt cấu hình VND đúng cho WooCommerce (chạy 1 lần khi kích hoạt theme) */
if (!defined('ABSPATH')) exit;

/* Bật đăng ký tài khoản tại trang Tài khoản (để cột Đăng ký luôn hiển thị) */
add_filter('option_woocommerce_enable_myaccount_registration', function($v){ return 'yes'; });
add_filter('pre_option_woocommerce_enable_myaccount_registration', function($v){ return 'yes'; });

function powerx_fix_wc_currency(){
    if (get_option('powerx_wc_vnd_fixed')==='1') return;
    update_option('woocommerce_currency','VND');
    update_option('woocommerce_currency_pos','right_space');
    update_option('woocommerce_price_thousand_sep','.');
    update_option('woocommerce_price_decimal_sep',',');
    update_option('woocommerce_price_num_decimals','0');
    update_option('powerx_wc_vnd_fixed','1');
}
add_action('after_switch_theme','powerx_fix_wc_currency',5);

/* Hộp liên hệ (hotline + Facebook) trong phần tóm tắt đơn — Giỏ hàng & Thanh toán */
function powerx_checkout_help_box(){
    if (!function_exists('px_opt')) return;
    $ph = px_opt('powerx_phone','0335332028');
    $fb = px_opt('powerx_messenger','https://www.facebook.com/profile.php?id=61579758988072');
    $tel = preg_replace('/\s+/','',$ph);
    echo '<div class="px-checkout-help">';
    echo '<div class="px-coh-title">Cần hỗ trợ đặt hàng?</div><div class="px-coh-btns">';
    if($ph) echo '<a class="px-coh-btn px-coh-call" href="tel:'.esc_attr($tel).'"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.1-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.5 2.7.6a2 2 0 0 1 1.7 2z"/></svg> Gọi '.esc_html($ph).'</a>';
    if($fb) echo '<a class="px-coh-btn px-coh-fb" href="'.esc_url($fb).'" target="_blank" rel="noopener"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.5 2 2 6.1 2 11.2c0 2.9 1.4 5.5 3.7 7.2v3.6l3.4-1.9c.9.2 1.9.4 2.9.4 5.5 0 10-4.1 10-9.2S17.5 2 12 2z"/></svg> Nhắn Facebook</a>';
    echo '</div></div>';
}
add_action('woocommerce_checkout_after_order_review','powerx_checkout_help_box');
add_action('woocommerce_after_cart_totals','powerx_checkout_help_box');
