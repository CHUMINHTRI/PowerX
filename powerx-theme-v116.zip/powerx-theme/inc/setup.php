<?php
/** Power X — tạo trang, vai trò, blog mẫu (chống trùng khi tái kích hoạt) */
if (!defined('ABSPATH')) exit;

function powerx_make_page($slug,$title,$content){
    $p = get_page_by_path($slug);
    if($p) return $p->ID;
    return wp_insert_post(array('post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$title,'post_content'=>$content));
}

function powerx_seed_pages_categories(){
    powerx_make_page('quiz-nem','Tư vấn chọn nệm','[powerx_quiz type="mattress"]');
    powerx_make_page('quiz-goi','Tư vấn chọn gối','[powerx_quiz type="pillow"]');
    powerx_make_page('so-sanh-nem','So sánh nệm','[powerx_compare]');

    $cats = array('San pham'=>'Sản phẩm','Cau chuyen giac ngu'=>'Câu chuyện giấc ngủ','Ngu ngon'=>'Ngủ ngon','Power X'=>'Power X');
    foreach($cats as $slug=>$name){ if(!term_exists($name,'category')) wp_insert_term($name,'category'); }

    $front = powerx_make_page('trang-chu','Trang chủ','');
    $blog  = powerx_make_page('blog','Blog','');
    if($front){ update_option('show_on_front','page'); update_option('page_on_front',$front); }
    if($blog){ update_option('page_for_posts',$blog); }

    // WooCommerce pages (đảm bảo có Cart/Checkout/My account/Shop)
    if (function_exists('WC_Install') && method_exists('WC_Install','create_pages')) {
        WC_Install::create_pages();
    } else {
        // fallback tạo tay nếu WC khác version
        foreach(array('cart'=>'Giỏ hàng','checkout'=>'Thanh toán','my-account'=>'Tài khoản','shop'=>'Cửa hàng') as $slug=>$title){
            $p = get_page_by_path($slug);
            if(!$p){
                $content = ($slug==='cart'?'[woocommerce_cart]':($slug==='checkout'?'[woocommerce_checkout]':($slug==='my-account'?'[woocommerce_my_account]':'')));
                $id = wp_insert_post(array('post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$title,'post_content'=>$content));
                if($slug==='cart')     update_option('woocommerce_cart_page_id',$id);
                if($slug==='checkout') update_option('woocommerce_checkout_page_id',$id);
                if($slug==='my-account') update_option('woocommerce_myaccount_page_id',$id);
                if($slug==='shop')     update_option('woocommerce_shop_page_id',$id);
            }
        }
    }
}
