<?php
/** Power X — Customizer */
if (!defined('ABSPATH')) exit;

add_action('customize_register', function($wp){
    $wp->add_panel('powerx_panel', array('title'=>'Power X — Trang chủ','priority'=>30));

    // HERO
    $wp->add_section('powerx_hero', array('title'=>'Hero (Đầu trang)','panel'=>'powerx_panel'));
    $hero = array(
        'powerx_hero_eyebrow' => 'Nệm & gối hiệu năng cao',
        'powerx_hero_h1_a'    => 'FOR ME',
        'powerx_hero_h1_em'   => 'NOT FOR YOU',
        'powerx_hero_tag'     => 'POWER X — Sleep Performance',
        'powerx_hero_lead'    => 'Hybrid Graphene + lò xo túi phân vùng. Bốn dòng nệm cho bốn lifestyle.',
        'powerx_hero_btn1'    => 'Khám phá sản phẩm',
        'powerx_hero_btn2'    => 'Nhận tư vấn miễn phí',
    );
    foreach($hero as $k=>$v){
        $wp->add_setting($k,array('default'=>$v,'sanitize_callback'=>'sanitize_text_field'));
        $wp->add_control($k,array('label'=>str_replace('powerx_hero_','Hero — ',$k),'section'=>'powerx_hero','type'=>'text'));
    }
    $wp->add_setting('powerx_hero_image',array('sanitize_callback'=>'esc_url_raw'));
    $wp->add_control(new WP_Customize_Image_Control($wp,'powerx_hero_image',array('label'=>'Slide #1 — Ảnh nền (≥1800×900, chủ thể NẰM BÊN PHẢI để không bị hộp thoại che)','section'=>'powerx_hero')));
    $wp->add_setting('powerx_hero_video',array('sanitize_callback'=>'esc_url_raw'));
    $wp->add_control('powerx_hero_video',array('label'=>'Slide #1 — Video (URL .mp4 từ Thư viện hoặc link YouTube/Vimeo). Nếu điền sẽ thay cho ảnh.','section'=>'powerx_hero','type'=>'url','input_attrs'=>array('placeholder'=>'https://.../hero.mp4 hoặc https://youtu.be/xxxx')));

    $wp->add_setting('powerx_hero_image_2',array('sanitize_callback'=>'esc_url_raw'));
    $wp->add_control(new WP_Customize_Image_Control($wp,'powerx_hero_image_2',array('label'=>'Slide #2 — Ảnh nền (tuỳ chọn — để bật chế độ trượt)','section'=>'powerx_hero')));
    $wp->add_setting('powerx_hero_video_2',array('sanitize_callback'=>'esc_url_raw'));
    $wp->add_control('powerx_hero_video_2',array('label'=>'Slide #2 — Video (tuỳ chọn, thay cho ảnh nếu điền)','section'=>'powerx_hero','type'=>'url','input_attrs'=>array('placeholder'=>'.mp4 / YouTube / Vimeo')));

    $wp->add_setting('powerx_hero_image_3',array('sanitize_callback'=>'esc_url_raw'));
    $wp->add_control(new WP_Customize_Image_Control($wp,'powerx_hero_image_3',array('label'=>'Slide #3 — Ảnh nền (tuỳ chọn)','section'=>'powerx_hero')));
    $wp->add_setting('powerx_hero_video_3',array('sanitize_callback'=>'esc_url_raw'));
    $wp->add_control('powerx_hero_video_3',array('label'=>'Slide #3 — Video (tuỳ chọn, thay cho ảnh nếu điền)','section'=>'powerx_hero','type'=>'url','input_attrs'=>array('placeholder'=>'.mp4 / YouTube / Vimeo')));

    $wp->add_setting('powerx_hero_interval',array('default'=>5,'sanitize_callback'=>'absint'));
    $wp->add_control('powerx_hero_interval',array('label'=>'Thời gian mỗi ẢNH (giây) trước khi trượt','section'=>'powerx_hero','type'=>'number','input_attrs'=>array('min'=>2,'max'=>15,'step'=>1)));
    $wp->add_setting('powerx_hero_video_secs',array('default'=>8,'sanitize_callback'=>'absint'));
    $wp->add_control('powerx_hero_video_secs',array('label'=>'Thời gian hiển thị VIDEO (giây) trước khi trượt sang slide khác','section'=>'powerx_hero','type'=>'number','input_attrs'=>array('min'=>2,'max'=>60,'step'=>1)));

    // Showroom
    $wp->add_section('powerx_showroom_sec',array('title'=>'Showroom (Trải nghiệm)','panel'=>'powerx_panel'));
    $wp->add_setting('powerx_showroom_eyebrow',array('default'=>'Showroom trải nghiệm','sanitize_callback'=>'sanitize_text_field'));
    $wp->add_control('powerx_showroom_eyebrow',array('label'=>'Chữ nhỏ (eyebrow)','section'=>'powerx_showroom_sec','type'=>'text'));
    $wp->add_setting('powerx_showroom_title1',array('default'=>'NẰM THỬ 15 PHÚT.','sanitize_callback'=>'sanitize_text_field'));
    $wp->add_control('powerx_showroom_title1',array('label'=>'Tiêu đề dòng 1','section'=>'powerx_showroom_sec','type'=>'text'));
    $wp->add_setting('powerx_showroom_title2',array('default'=>'QUYẾT ĐỊNH 10 NĂM.','sanitize_callback'=>'sanitize_text_field'));
    $wp->add_control('powerx_showroom_title2',array('label'=>'Tiêu đề dòng 2 (màu đỏ)','section'=>'powerx_showroom_sec','type'=>'text'));
    $wp->add_setting('powerx_showroom_text',array('default'=>'Prime, Fusion, Flow, Core — cả 4 dòng đặt cạnh nhau tại showroom Biên Hòa. Nằm thử trực tiếp, cảm nhận khác biệt trước khi quyết định.','sanitize_callback'=>'sanitize_textarea_field'));
    $wp->add_control('powerx_showroom_text',array('label'=>'Mô tả','section'=>'powerx_showroom_sec','type'=>'textarea'));
    $wp->add_setting('powerx_showroom_btn',array('default'=>'Đặt lịch trải nghiệm','sanitize_callback'=>'sanitize_text_field'));
    $wp->add_control('powerx_showroom_btn',array('label'=>'Chữ nút chính','section'=>'powerx_showroom_sec','type'=>'text'));
    $wp->add_setting('powerx_showroom_image',array('sanitize_callback'=>'esc_url_raw'));
    $wp->add_control(new WP_Customize_Image_Control($wp,'powerx_showroom_image',array('label'=>'Ảnh nền showroom (tuỳ chọn)','section'=>'powerx_showroom_sec')));
    $wp->add_setting('powerx_showroom_video',array('sanitize_callback'=>'esc_url_raw'));
    $wp->add_control('powerx_showroom_video',array('label'=>'Video nền (URL .mp4 hoặc YouTube/Vimeo) — tự chạy, tắt tiếng như Hero. Nếu điền sẽ thay ảnh nền.','section'=>'powerx_showroom_sec','type'=>'url','input_attrs'=>array('placeholder'=>'https://.../showroom.mp4 hoặc https://youtu.be/xxxx')));

    // CONTACT (đã cập nhật mặc định với link FB của bạn)
    $wp->add_section('powerx_contact_sec',array('title'=>'Liên hệ (Footer + Tab Liên hệ)','panel'=>'powerx_panel'));
    $contacts = array(
        'powerx_phone'    => array('Hotline','0335332028'),
        'powerx_zalo'     => array('Zalo (số hoặc link)','https://zalo.me/0335332028'),
        'powerx_messenger'=> array('Messenger / Facebook Page','https://www.facebook.com/profile.php?id=61579758988072'),
        'powerx_email'    => array('Email','info@powerxsleep.vn'),
        'powerx_address'  => array('Địa chỉ showroom','Số nhà E97, Đường D9, khu phố Vĩnh Thanh, Phường Trấn Biên, Thành Phố Đồng Nai'),
    );
    foreach($contacts as $k=>$v){
        $wp->add_setting($k,array('default'=>$v[1],'sanitize_callback'=>'sanitize_text_field'));
        $wp->add_control($k,array('label'=>$v[0],'section'=>'powerx_contact_sec','type'=>'text'));
    }
    // Nút Messenger nổi góc phải (bật/tắt)
    $wp->add_setting('powerx_msg_float_on',array('default'=>'1','sanitize_callback'=>'sanitize_text_field'));
    $wp->add_control('powerx_msg_float_on',array('label'=>'Nút Messenger nổi ở góc phải?','description'=>'Hiện nút chat Messenger cố định cuối màn hình.','section'=>'powerx_contact_sec','type'=>'select','choices'=>array('1'=>'BẬT','0'=>'TẮT')));
    // Mạng xã hội (footer)
    $socials = array(
        'powerx_social_fb'     => array('Facebook (URL)','https://www.facebook.com/profile.php?id=61579758988072'),
        'powerx_social_ig'     => array('Instagram (URL)',''),
        'powerx_social_tiktok' => array('TikTok (URL)',''),
        'powerx_social_youtube'=> array('YouTube (URL)',''),
    );
    foreach($socials as $k=>$v){
        $wp->add_setting($k,array('default'=>$v[1],'sanitize_callback'=>'esc_url_raw'));
        $wp->add_control($k,array('label'=>$v[0],'section'=>'powerx_contact_sec','type'=>'url'));
    }

    // ===== ĐÀO TẠO BÁN HÀNG (nội bộ) — tải file HTML lên =====
    $tr_name = get_option('powerx_training_name','');
    $tr_time = get_option('powerx_training_time','');
    $tr_desc = $tr_name
        ? '✅ File hiện tại: <b>'.esc_html($tr_name).'</b>'.($tr_time?' · '.esc_html($tr_time):'').'. Chọn file mới để thay thế rồi bấm “Đăng”.'
        : 'Chưa có file. Chọn file <b>.html</b> (app đào tạo khép kín) rồi bấm “Đăng”. Chỉ tài khoản quản trị mới xem được.';
    $wp->add_setting('powerx_training_attach',array('default'=>0,'sanitize_callback'=>'absint'));
    $wp->add_control(new WP_Customize_Media_Control($wp,'powerx_training_attach',array(
        'label'       => 'Đào tạo bán hàng — Tải file HTML',
        'description' => $tr_desc,
        'section'     => 'powerx_contact_sec',
        'button_labels' => array(
            'select'       => 'Chọn / Tải file HTML',
            'change'       => 'Đổi file',
            'default'      => 'Mặc định',
            'remove'       => 'Bỏ chọn',
            'placeholder'  => 'Chưa chọn file',
            'frame_title'  => 'Chọn file HTML đào tạo',
            'frame_button' => 'Dùng file này',
        ),
    )));
    $wp->add_setting('powerx_training_enabled',array('default'=>'1','sanitize_callback'=>function($v){ return $v ? '1':'0'; }));
    $wp->add_control('powerx_training_enabled',array(
        'label'=>'Hiện mục “Đào tạo bán hàng” ở footer?',
        'description'=>'Chỉ hiển thị cho tài khoản quản trị đã đăng nhập.',
        'section'=>'powerx_contact_sec','type'=>'select','choices'=>array('1'=>'BẬT','0'=>'TẮT')));

    // ẢNH DÒNG NỆM — 2 nhóm ĐỘC LẬP: mục "Chọn sản phẩm" và mục "Lợi ích"
    $px_lines = array('prime'=>'Prime','fusion'=>'Fusion','flow'=>'Flow','core'=>'Core');

    // Nhóm 1: mục "Chọn sản phẩm Power X" (tab Nệm — personas)
    $wp->add_section('powerx_persona_imgs',array('title'=>'Ảnh — Chọn sản phẩm (tab Nệm)','panel'=>'powerx_panel'));
    foreach($px_lines as $slug=>$name){
        $key='powerx_persona_img_'.$slug;
        $wp->add_setting($key,array('sanitize_callback'=>'esc_url_raw'));
        $wp->add_control(new WP_Customize_Image_Control($wp,$key,array(
            'label'=>'Ảnh Power X '.$name,'description'=>'Banner đầu thẻ ở mục "Chọn sản phẩm". Bỏ trống = hình mặc định.',
            'section'=>'powerx_persona_imgs',
        )));
    }

    // Nhóm 2: mục "Lợi ích bạn nhận được" (4 thẻ benefit)
    $wp->add_section('powerx_benefit_imgs',array('title'=>'Ảnh — Lợi ích (4 thẻ)','panel'=>'powerx_panel'));
    foreach($px_lines as $slug=>$name){
        $key='powerx_benefit_img_'.$slug;
        $wp->add_setting($key,array('sanitize_callback'=>'esc_url_raw'));
        $wp->add_control(new WP_Customize_Image_Control($wp,$key,array(
            'label'=>'Ảnh Power X '.$name,'description'=>'Ảnh đầu thẻ ở mục "Lợi ích". Bỏ trống = hình mặc định.',
            'section'=>'powerx_benefit_imgs',
        )));
    }

    // Nhóm 3: mục "Chọn sản phẩm" — tab Gối (Ergo, Matrix)
    $px_pillows = array('ergo'=>'Ergo','matrix'=>'Matrix');
    $wp->add_section('powerx_pillow_imgs',array('title'=>'Ảnh — Gối (tab Gối)','panel'=>'powerx_panel'));
    foreach($px_pillows as $slug=>$name){
        $key='powerx_pillow_img_'.$slug;
        $wp->add_setting($key,array('sanitize_callback'=>'esc_url_raw'));
        $wp->add_control(new WP_Customize_Image_Control($wp,$key,array(
            'label'=>'Ảnh Gối Power X '.$name,'description'=>'Ảnh thẻ gối ở tab Gối. Bỏ trống = hình minh hoạ mặc định.',
            'section'=>'powerx_pillow_imgs',
        )));
    }

    // PHẢN HỒI KHÁCH HÀNG (trang chủ)
    $wp->add_section('powerx_reviews_sec',array('title'=>'Phản hồi khách hàng (Trang chủ)','panel'=>'powerx_panel'));
    $rev = function($k,$label,$default,$type='text') use($wp){
        $wp->add_setting($k,array('default'=>$default,'sanitize_callback'=> ($type==='textarea'?'sanitize_textarea_field':'sanitize_text_field')));
        $wp->add_control($k,array('label'=>$label,'section'=>'powerx_reviews_sec','type'=>$type));
    };
    $rev('powerx_rev_h','Tiêu đề','Khách hàng nói gì về Power X');
    $rev('powerx_rev_sub','Mô tả ngắn','Hàng nghìn giấc ngủ ngon mỗi đêm — đây là vài chia sẻ thật từ người dùng Power X.','textarea');
    $rev_def = powerx_reviews_defaults();
    for($i=1;$i<=4;$i++){
        $rev("powerx_rev{$i}_name","Đánh giá #{$i} — Tên", $rev_def[$i][0]);
        $rev("powerx_rev{$i}_sub","Đánh giá #{$i} — Nghề/Nơi", $rev_def[$i][1]);
        $rev("powerx_rev{$i}_stars","Đánh giá #{$i} — Số sao (1-5)", $rev_def[$i][2]);
        $rev("powerx_rev{$i}_title","Đánh giá #{$i} — Tiêu đề ngắn", isset($rev_def[$i][4])?$rev_def[$i][4]:'');
        $rev("powerx_rev{$i}_text","Đánh giá #{$i} — Nội dung", $rev_def[$i][3],'textarea');
        $rev("powerx_rev{$i}_product","Đánh giá #{$i} — Slug sản phẩm (khung Mua ngay)", isset($rev_def[$i][5])?$rev_def[$i][5]:'');
    }
});

function px_opt($k,$def=''){ $v=get_theme_mod($k,$def); return $v!==''?$v:$def; }

/* Nội dung mặc định phản hồi khách hàng — dùng chung cho Customizer & trang chủ. [0]=Tên [1]=Nghề/Nơi [2]=Sao [3]=Nội dung [4]=Tiêu đề [5]=Slug sản phẩm */
function powerx_reviews_defaults(){
    return array(
      1=>array('Minh Tuấn','Doanh nhân · TP.HCM','5','Mình bị đau lưng kinh niên vì ngồi làm cả ngày. Sau 2 tuần nằm Power X Prime, sáng dậy lưng nhẹ hẳn, ngủ một mạch không trở mình.','Hết đau lưng sau 2 tuần','power-x-prime'),
      2=>array('Thu Hà','Mẹ 2 con · Hà Nội','5','Trước cứ nóng lưng là tỉnh giấc. Lớp Graphene mát thật sự — giờ cả nhà ngủ ngon, con cũng ít quấy hơn hẳn.','Mát lạnh cả đêm','power-x-flow'),
      3=>array('Đức Anh','Vận động viên · Đà Nẵng','5','Tập nặng nên rất cần hồi phục. Fusion nâng đỡ chắc mà vẫn êm, sáng dậy cơ thể đỡ mỏi rõ rệt. Đáng từng đồng.','Hồi phục nhanh hơn hẳn','power-x-fusion'),
      4=>array('Lan Phương','Nhân viên văn phòng · Biên Hòa','5','Đặt online hơi lo, nhưng được dùng thử 100 đêm nên yên tâm. Nệm Flow êm, giao lắp nhanh, tư vấn nhiệt tình. Rất hài lòng!','Trải nghiệm rất hài lòng','power-x-core'),
    );
}
