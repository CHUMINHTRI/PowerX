<?php
if (!defined('ABSPATH')) exit;

/* ===== BẢNG SO SÁNH — chuyển thành 4 CARDS có ảnh + benefit ===== */
add_shortcode('powerx_compare', function(){
    $base = get_template_directory_uri().'/assets/';
    $items = array(
      array('slug'=>'power-x-prime','code'=>'PRIME','name'=>'Power X Prime','tag'=>'Prime Level. Sleep Like a Pro.',
        'pbg'=>'#0a0a0a','pacc'=>'#A81E2E','color'=>'red',
        'height'=>'30 cm','type'=>'Hybrid','hardness'=>'Medium','price'=>'từ 23.598.000₫',
        'tech'=>'Lò xo kép + Cooling Gel + Aerospace Foam',
        'benefits'=>array(
          array('🏆','Đạt giải Red Dot 2019','Thiết kế được công nhận toàn cầu'),
          array('🧠','Phục hồi sâu cơ thể','Tái tạo năng lượng cho ngày làm việc cường độ cao'),
          array('❄️','Cooling Gel làm mát','Không nóng lưng, ngủ sâu suốt đêm'),
          array('⚙️','Lò xo túi siêu nhỏ','Nâng đỡ chính xác từng vùng cơ thể'),
        )),
      array('slug'=>'power-x-fusion','code'=>'FUSION','name'=>'Power X Fusion','tag'=>'Recover Fast. Play Hard.',
        'pbg'=>'#1a1a1a','pacc'=>'#9ACC00','color'=>'lime',
        'height'=>'27 cm','type'=>'Hybrid','hardness'=>'Medium','price'=>'từ 16.198.000₫',
        'tech'=>'Graphene Foam + Lò xo túi 11 vùng + FlowEdge',
        'benefits'=>array(
          array('💪','Phục hồi cơ bắp nhanh','Hợp người hoạt động thể chất, máy móc cường độ cao'),
          array('🦠','Graphene kháng khuẩn','Bề mặt sạch, mát, an toàn cho da'),
          array('🛡️','11 vùng nâng đỡ','Cột sống thẳng tự nhiên, giảm đau lưng-vai'),
          array('💑','Không rung lan','Bạn cùng giường trở mình không làm bạn thức'),
        )),
      array('slug'=>'power-x-flow','code'=>'FLOW','name'=>'Power X Flow','tag'=>'Flow Mode: Stay Cool, Stay Sharp.',
        'pbg'=>'#1a3a4a','pacc'=>'#5cd0e0','color'=>'teal',
        'height'=>'22 cm','type'=>'Foam Graphene','hardness'=>'Medium-Firm','price'=>'từ 9.398.000₫',
        'tech'=>'Memory Foam Graphene + Vỏ Tencel + AirWave',
        'benefits'=>array(
          array('🌡️','Mát lạnh cả đêm','Vỏ Tencel + AirWave: hết nóng lưng, hết đổ mồ hôi'),
          array('🤲','Ôm sát cơ thể','Giảm áp lực điểm tì đè ở vai và hông'),
          array('🌿','Vỏ Tencel mềm mịn','Cảm giác dễ chịu ngay khi chạm vào'),
          array('🔇','Im lặng tuyệt đối','Foam thuần — không tiếng kêu lò xo'),
        )),
      array('slug'=>'power-x-core','code'=>'CORE','name'=>'Power X Core','tag'=>'Cool Sleep. Core Power.',
        'pbg'=>'#143820','pacc'=>'#7DD66F','color'=>'green',
        'height'=>'15 cm','type'=>'Foam 2 mặt','hardness'=>'Firm','price'=>'từ 6.398.000₫',
        'tech'=>'Foam 2 mặt + Rãnh CNC AirWave + Dual Comfort',
        'benefits'=>array(
          array('💰','Giá hợp lý nhất','Chất lượng Power X với mức đầu tư tối ưu'),
          array('🔄','Hai mặt linh hoạt','Mặt thoáng & mặt phẳng cứng — đổi theo mùa'),
          array('💨','Rãnh CNC thông khí','Massage nhẹ, lưu thông không khí suốt đêm'),
          array('🏠','Dễ vệ sinh','Vỏ tháo giặt, lý tưởng phòng cho thuê'),
        )),
    );
    ob_start(); ?>
    <div class="px-compare-cards">
      <?php foreach($items as $it): ?>
        <a class="px-cc" href="/product/<?php echo esc_attr($it['slug']); ?>/" style="--cc-bg:<?php echo esc_attr($it['pbg']); ?>;--cc-acc:<?php echo esc_attr($it['pacc']); ?>">
          <?php if(function_exists('powerx_promo_badge_html')) echo powerx_promo_badge_html('px-sale-badge--cc'); ?>
          <div class="px-cc-head">
            <span class="px-cc-code"><?php echo esc_html($it['code']); ?></span>
            <h3><?php echo esc_html($it['name']); ?></h3>
            <div class="px-cc-tag"><?php echo esc_html($it['tag']); ?></div>
            <?php $cc_img = function_exists('px_opt') ? px_opt('powerx_benefit_img_'.strtolower($it['code']),'') : ''; if($cc_img): ?>
            <div class="px-cc-illust has-img"><img src="<?php echo esc_url($cc_img); ?>" alt="<?php echo esc_attr($it['name']); ?>" loading="lazy"></div>
            <?php endif; ?>
          </div>
          <div class="px-cc-body">
            <div class="px-cc-specs">
              <div><b><?php echo esc_html($it['height']); ?></b><small>Cao</small></div>
              <div><b><?php echo esc_html($it['hardness']); ?></b><small>Độ cứng</small></div>
              <div><b>10 năm</b><small>Bảo hành</small></div>
            </div>
            <div class="px-cc-tech">⚡ <?php echo esc_html($it['tech']); ?></div>
            <ul class="px-cc-benefits">
              <?php foreach($it['benefits'] as $b): ?>
                <li><span class="px-cc-ico"><?php echo esc_html($b[0]); ?></span><div><b><?php echo esc_html($b[1]); ?></b><small><?php echo esc_html($b[2]); ?></small></div></li>
              <?php endforeach; ?>
            </ul>
            <div class="px-cc-foot">
              <div class="px-cc-price"><?php echo esc_html($it['price']); ?></div>
              <span class="px-cc-cta">Khám phá →</span>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
    <?php return ob_get_clean();
});

/* ===== PERSONAS (tab Nệm trang chủ) ===== */
add_shortcode('powerx_personas', function(){
    $items = array(
      array('PRM','Prime','Prime Level. Sleep Like a Pro.','Đẳng cấp giấc ngủ — tái tạo năng lượng tối đa.','Người thành đạt · Gia đình hiện đại','Hybrid + lò xo kép cao cấp','Medium · 30cm','từ 23.598.000₫','#0a0a0a','#A81E2E'),
      array('FUS','Fusion','Recover Fast. Play Hard.','Phục hồi sâu cho cuộc sống năng động.','Người hoạt động thể chất · Văn phòng','Hybrid + lò xo túi 11 vùng','Medium · 27cm','từ 16.198.000₫','#1a1a1a','#9ACC00'),
      array('FLW','Flow','Flow Mode: Stay Cool, Stay Sharp.','Êm ái và mát lạnh suốt đêm.','Cặp đôi · Người dễ nóng khi ngủ','Foam Graphene Memory + Tencel','Medium-Firm · 22cm','từ 9.398.000₫','#1a3a4a','#5cd0e0'),
      array('COR','Core','Cool Sleep. Core Power.','Giấc ngủ thoáng mát, tiện lợi mỗi ngày.','Người trẻ · Lifestyle tối giản · Phòng cho thuê','Foam 2 mặt + Air Flow Design','Firm · 15cm','từ 6.398.000₫','#143820','#7DD66F'),
    );
    ob_start(); ?>
    <div class="px-personas">
      <?php foreach($items as $it): ?>
        <a class="px-persona" href="/product/power-x-<?php echo esc_attr(strtolower($it[1])); ?>/" style="--pacc:<?php echo esc_attr($it[9]); ?>;--pbg:<?php echo esc_attr($it[8]); ?>">
          <?php if(function_exists('powerx_promo_badge_html')) echo powerx_promo_badge_html('px-sale-badge--persona'); ?>
          <?php $p_img = function_exists('px_opt') ? px_opt('powerx_persona_img_'.strtolower($it[1]),'') : ''; ?>
          <div class="px-persona-head">
            <span class="px-persona-code"><?php echo esc_html($it[0]); ?></span>
            <h3>Power X <span><?php echo esc_html($it[1]); ?></span></h3>
            <div class="px-persona-tag"><?php echo esc_html($it[2]); ?></div>
            <p class="px-persona-sub"><?php echo esc_html($it[3]); ?></p>
            <?php if($p_img): ?><div class="px-persona-media"><img src="<?php echo esc_url($p_img); ?>" alt="Power X <?php echo esc_attr($it[1]); ?>" loading="lazy"></div><?php endif; ?>
          </div>
          <div class="px-persona-body">
            <div class="px-persona-row"><small>Dành cho</small><b><?php echo esc_html($it[4]); ?></b></div>
            <div class="px-persona-row"><small>Công nghệ</small><b><?php echo esc_html($it[5]); ?></b></div>
            <div class="px-persona-row"><small>Độ cứng · Cao</small><b><?php echo esc_html($it[6]); ?></b></div>
            <div class="px-persona-foot">
              <span class="px-persona-price"><?php echo esc_html($it[7]); ?></span>
              <span class="px-persona-cta">Khám phá →</span>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
    <?php return ob_get_clean();
});
