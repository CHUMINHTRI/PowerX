<?php
/** Khách hàng tiềm năng (Lead) — CPT + AJAX nhận form + gửi email */
if (!defined('ABSPATH')) exit;

add_action('init', function(){
    register_post_type('powerx_lead', array(
        'labels'=>array('name'=>'Khách hàng tiềm năng','singular_name'=>'Lead','menu_name'=>'KH tiềm năng'),
        'public'=>false,'show_ui'=>true,'show_in_menu'=>true,'menu_icon'=>'dashicons-groups',
        'menu_position'=>26,'capability_type'=>'post','supports'=>array('title'),
    ));
});

/* Cột hiển thị trong danh sách lead */
add_filter('manage_powerx_lead_posts_columns', function($c){
    return array('cb'=>$c['cb'],'title'=>'Tên','px_phone'=>'SĐT','px_email'=>'Email','px_interest'=>'Quan tâm','date'=>'Ngày');
});
add_action('manage_powerx_lead_posts_custom_column', function($col,$id){
    if($col==='px_phone')   echo esc_html(get_post_meta($id,'phone',true));
    if($col==='px_email')   echo esc_html(get_post_meta($id,'email',true));
    if($col==='px_interest')echo esc_html(get_post_meta($id,'interest',true));
},10,2);

/* Nhận form từ popup (cả khách chưa đăng nhập) */
function powerx_save_lead(){
    check_ajax_referer('powerx_lead','nonce');
    $name = sanitize_text_field($_POST['name']  ?? '');
    $phone= sanitize_text_field($_POST['phone'] ?? '');
    $email= sanitize_email($_POST['email']      ?? '');
    $interest = sanitize_text_field($_POST['interest'] ?? '');
    $note = sanitize_textarea_field($_POST['note'] ?? '');
    if($name==='' || $phone===''){ wp_send_json_error(array('msg'=>'Vui lòng nhập tên và số điện thoại.')); }

    $id = wp_insert_post(array(
        'post_type'=>'powerx_lead','post_status'=>'publish',
        'post_title'=> $name.' — '.$phone,
    ));
    if($id){
        update_post_meta($id,'phone',$phone);
        update_post_meta($id,'email',$email);
        update_post_meta($id,'interest',$interest);
        update_post_meta($id,'note',$note);

        $to = get_option('admin_email');
        $subj = '[Power X] Lead mới: '.$name;
        $body = "Tên: $name\nSĐT: $phone\nEmail: $email\nQuan tâm: $interest\nGhi chú: $note\n\nXem trong wp-admin → KH tiềm năng.";
        wp_mail($to,$subj,$body);
        wp_send_json_success(array('msg'=>'Đã nhận thông tin. Power X sẽ liên hệ sớm!'));
    }
    wp_send_json_error(array('msg'=>'Có lỗi, vui lòng thử lại.'));
}
add_action('wp_ajax_powerx_lead','powerx_save_lead');
add_action('wp_ajax_nopriv_powerx_lead','powerx_save_lead');
