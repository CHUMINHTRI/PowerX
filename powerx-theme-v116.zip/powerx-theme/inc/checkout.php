<?php
/** Power X — Tinh chỉnh trang Thanh toán theo kiểu Casper (2 cột, có ảnh trong tóm tắt đơn). */
if (!defined('ABSPATH')) exit;

/* Thêm ảnh sản phẩm vào tóm tắt đơn ở trang Thanh toán (kiểu Casper) */
add_filter('woocommerce_cart_item_name', function($name, $cart_item, $cart_item_key){
    if(!function_exists('is_checkout') || !is_checkout() || is_cart()) return $name;
    $p = isset($cart_item['data']) ? $cart_item['data'] : null;
    if(!$p) return $name;
    $img = $p->get_image('woocommerce_gallery_thumbnail');
    return '<span class="px-co-itemthumb">'.$img.'</span><span class="px-co-itemname">'.$name.'</span>';
}, 10, 3);
