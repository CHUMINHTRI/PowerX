<?php
/** Power X — Badge giảm giá tự động hiển thị khi sản phẩm có giá khuyến mãi (sale price) */
if (!defined('ABSPATH')) exit;

/* Custom badge "Giảm xx%" thay cho "Sale!" mặc định trên loop & single */
add_filter('woocommerce_sale_flash', function($html, $post, $product){
    if (!$product) $product = wc_get_product(get_the_ID());
    if (!$product) return $html;

    if ($product->is_type('variable')) {
        $max_pct = 0;
        foreach ($product->get_available_variations() as $v){
            $reg = (float)$v['display_regular_price']; $sale = (float)$v['display_price'];
            if ($reg>0 && $sale>0 && $sale<$reg){
                $pct = round(($reg-$sale)/$reg*100);
                if ($pct > $max_pct) $max_pct = $pct;
            }
        }
        if ($max_pct>0) return '<span class="onsale px-onsale">−'.$max_pct.'%</span>';
    } else {
        $reg = (float)$product->get_regular_price(); $sale = (float)$product->get_sale_price();
        if ($reg>0 && $sale>0 && $sale<$reg){
            $pct = round(($reg-$sale)/$reg*100);
            return '<span class="onsale px-onsale">−'.$pct.'%</span>';
        }
    }
    return $html;
}, 10, 3);

/* Site-wide promo banner (bật/tắt qua Customizer) — hiển thị trên trust strip */
add_action('customize_register', function($wp){
    $wp->add_section('powerx_promo', array('title'=>'Power X — Khuyến mãi (Promo)','panel'=>'powerx_panel'));
    $wp->add_setting('powerx_promo_on', array('default'=>'1','sanitize_callback'=>'sanitize_text_field'));
    $wp->add_control('powerx_promo_on', array('label'=>'Bật banner khuyến mãi?','section'=>'powerx_promo','type'=>'select','choices'=>array('0'=>'TẮT','1'=>'BẬT')));
    $wp->add_setting('powerx_promo_pct', array('default'=>'15','sanitize_callback'=>'sanitize_text_field'));
    $wp->add_control('powerx_promo_pct', array('label'=>'% giảm hiển thị','section'=>'powerx_promo','type'=>'number','input_attrs'=>array('min'=>0,'max'=>99)));
    $wp->add_setting('powerx_promo_text', array('default'=>'Power X Holiday Sale — Giảm đến','sanitize_callback'=>'sanitize_text_field'));
    $wp->add_control('powerx_promo_text', array('label'=>'Nội dung trước %','section'=>'powerx_promo','type'=>'text'));
    $wp->add_setting('powerx_promo_text2', array('default'=>'cho mọi đơn nệm','sanitize_callback'=>'sanitize_text_field'));
    $wp->add_control('powerx_promo_text2', array('label'=>'Nội dung sau %','section'=>'powerx_promo','type'=>'text'));
}, 20);

function powerx_promo_banner(){
    if (px_opt('powerx_promo_on','1') !== '1') return '';
    $pct = intval(px_opt('powerx_promo_pct','15'));
    $a = px_opt('powerx_promo_text','Power X Holiday Sale — Giảm đến');
    $b = px_opt('powerx_promo_text2','cho mọi đơn nệm');
    return '<div class="px-promo-banner"><div class="px-wrap"><span class="px-promo-icon">🏷</span> <b>'.esc_html($a).'</b> <span class="px-promo-pct">'.$pct.'%</span> '.esc_html($b).' — <span class="px-promo-cta">DÙNG MÃ POWER'.$pct.'</span></div></div>';
}

/* ===== Label "% sale" theo % promo — hiển thị trên góc MỌI sản phẩm khi promo BẬT ===== */
function powerx_promo_pct(){
    if (!function_exists('px_opt') || px_opt('powerx_promo_on','1') !== '1') return 0;
    return max(0, intval(px_opt('powerx_promo_pct','15')));
}
function powerx_promo_badge_html($class=''){
    $p = powerx_promo_pct();
    if($p<=0) return '';
    return '<span class="px-sale-badge '.esc_attr($class).'">Sale '.$p.'%</span>';
}
/* Lưu ý: trên trang chi tiết, badge được render TRONG ảnh chính (xem woocommerce/single-product/product-image.php) để bám đúng góc ảnh */

/* ===== GIẢM GIÁ ĐỘNG: giá bán = giá niêm yết × (1 − %). Đổi % trong Customizer là MỌI giá tự cập nhật ===== */
function powerx_discounted($regular){
    $pct = powerx_promo_pct();
    $regular = (float)$regular;
    if($pct<=0 || $regular<=0) return '';
    // Làm tròn xuống còn đuôi .000 (vd 8.669.150 -> 8.669.000)
    return floor(($regular * (1 - $pct/100)) / 1000) * 1000;
}
function powerx_filter_active_price($price, $product){
    if(!is_object($product)) return $price;
    $d = powerx_discounted($product->get_regular_price());
    return ($d==='') ? $price : $d;
}
add_filter('woocommerce_product_get_price',                'powerx_filter_active_price', 99, 2);
add_filter('woocommerce_product_get_sale_price',           'powerx_filter_active_price', 99, 2);
add_filter('woocommerce_product_variation_get_price',      'powerx_filter_active_price', 99, 2);
add_filter('woocommerce_product_variation_get_sale_price', 'powerx_filter_active_price', 99, 2);

/* Range giá của sản phẩm variable */
function powerx_filter_variation_prices($price, $variation, $product){
    $d = powerx_discounted($variation->get_regular_price());
    return ($d==='') ? $price : $d;
}
add_filter('woocommerce_variation_prices_price',      'powerx_filter_variation_prices', 99, 3);
add_filter('woocommerce_variation_prices_sale_price', 'powerx_filter_variation_prices', 99, 3);
/* Cache giá biến thể đổi theo % để không giữ giá cũ */
add_filter('woocommerce_get_variation_prices_hash', function($hash,$product,$display){
    $hash['powerx_promo'] = powerx_promo_pct();
    return $hash;
}, 10, 3);
