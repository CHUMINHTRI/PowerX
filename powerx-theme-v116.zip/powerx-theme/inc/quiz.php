<?php
/** Shortcode quiz + nút mở popup lead */
if (!defined('ABSPATH')) exit;

add_shortcode('powerx_quiz', function($atts){
    $a = shortcode_atts(array('type'=>'mattress'), $atts);
    $type = in_array($a['type'],array('mattress','pillow')) ? $a['type'] : 'mattress';
    return '<div class="px-quiz" data-type="'.esc_attr($type).'"></div>';
});

add_shortcode('powerx_lead_button', function($atts){
    $a = shortcode_atts(array('text'=>'Nhận tư vấn miễn phí','interest'=>'Tư vấn chung'), $atts);
    return '<button class="px-btn px-lead-open" data-interest="'.esc_attr($a['interest']).'">'.esc_html($a['text']).'</button>';
});
