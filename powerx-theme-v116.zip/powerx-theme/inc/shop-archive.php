<?php
/** Power X — Layout cửa hàng/danh mục kiểu Bedgear: Hero + Filter + thẻ sản phẩm lớn.
 *  Áp dụng cho: Cửa hàng (shop), Nệm Hightech, Gối Hightech. */
if (!defined('ABSPATH')) exit;

/* ===== Xác định ngữ cảnh ===== */
// Trả về 'shop' | 'nem' | 'goi' | '' (rỗng = không dùng layout tuỳ biến)
function powerx_current_shop_key(){
    if(function_exists('is_product_category') && is_product_category()){
        $term = get_queried_object();
        if($term && !is_wp_error($term)){
            $slugs = array($term->slug);
            foreach(get_ancestors($term->term_id,'product_cat') as $aid){
                $at=get_term($aid,'product_cat'); if($at && !is_wp_error($at)) $slugs[]=$at->slug;
            }
            foreach($slugs as $s){
                if(in_array($s,array('nem','nem-hightech','nem-hi-tech'),true)) return 'nem';
                if(in_array($s,array('goi','goi-hightech','goi-hi-tech'),true)) return 'goi';
            }
        }
        return '';
    }
    if(function_exists('is_shop') && is_shop()) return 'shop';
    return '';
}
function powerx_is_custom_shop(){ return powerx_current_shop_key() !== ''; }

// Slug danh mục thực sự tồn tại cho key nem/goi (để lọc wc_get_products)
function powerx_shop_cat_slug($key){
    $cand = ($key==='nem') ? array('nem-hightech','nem','nem-hi-tech')
          : (($key==='goi') ? array('goi-hightech','goi','goi-hi-tech') : array());
    foreach($cand as $s){ $t=get_term_by('slug',$s,'product_cat'); if($t && !is_wp_error($t)) return $s; }
    return '';
}

/* ===== Hero defaults (dùng chung cho Customizer & template để tránh lỗi default) ===== */
function powerx_wchero_defaults(){
    return array(
        'shop'=>array('eyebrow'=>'POWER X STORE','title'=>'GIẤC NGỦ HIỆU SUẤT CAO','sub'=>'Khám phá toàn bộ nệm & gối công nghệ Power X — FOR ME · NOT FOR YOU.'),
        'nem' =>array('eyebrow'=>'NỆM HIGHTECH','title'=>'NỆM KHÔNG CHỈ ĐỂ NẰM','sub'=>'Hybrid · Graphene · Memory — nâng đỡ chuẩn cột sống, ngủ mát suốt đêm.'),
        'goi' =>array('eyebrow'=>'GỐI HIGHTECH','title'=>'NÂNG NIU TỪNG GIẤC NGỦ','sub'=>'Gối định hình CNC — ôm sát cổ gáy, êm thoáng cho mọi tư thế.'),
    );
}

/* ===== Customizer: Hero riêng từng danh mục ===== */
add_action('customize_register', function($wp){
    if(!class_exists('WP_Customize_Image_Control')) return;
    $wp->add_section('powerx_shop_hero_sec', array('title'=>'WooCommerce — Hero cửa hàng & danh mục','priority'=>33));

    $defs = powerx_wchero_defaults();
    $labels = array('shop'=>'Cửa hàng (Shop)','nem'=>'Nệm Hightech','goi'=>'Gối Hightech');
    foreach($defs as $key=>$d){
        $L = $labels[$key];
        // Ảnh
        $wp->add_setting("powerx_wchero_{$key}_img", array('sanitize_callback'=>'esc_url_raw'));
        $wp->add_control(new WP_Customize_Image_Control($wp,"powerx_wchero_{$key}_img",array('label'=>"$L — Ảnh hero",'section'=>'powerx_shop_hero_sec')));
        // Eyebrow
        $wp->add_setting("powerx_wchero_{$key}_eyebrow", array('default'=>$d['eyebrow'],'sanitize_callback'=>'sanitize_text_field'));
        $wp->add_control("powerx_wchero_{$key}_eyebrow", array('label'=>"$L — Chữ nhỏ trên",'section'=>'powerx_shop_hero_sec','type'=>'text'));
        // Title
        $wp->add_setting("powerx_wchero_{$key}_title", array('default'=>$d['title'],'sanitize_callback'=>'sanitize_text_field'));
        $wp->add_control("powerx_wchero_{$key}_title", array('label'=>"$L — Tiêu đề lớn",'section'=>'powerx_shop_hero_sec','type'=>'text'));
        // Sub
        $wp->add_setting("powerx_wchero_{$key}_sub", array('default'=>$d['sub'],'sanitize_callback'=>'sanitize_text_field'));
        $wp->add_control("powerx_wchero_{$key}_sub", array('label'=>"$L — Mô tả ngắn",'section'=>'powerx_shop_hero_sec','type'=>'textarea'));
    }
});

/* ===== Lọc sản phẩm theo tham số ?fcat / ?ftype / ?fhard / ?fmin / ?fmax ===== */
add_action('woocommerce_product_query', function($q){
    if(is_admin() || !powerx_is_custom_shop()) return;

    $meta = (array)$q->get('meta_query');
    $tax  = (array)$q->get('tax_query');

    if(!empty($_GET['fcat'])){
        $slugs = array_filter(array_map('sanitize_title',(array)$_GET['fcat']));
        if($slugs){ $tax[] = array('taxonomy'=>'product_cat','field'=>'slug','terms'=>$slugs,'operator'=>'IN'); }
    }
    if(!empty($_GET['ftype'])){
        $vals = array_filter(array_map('sanitize_text_field',(array)$_GET['ftype']));
        if($vals){ $meta[] = array('key'=>'px_type','value'=>$vals,'compare'=>'IN'); }
    }
    if(!empty($_GET['fhard'])){
        $vals = array_filter(array_map('sanitize_text_field',(array)$_GET['fhard']));
        if($vals){ $meta[] = array('key'=>'px_hardness','value'=>$vals,'compare'=>'IN'); }
    }
    if(isset($_GET['fmin']) || isset($_GET['fmax'])){
        $min = isset($_GET['fmin']) && $_GET['fmin']!=='' ? (float)$_GET['fmin'] : 0;
        $max = isset($_GET['fmax']) && $_GET['fmax']!=='' ? (float)$_GET['fmax'] : 999999999;
        $meta[] = array('key'=>'_price','value'=>array($min,$max),'type'=>'NUMERIC','compare'=>'BETWEEN');
    }

    if(count($meta)){ $q->set('meta_query',$meta); }
    if(count($tax)){ if(count($tax)>1 && empty($tax['relation'])) $tax['relation']='AND'; $q->set('tax_query',$tax); }
});

/* ===== Dữ liệu để dựng các nhóm filter (theo phạm vi danh mục hiện tại) ===== */
function powerx_shop_filter_data(){
    $key = powerx_current_shop_key();
    $args = array('status'=>'publish','limit'=>-1,'return'=>'ids');
    $catslug = ($key==='nem'||$key==='goi') ? powerx_shop_cat_slug($key) : '';
    if($catslug) $args['category'] = array($catslug);
    $ids = function_exists('wc_get_products') ? wc_get_products($args) : array();

    $types=array(); $hards=array(); $min=null; $max=null;
    foreach($ids as $pid){
        $t=get_post_meta($pid,'px_type',true);     if($t!=='') $types[$t]=true;
        $h=get_post_meta($pid,'px_hardness',true);  if($h!=='') $hards[$h]=true;
        $p=(float)get_post_meta($pid,'_price',true);
        if($p>0){ if($min===null||$p<$min)$min=$p; if($max===null||$p>$max)$max=$p; }
    }
    ksort($types); ksort($hards);

    // Danh mục để lọc: trên Shop hiện danh mục con của nem & goi (hoặc toàn bộ); trên nem/goi hiện danh mục con của chính nó
    $cats = array();
    $parent_slug = $catslug;
    if($key==='shop'){
        $terms = get_terms(array('taxonomy'=>'product_cat','hide_empty'=>true,'parent'=>0,'exclude'=>array(get_option('default_product_cat'))));
        if(!is_wp_error($terms)) foreach($terms as $tm){ $cats[]=$tm; }
    } elseif($parent_slug){
        $pt = get_term_by('slug',$parent_slug,'product_cat');
        if($pt && !is_wp_error($pt)){
            $terms = get_terms(array('taxonomy'=>'product_cat','hide_empty'=>true,'parent'=>$pt->term_id));
            if(!is_wp_error($terms)) foreach($terms as $tm){ $cats[]=$tm; }
        }
    }
    return array(
        'types'=>array_keys($types),
        'hards'=>array_keys($hards),
        'min'=>$min!==null?(int)floor($min):0,
        'max'=>$max!==null?(int)ceil($max):0,
        'cats'=>$cats,
    );
}

/* ===== Render: nhóm filter dạng accordion ===== */
function powerx_filter_group($title,$inner,$open=true){
    if(trim($inner)==='') return '';
    $cls = $open ? 'px-fgroup is-open' : 'px-fgroup';
    return '<div class="'.$cls.'"><button type="button" class="px-fgroup-head">'.esc_html($title).'<span class="px-fgroup-ic"></span></button><div class="px-fgroup-body">'.$inner.'</div></div>';
}
function powerx_render_shop_filters(){
    $d = powerx_shop_filter_data();
    $sel_cat  = isset($_GET['fcat'])  ? (array)$_GET['fcat']  : array();
    $sel_type = isset($_GET['ftype']) ? array_map('sanitize_text_field',(array)$_GET['ftype']) : array();
    $sel_hard = isset($_GET['fhard']) ? array_map('sanitize_text_field',(array)$_GET['fhard']) : array();
    $cur_min  = isset($_GET['fmin']) ? esc_attr($_GET['fmin']) : '';
    $cur_max  = isset($_GET['fmax']) ? esc_attr($_GET['fmax']) : '';

    echo '<aside class="px-shop-filters" id="px-shop-filters">';
    echo '<form method="get" class="px-filter-form">';
    // giữ lại orderby nếu có
    if(!empty($_GET['orderby'])) echo '<input type="hidden" name="orderby" value="'.esc_attr(sanitize_text_field($_GET['orderby'])).'">';
    echo '<div class="px-filter-top"><span>Bộ lọc</span><button type="button" class="px-filter-close" aria-label="Đóng">&times;</button></div>';

    // Danh mục
    if(!empty($d['cats'])){
        $in='';
        foreach($d['cats'] as $tm){
            $ck = in_array($tm->slug,array_map('sanitize_title',$sel_cat),true)?' checked':'';
            $in .= '<label class="px-fopt"><input type="checkbox" name="fcat[]" value="'.esc_attr($tm->slug).'"'.$ck.'><span>'.esc_html($tm->name).'</span><em>'.intval($tm->count).'</em></label>';
        }
        echo powerx_filter_group('Danh mục',$in,true);
    }
    // Loại (px_type)
    if(!empty($d['types'])){
        $in='';
        foreach($d['types'] as $v){
            $ck = in_array($v,$sel_type,true)?' checked':'';
            $in .= '<label class="px-fopt"><input type="checkbox" name="ftype[]" value="'.esc_attr($v).'"'.$ck.'><span>'.esc_html($v).'</span></label>';
        }
        echo powerx_filter_group('Loại',$in,true);
    }
    // Độ cứng (px_hardness)
    if(!empty($d['hards'])){
        $in='';
        foreach($d['hards'] as $v){
            $ck = in_array($v,$sel_hard,true)?' checked':'';
            $in .= '<label class="px-fopt"><input type="checkbox" name="fhard[]" value="'.esc_attr($v).'"'.$ck.'><span>'.esc_html($v).'</span></label>';
        }
        echo powerx_filter_group('Độ cứng',$in,true);
    }
    // Khoảng giá
    if($d['max']>0){
        $in = '<div class="px-fprice">'
            . '<input type="number" name="fmin" inputmode="numeric" placeholder="'.esc_attr(number_format($d['min'],0,',','.')).'" value="'.$cur_min.'" min="0">'
            . '<span>—</span>'
            . '<input type="number" name="fmax" inputmode="numeric" placeholder="'.esc_attr(number_format($d['max'],0,',','.')).'" value="'.$cur_max.'" min="0">'
            . '</div><div class="px-fprice-hint">Đơn vị: VNĐ</div>';
        echo powerx_filter_group('Khoảng giá',$in,true);
    }

    echo '<div class="px-filter-actions"><button type="submit" class="px-btn px-btn-lime">Áp dụng</button>';
    echo '<a class="px-filter-clear" href="'.esc_url(strtok($_SERVER['REQUEST_URI'],'?')).'">Xoá lọc</a></div>';
    echo '</form>';
    echo '</aside>';
}

/* ===== Render: thẻ sản phẩm lớn kiểu Bedgear ===== */
function powerx_shop_card($product){
    if(!$product) return;
    $id   = $product->get_id();
    $link = get_permalink($id);
    $pill = get_post_meta($id,'px_pill',true);
    $rating = (float)$product->get_average_rating();
    $rcount = (int)$product->get_rating_count();

    // mô tả ngắn
    $desc = $product->get_short_description();
    if($desc==='') $desc = wp_trim_words( wp_strip_all_tags($product->get_description()), 30 );

    // tính năng: ưu tiên X-Features (Mã | Mô tả), fallback specs
    $feats = array();
    $xf = get_post_meta($id,'px_xfeatures',true);
    if($xf){
        foreach(preg_split('/\r?\n/',$xf) as $line){
            $parts=array_map('trim',explode('|',$line,2));
            if($parts[0]!=='') $feats[] = $parts[0];
            if(count($feats)>=4) break;
        }
    }
    if(empty($feats)){
        $h=get_post_meta($id,'px_height',true); $t=get_post_meta($id,'px_type',true); $hd=get_post_meta($id,'px_hardness',true); $w=get_post_meta($id,'px_warranty',true);
        if($t) $feats[]=$t; if($hd) $feats[]='Độ cứng '.$hd; if($h) $feats[]='Cao '.$h; if($w) $feats[]='BH '.$w;
    }

    echo '<article '; wc_product_class('px-bigcard',$product); echo '>';
    echo '<a class="px-bigcard-media" href="'.esc_url($link).'">';
    if($pill) echo '<span class="px-card-pill">'.esc_html($pill).'</span>';
    if(function_exists('powerx_promo_badge_html')) echo powerx_promo_badge_html('px-sale-badge--card');
    if($product->get_image_id()){
        echo $product->get_image('woocommerce_single');
    } else {
        $g1 = get_post_meta($id,'px_gal1_img',true);
        if($g1) echo '<img src="'.esc_url($g1).'" alt="'.esc_attr($product->get_name()).'">';
        else echo $product->get_image('woocommerce_single');
    }
    echo '</a>';

    echo '<div class="px-bigcard-info">';
    echo '<h3 class="px-bigcard-title"><a href="'.esc_url($link).'">'.esc_html($product->get_name()).'</a></h3>';
    if(function_exists('powerx_trust_html')) echo powerx_trust_html($product,'px-bigcard-rate');
    if($desc) echo '<p class="px-bigcard-desc">'.esc_html(wp_strip_all_tags($desc)).'</p>';
    if(!empty($feats)){
        echo '<ul class="px-bigcard-feats">';
        foreach($feats as $f){
            echo '<li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6L9 17l-5-5"/></svg>'.esc_html($f).'</li>';
        }
        echo '</ul>';
    }
    echo '<div class="px-bigcard-foot">';
    echo '<span class="px-bigcard-price">'.$product->get_price_html().'</span>';
    echo '<div class="px-bigcard-cta">';
    echo '<a class="px-btn px-btn-ghost" href="'.esc_url($link).'">Xem chi tiết</a>';
    woocommerce_template_loop_add_to_cart();
    echo '</div></div>';
    echo '</div></article>';
}

/* ===== Render: toàn bộ trang archive ===== */
function powerx_render_shop_archive(){
    $key = powerx_current_shop_key();
    $dd  = powerx_wchero_defaults();
    $d   = isset($dd[$key]) ? $dd[$key] : array('eyebrow'=>'','title'=>'','sub'=>'');
    $eyebrow = px_opt("powerx_wchero_{$key}_eyebrow", $d['eyebrow']);
    $title   = px_opt("powerx_wchero_{$key}_title",   $d['title']);
    $sub     = px_opt("powerx_wchero_{$key}_sub",     $d['sub']);
    $img     = px_opt("powerx_wchero_{$key}_img",     '');

    // HERO
    echo '<section class="px-shop-hero'.($img?'':' is-noimg').'"'.($img?(' style="background-image:url('.esc_url($img).')"'):'').'>';
    echo '<div class="px-shop-hero-overlay"></div>';
    echo '<div class="px-wrap px-shop-hero-in">';
    if($eyebrow) echo '<span class="px-shop-hero-eyebrow">'.esc_html($eyebrow).'</span>';
    echo '<h1 class="px-shop-hero-title">'.esc_html($title).'</h1>';
    if($sub) echo '<p class="px-shop-hero-sub">'.esc_html($sub).'</p>';
    echo '</div></section>';

    // BODY
    echo '<div class="px-wrap px-shop-wrap">';

    // Toolbar (đếm + nút mở lọc mobile + sắp xếp)
    $total = isset($GLOBALS['wp_query']->found_posts) ? (int)$GLOBALS['wp_query']->found_posts : 0;
    $cur_order = isset($_GET['orderby']) ? sanitize_text_field($_GET['orderby']) : '';
    $orders = array(
        'menu_order'=>'Nổi bật',
        'popularity'=>'Bán chạy',
        'rating'=>'Đánh giá cao',
        'date'=>'Mới nhất',
        'price'=>'Giá: thấp → cao',
        'price-desc'=>'Giá: cao → thấp',
    );
    echo '<div class="px-shop-toolbar">';
    echo '<button type="button" class="px-filter-toggle" aria-controls="px-shop-filters"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M7 12h10M10 18h4"/></svg> Bộ lọc</button>';
    echo '<div class="px-shop-count"><b>'.$total.'</b> sản phẩm</div>';
    echo '<div class="px-shop-sort"><label>Sắp xếp</label><select onchange="var u=new URL(location.href);if(this.value){u.searchParams.set(\'orderby\',this.value);}else{u.searchParams.delete(\'orderby\');}u.searchParams.delete(\'paged\');location.href=u.toString();">';
    foreach($orders as $val=>$lbl){
        $sel = ($val===$cur_order || ($cur_order==='' && $val==='menu_order')) ? ' selected' : '';
        echo '<option value="'.esc_attr($val).'"'.$sel.'>'.esc_html($lbl).'</option>';
    }
    echo '</select></div>';
    echo '</div>';

    echo '<div class="px-shop-cols">';
    powerx_render_shop_filters();

    echo '<div class="px-shop-main">';
    if(woocommerce_product_loop()){
        // cập nhật lại số đếm chính xác sau khi loop khởi tạo loop props
        echo '<div class="px-bigcard-grid">';
        while(have_posts()){
            the_post();
            $p = wc_get_product(get_the_ID());
            powerx_shop_card($p);
        }
        echo '</div>';
        woocommerce_pagination();
    } else {
        echo '<div class="px-shop-empty"><p>Không tìm thấy sản phẩm phù hợp bộ lọc.</p><a class="px-btn" href="'.esc_url(strtok($_SERVER['REQUEST_URI'],'?')).'">Xoá bộ lọc</a></div>';
    }
    echo '</div>'; // main
    echo '</div>'; // cols
    echo '</div>'; // wrap
}
