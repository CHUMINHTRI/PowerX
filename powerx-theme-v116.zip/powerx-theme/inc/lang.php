<?php
/**
 * Power X — Đa ngôn ngữ tự động bằng Google Translate.
 * Dropdown 1 cờ trên header: bấm cờ là cả trang tự dịch sang EN/中文 (không cần plugin, không cần tạo nội dung).
 */
if (!defined('ABSPATH')) exit;

/* 3 ngôn ngữ cố định (mã theo Google Translate) */
function powerx_langs(){
    return array(
        array('code'=>'vi',    'flag'=>'vn', 'name'=>'Tiếng Việt', 'short'=>'VI'),
        array('code'=>'en',    'flag'=>'gb', 'name'=>'English',     'short'=>'EN'),
        array('code'=>'zh-CN', 'flag'=>'cn', 'name'=>'中文',        'short'=>'中'),
    );
}
function powerx_lang_flag_url($flag){ return 'https://flagcdn.com/w40/'.$flag.'.png'; }

/* Ngôn ngữ hiện tại đọc từ cookie googtrans (vd /vi/en) */
function powerx_current_lang(){
    $code='vi';
    if(!empty($_COOKIE['googtrans'])){
        $parts=array_values(array_filter(explode('/', $_COOKIE['googtrans'])));
        if(!empty($parts)){ $last=end($parts); if($last) $code=$last; }
    }
    return $code;
}

/* Dropdown cờ cho header */
function powerx_lang_switcher(){
    $langs=powerx_langs();
    $cur=powerx_current_lang();
    $curL=$langs[0];
    foreach($langs as $l){ if($l['code']===$cur){ $curL=$l; break; } }

    $h  = '<div class="px-lang notranslate" translate="no" data-open="false">';
    $h .= '<button type="button" class="px-lang-cur" aria-haspopup="true" aria-expanded="false" aria-label="Chọn ngôn ngữ">';
    $h .= '<img src="'.esc_url(powerx_lang_flag_url($curL['flag'])).'" alt="'.esc_attr($curL['name']).'" width="22" height="16" loading="lazy">';
    $h .= '<span class="px-lang-code">'.esc_html($curL['short']).'</span>';
    $h .= '<svg class="px-lang-caret" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 9l6 6 6-6"/></svg>';
    $h .= '</button>';
    $h .= '<ul class="px-lang-menu" role="menu">';
    foreach($langs as $l){
        $active = ($l['code']===$cur) ? ' is-active' : '';
        $h .= '<li role="none"><button type="button" role="menuitem" class="px-lang-item'.$active.'" data-lang="'.esc_attr($l['code']).'">'
            . '<img src="'.esc_url(powerx_lang_flag_url($l['flag'])).'" alt="" width="22" height="16" loading="lazy">'
            . '<span>'.esc_html($l['name']).'</span></button></li>';
    }
    $h .= '</ul></div>';
    return $h;
}

/* Nạp Google Translate (ẩn) + xử lý đổi ngôn ngữ qua cookie */
add_action('wp_footer', function(){
    ?>
    <div id="google_translate_element" style="display:none"></div>
    <script>
    function googleTranslateElementInit(){
        new google.translate.TranslateElement({pageLanguage:'vi',includedLanguages:'vi,en,zh-CN',autoDisplay:false},'google_translate_element');
    }
    (function(){
        function setCookie(name,val){
            var h=location.hostname;
            document.cookie=name+'='+val+';path=/';
            document.cookie=name+'='+val+';path=/;domain='+h;
            document.cookie=name+'='+val+';path=/;domain=.'+h;
        }
        function killCookie(name){
            var exp=';expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/', h=location.hostname;
            document.cookie=name+'='+exp;
            document.cookie=name+'='+exp+';domain='+h;
            document.cookie=name+'='+exp+';domain=.'+h;
        }
        var FLAG={'vi':['vn','VI'],'en':['gb','EN'],'zh-CN':['cn','中']};
        function updateFlagUI(code){
            var f=FLAG[code]||FLAG['vi'], cur=document.querySelector('.px-lang-cur');
            if(cur){ var img=cur.querySelector('img'); if(img) img.src='https://flagcdn.com/w40/'+f[0]+'.png';
                     var c=cur.querySelector('.px-lang-code'); if(c) c.textContent=f[1]; }
            document.querySelectorAll('.px-lang-item').forEach(function(it){
                it.classList.toggle('is-active', it.getAttribute('data-lang')===code); });
            var w=document.querySelector('.px-lang'); if(w) w.setAttribute('data-open','false');
        }
        // Đợi combo của Google sẵn sàng rồi dịch ngay tại chỗ (không reload)
        function withCombo(cb, tries){
            tries=tries||0;
            var combo=document.querySelector('.goog-te-combo');
            if(combo){ cb(combo); return; }
            if(tries<40){ setTimeout(function(){ withCombo(cb,tries+1); }, 150); }
            else { cb(null); }
        }
        window.pxSetLang=function(code){
            killCookie('googtrans');
            if(code && code!=='vi'){ setCookie('googtrans','/vi/'+code); }
            if(code==='vi'){ location.reload(); return; } // về tiếng Việt: tải lại bản gốc cho sạch
            updateFlagUI(code);
            withCombo(function(combo){
                if(combo){ combo.value=code; combo.dispatchEvent(new Event('change')); }
                else { location.reload(); } // dự phòng nếu combo chưa nạp được
            });
        };
        document.addEventListener('click',function(e){
            var b=e.target.closest && e.target.closest('.px-lang-item[data-lang]');
            if(b){ e.preventDefault(); window.pxSetLang(b.getAttribute('data-lang')); }
        });
    })();
    </script>
    <script async src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <?php
});
