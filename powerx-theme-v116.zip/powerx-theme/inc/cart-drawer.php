<?php
/** Power X — Giỏ hàng trượt (drawer) kiểu Bedgear: mở khi bấm icon giỏ, cập nhật AJAX (+/-/xoá). */
if (!defined('ABSPATH')) exit;

/* Nội dung bên trong drawer (freeship luôn đạt + danh sách + tạm tính + nút) */
function powerx_cart_drawer_content(){
    if(!function_exists('WC') || !WC()->cart) return '';
    $cart = WC()->cart;
    ob_start(); ?>
    <div class="px-cd-ship">
        <span class="px-cd-ship-tx"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7h11v8H3z"/><path d="M14 10h4l3 3v2h-7z"/><circle cx="7" cy="17.5" r="1.6"/><circle cx="17.5" cy="17.5" r="1.6"/></svg> Bạn được <b>miễn phí giao lắp</b> toàn quốc</span>
        <div class="px-cd-bar"><span style="width:100%"></span></div>
    </div>
    <?php if($cart->is_empty()): ?>
        <div class="px-cd-empty">
            <p>Giỏ hàng của bạn đang trống.</p>
            <a class="px-btn px-btn-lime" href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>">Tiếp tục mua sắm</a>
        </div>
    <?php else: ?>
        <div class="px-cd-items">
        <?php foreach($cart->get_cart() as $key=>$item):
            $p = isset($item['data']) ? $item['data'] : null;
            if(!$p || !$p->exists() || $item['quantity']<=0) continue;
            $link = $p->is_visible() ? get_permalink($p->get_id()) : '';
        ?>
            <div class="px-cd-item" data-key="<?php echo esc_attr($key); ?>">
                <a class="px-cd-thumb" href="<?php echo esc_url($link); ?>"><?php echo $p->get_image('woocommerce_gallery_thumbnail'); ?></a>
                <div class="px-cd-info">
                    <a class="px-cd-name" href="<?php echo esc_url($link); ?>"><?php echo esc_html($p->get_name()); ?></a>
                    <div class="px-cd-price"><?php echo wc_price($p->get_price()); ?></div>
                    <div class="px-cd-qtyrow">
                        <div class="px-cd-qty">
                            <button type="button" class="px-cd-minus" aria-label="Giảm">&minus;</button>
                            <span class="px-cd-num"><?php echo esc_html($item['quantity']); ?></span>
                            <button type="button" class="px-cd-plus" aria-label="Tăng">+</button>
                        </div>
                        <button type="button" class="px-cd-remove">Xoá</button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
        <div class="px-cd-foot">
            <div class="px-cd-sub"><span>Tạm tính</span><b><?php echo $cart->get_cart_subtotal(); ?></b></div>
            <p class="px-cd-note">Thuế, giảm giá &amp; phí vận chuyển tính ở bước thanh toán.</p>
            <a class="px-btn px-btn-lime px-cd-checkout" href="<?php echo esc_url(wc_get_checkout_url()); ?>">Thanh toán</a>
            <a class="px-cd-viewcart" href="<?php echo esc_url(wc_get_cart_url()); ?>">Xem giỏ hàng</a>
        </div>
    <?php endif;
    return ob_get_clean();
}

/* Khung drawer (render 1 lần ở footer) */
add_action('wp_footer', function(){
    if(!function_exists('WC') || is_admin()) return;
    echo '<div class="px-cartdrawer" id="px-cartdrawer" aria-hidden="true">'
       . '<div class="px-cartdrawer-overlay"></div>'
       . '<aside class="px-cartdrawer-panel" role="dialog" aria-label="Giỏ hàng">'
       . '<div class="px-cartdrawer-head"><b>Giỏ hàng của bạn</b><span class="px-cd-count">'.intval(powerx_cart_count()).'</span><button type="button" class="px-cartdrawer-x" aria-label="Đóng">&times;</button></div>'
       . '<div class="px-cd-content">'.powerx_cart_drawer_content().'</div>'
       . '</aside></div>';
});

/* AJAX: lấy/đổi số lượng/xoá item -> trả HTML mới + số lượng */
add_action('wp_ajax_powerx_cart','powerx_cart_ajax');
add_action('wp_ajax_nopriv_powerx_cart','powerx_cart_ajax');
function powerx_cart_ajax(){
    if(!function_exists('WC') || !WC()->cart){ wp_send_json_error(); }
    $act = isset($_POST['act']) ? sanitize_text_field($_POST['act']) : 'get';
    $key = isset($_POST['key']) ? sanitize_text_field($_POST['key']) : '';
    $cart = WC()->cart;
    if($act==='remove' && $key){
        $cart->remove_cart_item($key);
    } elseif($act==='set' && $key){
        $q = isset($_POST['qty']) ? intval($_POST['qty']) : 1;
        if($q<=0) $cart->remove_cart_item($key);
        else $cart->set_quantity($key, $q, true);
    }
    $cart->calculate_totals();
    wp_send_json_success(array(
        'html'  => powerx_cart_drawer_content(),
        'count' => $cart->get_cart_contents_count(),
    ));
}
