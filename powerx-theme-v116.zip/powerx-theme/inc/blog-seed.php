<?php
/** 5 bài blog mẫu — chỉ tạo NẾU CHƯA TỒN TẠI (chống trùng khi tái kích hoạt theme) */
if (!defined('ABSPATH')) exit;

function powerx_post_exists($title){
    $q = get_posts(array('post_type'=>'post','title'=>$title,'post_status'=>'any','numberposts'=>1));
    return !empty($q);
}

function powerx_seed_blog(){
    $posts = array(
      array('Câu chuyện giấc ngủ','Vì sao 1/3 cuộc đời nằm trên nệm lại quyết định 2/3 còn lại',
        '<p>Trung bình mỗi người dành khoảng một phần ba cuộc đời để ngủ. Nghe có vẻ là khoảng thời gian "không làm gì", nhưng thực ra đây là lúc cơ thể làm việc chăm chỉ nhất.</p><h3>Giấc ngủ là khoản đầu tư</h3><p>Một đêm ngủ kém khiến bạn mất tập trung, dễ cáu gắt, giảm hiệu suất. Ngủ sâu giúp tỉnh táo, ra quyết định tốt hơn.</p><h3>Chiếc nệm quyết định chất lượng</h3><p>Bề mặt bạn nằm ảnh hưởng trực tiếp cột sống, tuần hoàn và nhiệt độ cơ thể. Power X — "FOR ME · NOT FOR YOU" — chọn nệm phù hợp với chính bạn.</p>'),
      array('Ngủ ngon','7 thói quen giúp bạn ngủ sâu hơn mỗi đêm',
        '<p>Ngủ ngon là kết quả của nhiều thói quen nhỏ trong ngày.</p><h3>1. Cố định giờ ngủ-thức</h3><p>Đồng hồ sinh học thích sự đều đặn.</p><h3>2. Tránh màn hình trước ngủ</h3><p>Tắt thiết bị 30–60 phút trước khi lên giường.</p><h3>3. Phòng mát, tối</h3><p>24–26°C và tối giúp hạ nhiệt cơ thể.</p><h3>4. Hạn chế caffeine buổi chiều</h3><h3>5. Vận động ban ngày</h3><h3>6. Thư giãn trước khi ngủ</h3><h3>7. Đầu tư bề mặt ngủ</h3><p>Nệm và gối nâng đỡ đúng nhân đôi hiệu quả 6 thói quen trên.</p>'),
      array('Ngủ ngon','Vì sao bạn hay nóng lưng khi ngủ và cách khắc phục',
        '<p>Nhiều người thức giấc vì nóng và bí lưng — một trong những nguyên nhân khiến giấc ngủ bị gián đoạn.</p><h3>Nguyên nhân</h3><p>Cơ thể cần hạ nhiệt nhẹ để vào giấc ngủ sâu. Nệm giữ nhiệt khiến nhiệt tích quanh lưng.</p><h3>Cách khắc phục</h3><p>Chọn vật liệu tản nhiệt. Power X Fusion và Flow dùng foam Graphene + đường cắt AirWave để bề mặt mát hơn suốt đêm.</p>'),
      array('Sản phẩm','Nệm Hybrid hay Foam: chọn loại nào cho bạn?',
        '<p>Hai dòng nệm phổ biến nhất hiện nay: Hybrid (foam + lò xo túi) và Foam (thuần foam).</p><h3>Hybrid</h3><p>Nâng đỡ chắc, thoáng khí tốt, hạn chế rung lan. Phù hợp cặp đôi và người thích "có lực nâng".</p><h3>Foam</h3><p>Ôm sát, phân tán áp lực vai-hông. Hợp người nằm nghiêng.</p><h3>Gợi ý Power X</h3><p>Hybrid: <strong>Prime</strong> hoặc <strong>Fusion</strong>. Foam: <strong>Flow</strong> hoặc <strong>Core</strong>. Hoặc thử <a href="/quiz-nem/">quiz chọn nệm</a>.</p>'),
      array('Power X','Graphene và lò xo túi: công nghệ Power X mang lại gì?',
        '<p>Hai công nghệ đặc trưng của Power X: foam Graphene và lò xo túi độc lập phân vùng.</p><h3>Foam Graphene</h3><p>Dẫn nhiệt và kháng khuẩn tốt — giảm nóng lưng, giữ bề mặt sạch.</p><h3>Lò xo túi độc lập</h3><p>Nén độc lập theo từng điểm — nâng đỡ chính xác, ít ảnh hưởng khi bạn cùng giường trở mình.</p><h3>Kết hợp: cấu trúc Hybrid</h3><p>Prime và Fusion kết hợp cả hai — vừa êm vừa chắc. Đạt CertiPUR-US, OEKO-TEX; Prime nhận Red Dot 2019.</p>'),
    );

    foreach($posts as $i=>$pp){
        list($cat,$title,$content) = $pp;
        if (powerx_post_exists($title)) continue; // tránh trùng
        $term = get_term_by('name',$cat,'category');
        $catId = $term ? array($term->term_id) : array();
        wp_insert_post(array(
            'post_type'=>'post','post_status'=>'publish','post_title'=>$title,
            'post_content'=>$content,'post_category'=>$catId,
            'post_date'=> date('Y-m-d H:i:s', strtotime('-'.($i*2).' days')),
        ));
    }
}
