<?php if (!defined('ABSPATH')) exit; get_header(); ?>
<section class="px-section px-quizpage"><div class="px-wrap">
  <div class="px-quizpage-head">
    <span class="px-eyebrow"><?php echo esc_html(px_opt('powerx_quiznem_eyebrow','Power X MattressID')); ?></span>
    <h1><?php echo esc_html(px_opt('powerx_quiznem_h','Tìm dòng nệm hoàn hảo cho bạn')); ?></h1>
    <p><?php echo esc_html(px_opt('powerx_quiznem_sub','Trả lời 4 câu hỏi nhanh — Power X gợi ý đúng dòng nệm phù hợp với lifestyle và tư thế ngủ của bạn.')); ?></p>
  </div>
  <div class="px-quizpage-quiz"><?php echo do_shortcode('[powerx_quiz type="mattress"]'); ?></div>
</div></section>
<?php get_footer(); ?>
