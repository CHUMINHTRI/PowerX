<?php if (!defined('ABSPATH')) exit; get_header(); ?>
<?php if (function_exists('powerx_is_custom_shop') && powerx_is_custom_shop()): ?>
  <?php powerx_render_shop_archive(); ?>
<?php elseif (function_exists('is_product') && is_product()): ?>
  <?php woocommerce_content(); // template tự quản chiều rộng (2 cột px-wrap + khối full-width) ?>
<?php else: ?>
  <div class="px-wrap px-section">
    <?php woocommerce_content(); ?>
  </div>
<?php endif; ?>
<?php get_footer(); ?>
