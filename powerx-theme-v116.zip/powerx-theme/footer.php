<?php if (!defined('ABSPATH')) exit; ?>
</main>
<footer class="px-footer">
  <div class="px-wrap">

    <div class="px-foot-news">
      <div class="px-foot-news-text"><h3>Đăng ký nhận ưu đãi</h3><p>Khuyến mãi độc quyền &amp; mẹo ngủ ngon — gửi thẳng vào hộp thư của bạn.</p></div>
      <form class="px-news-form">
        <input type="email" name="email" placeholder="Email của bạn" aria-label="Email" required>
        <button type="submit">Đăng ký</button>
        <span class="px-news-msg" aria-live="polite"></span>
      </form>
    </div>

    <?php
      $f_phone = px_opt('powerx_phone','0335332028');
      $f_addr  = px_opt('powerx_address','Số nhà E97, Đường D9, khu phố Vĩnh Thanh, Phường Trấn Biên, Thành Phố Đồng Nai');
      $shop    = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/');
      $p_ss=get_page_by_path('so-sanh-nem'); $p_qn=get_page_by_path('quiz-nem'); $p_qg=get_page_by_path('quiz-goi');
      $p_vc=get_page_by_path('ve-chung-toi'); $p_dt=get_page_by_path('doi-tac');
    ?>
    <div class="px-foot-grid">
      <div class="px-foot-brand">
        <?php echo powerx_default_logo('light'); ?>
        <p class="px-foot-desc">Nệm &amp; gối hiệu năng cao — Hybrid &amp; Foam Graphene. Thương hiệu của tập đoàn DPD FOAM, phân phối độc quyền tại Việt Nam bởi Sleep Expert.</p>
        <div class="px-foot-social">
          <?php
          $socials = array(
            'powerx_social_fb'     => array('Facebook','<svg viewBox="0 0 24 24" fill="currentColor"><path d="M24 12c0-6.6-5.4-12-12-12S0 5.4 0 12c0 6 4.4 11 10.1 11.9v-8.4H7.1V12h3V9.4c0-3 1.8-4.6 4.5-4.6 1.3 0 2.7.2 2.7.2v2.9h-1.5c-1.5 0-1.9.9-1.9 1.8V12h3.3l-.5 3.5h-2.8v8.4C19.6 23 24 18 24 12z"/></svg>'),
            'powerx_social_ig'     => array('Instagram','<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1.1" fill="currentColor" stroke="none"/></svg>'),
            'powerx_social_tiktok' => array('TikTok','<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 3c.3 2.1 1.5 3.6 3.6 3.8v2.4c-1.2.1-2.5-.3-3.6-1v6.2c0 4-3.3 6.6-6.9 5.6-2.6-.7-4-3.3-3.4-5.9.5-2.3 2.7-3.9 5.1-3.7v2.5c-.4-.1-.9-.2-1.4-.1-1.1.2-1.9 1.2-1.7 2.4.2 1.1 1.3 1.9 2.5 1.6 1-.2 1.7-1.1 1.7-2.2V3H16z"/></svg>'),
            'powerx_social_youtube'=> array('YouTube','<svg viewBox="0 0 24 24" fill="currentColor"><path d="M23 7.5c-.3-1-1-1.8-2-2C19 5 12 5 12 5s-7 0-9 .5c-1 .2-1.8 1-2 2C.5 9.4.5 12 .5 12s0 2.6.5 4.5c.3 1 1 1.8 2 2C5 19 12 19 12 19s7 0 9-.5c1-.2 1.8-1 2-2 .5-1.9.5-4.5.5-4.5s0-2.6-.5-4.5zM9.8 15.3V8.7l5.7 3.3-5.7 3.3z"/></svg>'),
          );
          foreach($socials as $sk=>$sv){ $u=px_opt($sk,''); if($u) echo '<a href="'.esc_url($u).'" target="_blank" rel="noopener" aria-label="'.esc_attr($sv[0]).'">'.$sv[1].'</a>'; }
          ?>
        </div>
        <div class="px-pay"><span class="vnp">VNPAY</span><span class="mm">MoMo</span><span>VietQR</span><span>COD</span></div>
      </div>

      <div class="px-foot-col">
        <h4>Sản phẩm</h4>
        <ul>
          <li><a href="<?php echo esc_url(powerx_cat_url(array('nem-hightech','nem'))); ?>">Nệm Hightech</a></li>
          <li><a href="<?php echo esc_url(powerx_cat_url(array('goi-hightech','goi'))); ?>">Gối Hightech</a></li>
          <?php if($p_ss): ?><li><a href="<?php echo esc_url(get_permalink($p_ss)); ?>">So sánh nệm</a></li><?php endif; ?>
          <?php if($p_qn): ?><li><a href="<?php echo esc_url(get_permalink($p_qn)); ?>">Tư vấn chọn nệm</a></li><?php endif; ?>
          <li><a href="<?php echo esc_url($shop); ?>">Cửa hàng</a></li>
        </ul>
      </div>

      <div class="px-foot-col">
        <h4>Power X</h4>
        <ul>
          <?php if($p_vc): ?><li><a href="<?php echo esc_url(get_permalink($p_vc)); ?>">Về chúng tôi</a></li><?php endif; ?>
          <?php if($p_dt): ?><li><a href="<?php echo esc_url(get_permalink($p_dt)); ?>">Đối tác &amp; Đại lý</a></li><?php endif; ?>
          <li><a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a></li>
          <li><a class="px-lead-open" href="#" data-interest="Đăng ký đại lý (footer)">Đăng ký làm đại lý</a></li>
          <?php if (function_exists('powerx_training_can_view') && powerx_training_can_view() && powerx_training_enabled() && powerx_training_has_file()): ?>
          <li><a href="<?php echo esc_url(powerx_training_url()); ?>" target="_blank" rel="noopener">Đào tạo bán hàng</a></li>
          <?php endif; ?>
        </ul>
      </div>

      <div class="px-foot-col">
        <h4>Liên hệ</h4>
        <ul class="px-foot-contact">
          <li><b>Hotline:</b> <a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$f_phone)); ?>"><?php echo esc_html($f_phone); ?></a></li>
          <?php if($e=px_opt('powerx_email','info@powerxsleep.vn')): ?><li><b>Email:</b> <a href="mailto:<?php echo esc_attr($e); ?>"><?php echo esc_html($e); ?></a></li><?php endif; ?>
          <?php $z=px_opt('powerx_zalo','https://zalo.me/0335332028'); $m=px_opt('powerx_messenger','https://www.facebook.com/profile.php?id=61579758988072'); if($z||$m): ?>
          <li class="px-foot-cicons">
            <?php if($z): ?><a class="px-cic px-cic-zalo" href="<?php echo esc_url($z); ?>" target="_blank" rel="noopener" aria-label="Zalo">Zalo</a><?php endif; ?>
            <?php if($m): ?><a class="px-cic px-cic-fb" href="<?php echo esc_url($m); ?>" target="_blank" rel="noopener" aria-label="Facebook"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M24 12c0-6.6-5.4-12-12-12S0 5.4 0 12c0 6 4.4 11 10.1 11.9v-8.4H7.1V12h3V9.4c0-3 1.8-4.6 4.5-4.6 1.3 0 2.7.2 2.7.2v2.9h-1.5c-1.5 0-1.9.9-1.9 1.8V12h3.3l-.5 3.5h-2.8v8.4C19.6 23 24 18 24 12z"/></svg></a><?php endif; ?>
          </li>
          <?php endif; ?>
          <li><b>Showroom:</b> <?php echo esc_html($f_addr); ?></li>
        </ul>
      </div>
    </div>

    <div class="px-foot-guarantee">
      <span>✓ Bảo hành 10 năm</span><span>✓ Dùng thử 100 đêm</span><span>✓ Đổi trả miễn phí</span><span>✓ Giao lắp 24h</span>
    </div>

    <div class="px-foot-bottom">
      <div>© <?php echo esc_html(date('Y')); ?> Power X Vietnam · Sleep Expert. Mọi quyền được bảo lưu.</div>
      <div>🛡 Đã thông báo Bộ Công Thương</div>
    </div>
  </div>
</footer>

<?php if (px_opt('powerx_msg_float_on','1')==='1' && ($mf=px_opt('powerx_messenger','https://www.facebook.com/profile.php?id=61579758988072'))): ?>
<a class="px-msg-float" href="<?php echo esc_url($mf); ?>" target="_blank" rel="noopener" aria-label="Nhắn tin Messenger với Power X">
  <svg viewBox="0 0 24 24" width="30" height="30" fill="#fff" aria-hidden="true"><path d="M12 2C6.5 2 2 6.1 2 11.2c0 2.9 1.4 5.5 3.7 7.2v3.6l3.4-1.9c.9.2 1.9.4 2.9.4 5.5 0 10-4.1 10-9.2S17.5 2 12 2zm1 12.4l-2.6-2.7L5.7 14.4l5.2-5.5 2.6 2.7L18.3 9l-5.3 5.4z"/></svg>
</a>
<?php endif; ?>

<?php wp_footer(); ?>
</body></html>
